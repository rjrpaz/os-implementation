/*
 * GeekOS C code entry point
 * Copyright (c) 2001,2003,2004 David H. Hovemeyer <daveho@cs.umd.edu>
 * Copyright (c) 2003, Jeffrey K. Hollingsworth <hollings@cs.umd.edu>
 * Copyright (c) 2004, Iulian Neamtiu <neamtiu@cs.umd.edu>
 * $Revision: 1.51 $
 * 
 * This is free software.  You are permitted to use,
 * redistribute, and modify it as specified in the file "COPYING".
 */

#include <geekos/bootinfo.h>
#include <geekos/string.h>
#include <geekos/screen.h>
#include <geekos/mem.h>
#include <geekos/crc32.h>
#include <geekos/tss.h>
#include <geekos/int.h>
#include <geekos/kthread.h>
#include <geekos/trap.h>
#include <geekos/timer.h>
#include <geekos/keyboard.h>
#include <geekos/dma.h>
#include <geekos/ide.h>
#include <geekos/floppy.h>
#include <geekos/pfat.h>
#include <geekos/vfs.h>
#include <geekos/user.h>
#include <geekos/errno.h>
#include <geekos/sem.h>
#include <geekos/paging.h>
#include <geekos/gosfs.h>

/*
 * Define this for a self-contained boot floppy
 * with a PFAT filesystem.  (Target "fd_aug.img" in
 * the makefile.)
 */
/*#define FD_BOOT*/

#ifdef FD_BOOT
#  define ROOT_DEVICE "fd0"
#  define ROOT_PREFIX "a"
#else
#  define ROOT_DEVICE "ide0"
#  define ROOT_PREFIX "c"
#  define SLAVE_DEVICE "ide1"
#  define SLAVE_PREFIX "d"
#endif

#define INIT_PROGRAM "/" ROOT_PREFIX "/shell.exe"

static void Mount_Root_Filesystem(void);
//static void Format_And_Mount_Slave_Filesystem(void);
static void Spawn_Init_Process(void);

struct Kernel_Thread *thread;
/*
void echoInput(ulong_t arg)
{
	int echoMode = true;

	//while the input shuld be echoed to the screen
	while(echoMode)
	{
		//wait for the next key entered
		Keycode kcode = Wait_For_Key();
		
		if((kcode & KEY_CTRL_FLAG) && (kcode & 0x00FF) == 'd')
		{
			// <ctrl> d aborts this thread 
			echoMode = false;
		}
		else if(!(kcode & KEY_RELEASE_FLAG) &&
			!(kcode & KEY_ALT_FLAG) &&
			!(kcode & KEY_CTRL_FLAG) &&
			!(kcode & KEY_SPECIAL_FLAG))
		{
			//Print("%c = %d (enter is %d), ", (char)kcode, kcode, (int)'\n');
			// no <alt>, <ctrl>, or special key was hit.
			// and the key has been pressed, not released (don't print this char twice!)
			if(kcode == 13)
				Put_Char('\n');
			else
				//else print the entered char
				Put_Char(kcode);
		}
	}
	
	//print some statement, to inform the user
	Print("\nexit.\n");
}
*/

/*
 * Kernel C code entry point.
 * Initializes kernel subsystems, mounts filesystems,
 * and spawns init process.
 */
void Main(struct Boot_Info* bootInfo)
{
    Init_BSS();
    Init_Screen();
    Init_Mem(bootInfo);
    Init_CRC32();
    Init_TSS();
    Init_Interrupts();
    Init_VM(bootInfo);
    Init_Scheduler();
    Init_Traps();
    Init_Timer();
    Init_Keyboard();
    Init_DMA();
    Init_Floppy();
    Init_IDE();
    Init_PFAT();
    Init_GOSFS();
    Init_Semaphors();

    Mount_Root_Filesystem();    
    //Format_And_Mount_Slave_Filesystem();      

    Set_Current_Attr(ATTRIB(BLACK, GREEN|BRIGHT));
    //Print("Welcome to GeekOS!\n");
	Print("Hello from FtpOS\n");
    Set_Current_Attr(ATTRIB(BLACK, GRAY));

    /*Start a kernel thread to echo pressed keys and print counts
    Start_Kernel_Thread(
    	echoInput,			//startFunc
    	0,					//arg
    	PRIORITY_NORMAL,	//priority
    	false				//detached (use false for kernal-threads)
    );
    */

    Spawn_Init_Process();

    /* Now this thread is done. */
    Exit(0);
}

static void Mount_Root_Filesystem(void)
{
    if (Mount(ROOT_DEVICE, ROOT_PREFIX, "pfat") != 0)
	Print("Failed to mount /" ROOT_PREFIX " filesystem\n");
    else
	Print("Mounted /" ROOT_PREFIX " filesystem!\n");

    Init_Paging();
}

/*static void Format_And_Mount_Slave_Filesystem(void)
{
	if (Format(SLAVE_DEVICE,"gosfs") != 0)
	Print("Failed to format /" SLAVE_DEVICE "\n");
    else
	Print("Successfully formated /" SLAVE_DEVICE "\n");
	
	if (Mount(SLAVE_DEVICE, SLAVE_PREFIX, "gosfs") != 0)
	Print("Failed to mount /" SLAVE_PREFIX " filesystem\n");
    else
	Print("Mounted /" SLAVE_PREFIX " filesystem!\n");
}*/

static void Spawn_Init_Process(void)
{
	struct Kernel_Thread *thread;
	
    Spawn(
    	INIT_PROGRAM,	//program
    	INIT_PROGRAM,	//command
    	&thread			//pThread
    );
}
