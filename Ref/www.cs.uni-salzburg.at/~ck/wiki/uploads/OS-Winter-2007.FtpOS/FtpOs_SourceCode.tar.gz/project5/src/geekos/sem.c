
#include <geekos/malloc.h>
#include <geekos/user.h>
#include <geekos/kthread.h>
#include <geekos/string.h>
#include <geekos/bitset.h>
#include <geekos/kassert.h>
#include <geekos/errno.h>
#include <geekos/sem.h>

//---------------------- private functions ---------------------------

//DEFINE_LIST(Wait_Thread_Queue, Kernel_Thread);
//IMPLEMENT_LIST(Wait_Thread_Queue, Kernel_Thread);

struct semaphor
{
	int semCounter;
	int threadCounter;
	char* semName;
	struct Thread_Queue waitingThreads;
};

struct semaphor semaphors[NR_OF_SEMAPHORS];

//---------------------- public functions ----------------------------

/*
 * 
 */
 void Init_Semaphors()
 {
 	int i;
 
 	Print("Initializing semaphors\n");
 	
 	for(i=0; i<NR_OF_SEMAPHORS; i++)
 	{
 		semaphors[i].semCounter = 0;
 		semaphors[i].threadCounter = 0;
 		semaphors[i].semName = NULL;
 		semaphors[i].waitingThreads.head = NULL;
 		semaphors[i].waitingThreads.tail = NULL;
 	}
 }

/*
 * 
 */
int sem_create(uint_t name, uint_t nameLength, uint_t initCount, struct Kernel_Thread* caller)
{
	int i;
	int freeSem = -1;
	
	//copy name from user space to kernel space
	char* semName = Malloc(nameLength + 1);
    Copy_From_User(semName, name, nameLength);
    *(semName + nameLength) = 0;

	//Print("DEBUG: sem_ceate(%s, %d)", semName, initCount);
	
    //search for semaphor (and save the next free semaphor, if sem does not exists)
    for(i=0; i< NR_OF_SEMAPHORS; i++)
    {
    	if(semaphors[i].semName == NULL)
    	{
    		if(freeSem < 0) //save the first free semaphor, not the last
    			freeSem = i;
    	}
    	else if(!strncmp(semaphors[i].semName, semName, MAX_SEM_NAME_LENGTH))
    	{
    		if(!Is_Bit_Set(caller->semaphorBitset, i))
    		{
    			semaphors[i].threadCounter ++;
    			Set_Bit(caller->semaphorBitset, i);
    		}
    		Free(semName);
    		//Print("; semaphor \"%s\" already exists: %d\n", semaphors[i].semName, i);
    		return i;
    	}
    }
    
    //semaphor with given name not found; create new
    if(freeSem >= 0)
    {
    	semaphors[freeSem].semName = semName;
    	semaphors[freeSem].semCounter = initCount;
    	semaphors[freeSem].threadCounter = 1;
    	
    	Set_Bit(caller->semaphorBitset, freeSem);
    }  
    
    //Print("; new semaphor \"%s\" created: %d\n", semName, freeSem);
	return freeSem;
}

/*
 * 
 */
int sem_p(int semId, struct Kernel_Thread* caller)
{
	if(semaphors[semId].semName == NULL || !Is_Bit_Set(caller->semaphorBitset, semId))
	{
		//Print("\nDEBUG: p(%s, %d) -> EINVALID\n", semaphors[semId].semName, semId);
		return EINVALID;
	}
	
	//Print("DEBUG: p(%s)", semaphors[semId].semName);
	
	while(true)
	{
		if(semaphors[semId].semCounter > 0)
		{
			semaphors[semId].semCounter --;
			break;
		}
		
		Wait(&semaphors[semId].waitingThreads);
	}
	
	//Print("; semCounter = %d\n", semaphors[semId].semCounter);
	return 0;
}

/*
 * 
 */
int sem_v(int semId, struct Kernel_Thread* caller)
{
	if(semaphors[semId].semName == NULL || !Is_Bit_Set(caller->semaphorBitset, semId))
	{
		//Print("\nDEBUG: p(%s, %d) -> EINVALID\n", semaphors[semId].semName, semId);
		return EINVALID;
	}
	//Print("DEBUG: v(%s)", semaphors[semId].semName);
	
	semaphors[semId].semCounter ++;
	Wake_Up(&semaphors[semId].waitingThreads);
	
	//Print("; semCounter = %d\n", semaphors[semId].semCounter);
	return 0;
}

/*
 * 
 */
int sem_destroy(int semId, struct Kernel_Thread* caller)
{
	if(semId < 0 || semId >= NR_OF_SEMAPHORS || semaphors[semId].semName == NULL || !Is_Bit_Set(caller->semaphorBitset, semId))
	{
		//Print("DEBUG: p(%s, %d) -> EINVALID\n", semaphors[semId].semName, semId);
		return EINVALID;
	}
	
	Clear_Bit(caller->semaphorBitset, semId);	
	semaphors[semId].threadCounter --;
	//Print("DEBUG: semaphor \"%s\" destroyed; %d threads left", semaphors[semId].semName, semaphors[semId].threadCounter);
	
	if(semaphors[semId].threadCounter == 0)
	{
		//Print("; semaphor freed\n");
		Free(semaphors[semId].semName);
		semaphors[semId].semName = NULL;
	}
	
	//Print("\n");
	return 0;
}
