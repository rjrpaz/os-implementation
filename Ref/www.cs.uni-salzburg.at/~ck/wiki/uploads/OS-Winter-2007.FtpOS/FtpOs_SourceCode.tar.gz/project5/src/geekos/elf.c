/*
 * ELF executable loading
 * Copyright (c) 2003, Jeffrey K. Hollingsworth <hollings@cs.umd.edu>
 * Copyright (c) 2003, David H. Hovemeyer <daveho@cs.umd.edu>
 * $Revision: 1.29 $
 * 
 * This is free software.  You are permitted to use,
 * redistribute, and modify it as specified in the file "COPYING".
 */

#include <geekos/errno.h>
#include <geekos/kassert.h>
#include <geekos/ktypes.h>
#include <geekos/screen.h>  /* for debug Print() statements */
#include <geekos/pfat.h>
#include <geekos/malloc.h>
#include <geekos/string.h>
#include <geekos/user.h>
#include <geekos/fileio.h>
#include <geekos/elf.h>

#define ET_EXEC		2
#define EM_386		3

/**
 * From the data of an ELF executable, determine how its segments
 * need to be loaded into memory.
 * @param exeFileData buffer containing the executable file
 * @param exeFileLength length of the executable file in bytes
 * @param exeFormat structure describing the executable's segments
 *   and entry address; to be filled in
 * @return 0 if successful, < 0 on error
 */
int Parse_ELF_Executable(
	char *exeFileData,
	ulong_t exeFileLength,
    struct Exe_Format *exeFormat)
{	
	//var declaration
	int i;
	
	//map an elfHeader to the exeFileData
	elfHeader* eh = (elfHeader*) exeFileData;
	//check the elf-identification
	if(eh->ident[0] != 0x7F && 
			eh->ident[1] != 'E' &&
			eh->ident[2] != 'L' &&
			eh->ident[3] != 'F')
	{
		//TODO is it necessary, that the other bytes are checked too?
		Print("\nnot an executable file\n");
		return ENOEXEC;
	}
	if(eh->ident[4] == 0 ||
			eh->ident[4] == 2)
	{
		Print("\ninvalid class or 64bit object\n");
		return ENOEXEC;
	}
	
	//check header for correct data
	if(eh->type != ET_EXEC)
	{ //executable type - first we only implement exec files
		Print("\nunimplemented executable type: %d\n", eh->type);
		return ENOEXEC;
	}
	if(eh->machine != EM_386)
	{ //machine type - we implement this on x86 machines
		Print("\nunsupported machine type: %d\n", eh->machine);
		return ENOEXEC;
	}
	
	//fill in data to exeFormat
	//- set nr. of exeSegments
	exeFormat->numSegments = eh->phnum;
	//- set the entry address
	exeFormat->entryAddr = eh->entry;
	//- get exeSegments
	if(eh->phoff == 0)
	{
		Print("\nno program header available\n");
		return ENOEXEC;
	}
	
	int nextProgramHeaderOffset = (eh->phoff);
	for(i=0; i<eh->phnum; i++)
	{
		if(i >= EXE_MAX_SEGMENTS)
		{ //the number of segments must be less or equals the maximum numbers set for the exeFormat
			Print("\nmaximum number of segments exceeded\n");
			return ENOEXEC;
		}
		
		//map the programHeader to the exeFileData
		programHeader* ph = (programHeader*) (exeFileData+nextProgramHeaderOffset);
	
		//fill in the sections in the exeFormat
		(exeFormat->segmentList[i]).offsetInFile = ph->offset;
		(exeFormat->segmentList[i]).lengthInFile = ph->fileSize;
		(exeFormat->segmentList[i]).startAddress = ph->vaddr;
		(exeFormat->segmentList[i]).sizeInMemory = ph->memSize;
		(exeFormat->segmentList[i]).protFlags	 = ph->flags;
		
		//get the address of the next programHeader
		nextProgramHeaderOffset += eh->phentsize;
	}
	
    return 0;
}

