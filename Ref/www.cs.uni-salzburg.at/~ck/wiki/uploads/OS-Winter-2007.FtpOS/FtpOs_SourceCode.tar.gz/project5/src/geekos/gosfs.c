/*
 * GeekOS file system
 * Copyright (c) 2004, David H. Hovemeyer <daveho@cs.umd.edu>
 * $Revision: 1.54 $
 *
 * This is free software.  You are permitted to use,
 * redistribute, and modify it as specified in the file "COPYING".
 */

#include <limits.h>
#include <geekos/errno.h>
#include <geekos/kassert.h>
#include <geekos/screen.h>
#include <geekos/malloc.h>
#include <geekos/string.h>
#include <geekos/bitset.h>
#include <geekos/synch.h>
#include <geekos/bufcache.h>
#include <geekos/gosfs.h>
#include <geekos/blockdev.h>
#include <geekos/bitset.h>
#include <geekos/bufcache.h>
#include <geekos/mem.h>

/* ----------------------------------------------------------------------
 * Private data and functions
 * ---------------------------------------------------------------------- */
 
 int debugGOSFS = 0;
#define Debug(args...) if (debugGOSFS) Print("GOSFS: " args)
#define Println(args...) Print(args); Print("\n");

struct GOSFS_File 
{
	uint_t dirBlock;
	uint_t offset;
};

/*
 * In-memory information describing a mounted PFAT filesystem.
 * This is kept in the fsInfo field of the Mount_Point.
 */
struct GOSFS_Instance
{
    struct GOSFS_SuperBlock *superBlock;
    struct FS_Buffer_Cache *bufferCache;
};
/*
//method to print out errorType
void PrintError(int i){	
	switch(i) {
      case EUNSPECIFIED: Print("Unspecified error\n");
              break;
      case ENOTFOUND: Print("No such file or directory\n");
              break;
      case EUNSUPPORTED: Print("Operation not supported\n");
              break;
      case ENODEV: Print("No such device\n");
              break;
      case EIO: Print("Input/output error\n");
              break;
      case EBUSY: Print("Resource in use\n");
              break;
      case ENOMEM: Print("Out of memory\n");
              break;
      case ENOFILESYS: Print("No such filesystem\n");
              break;
      case ENAMETOOLONG: Print("Name too long\n");
              break;
      case EINVALIDFS: Print("Invalid format for filesystem\n");
              break;
      case EACCESS: Print("Permission denied\n");
              break;
      case EINVALID: Print("Invalid argument\n");
              break;
      case EMFILE: Print("File descriptor table full\n");
              break;
      case ENOTDIR: Print("Not a directory\n");
              break;
      case EEXIST: Print("File or directory already exists\n");
              break;
      case ENOSPACE: Print("Out of space on device\n");
              break;
      case EPIPE: Print("Pipe has no reader\n");
              break;
      case ENOEXEC: Print("Invalid executable format\n");
              break;              
      }      
}

static void printSuperBlock(struct FS_Buffer_Cache *bufferCache){
		
    struct FS_Buffer *superBlockBuffer = 0;
    struct GOSFS_SuperBlock superBlock;   
    int returnCode;       
	
	//Get buffer for superblock		
	returnCode = Get_FS_Buffer(bufferCache, GOSFS_SUPERBLOCK_BLOCKNR, &superBlockBuffer);
    KASSERT(returnCode == 0);
    
    //Get superblock
    memcpy(&superBlock, superBlockBuffer->data, sizeof(superBlock));    
    
    //print superblock
    Println("------------------Printing SuperBlock----------------");   
    Print("Magic: %s\n", superBlock.magic);
    Print("RootDirPointer: %ld\n", superBlock.rootDirPointer);
    Print("Size: %d\n", superBlock.size);
    Println("Bitmap:");
    int i;
	for(i = 0; i < superBlock.size; i++){
		Print("%d", Is_Bit_Set(superBlock.blockBitmap, i));
	}
	Print("\n");		
	Print("--------------------------------------------------------\n");
	
	//release buffer
	returnCode = Release_FS_Buffer(bufferCache, superBlockBuffer);
	KASSERT(returnCode == 0);	
}*/
/*
static void printRootDir(struct FS_Buffer_Cache *bufferCache){   
    
    struct FS_Buffer *rootDirBuffer = 0;
    struct GOSFS_Dir_Entry rootDirectory[GOSFS_DIR_ENTRIES_PER_BLOCK];      
    int returnCode;       
    
    //Get buffer for rootDir		
	returnCode = Get_FS_Buffer(bufferCache, GOSFS_ROOTDIR_BLOCKNR, &rootDirBuffer);
    KASSERT(returnCode == 0);
    
    //Get rootDir
    memcpy(rootDirectory, rootDirBuffer->data, sizeof(rootDirectory));    
    
    //print rootDir
    Print("--------------------Printing RootDir--------------------\n");       
    int i;		
    int j;
	for(i = 0; i < GOSFS_DIR_ENTRIES_PER_BLOCK; i++){
		Print("Nr: %d | Size: %ld | Used: %d | Directory: %d | Filename: %s\n"
		,i
		,rootDirectory[i].size
		,((rootDirectory[i].flags & GOSFS_DIRENTRY_USED) == GOSFS_DIRENTRY_USED)
		,((rootDirectory[i].flags & GOSFS_DIRENTRY_ISDIRECTORY) == GOSFS_DIRENTRY_ISDIRECTORY)
		,rootDirectory[i].filename);
		Print("Blocklist: ");		
		for(j = 0; j < GOSFS_NUM_BLOCK_PTRS; j++){
			Print("%ld, ", rootDirectory[i].blockList[j]);
		}
		Print("\n");
	}
	Print("--------------------------------------------------------\n");
	Print("\n");  
	
	//release buffer
	returnCode = Release_FS_Buffer(bufferCache, rootDirBuffer);
	KASSERT(returnCode == 0);		
}*/
/*
static void printDirEntries(struct FS_Buffer_Cache *bufferCache, int blockNum){   
    
    struct FS_Buffer *rootDirBuffer = 0;
    struct GOSFS_Dir_Entry rootDirectory[GOSFS_DIR_ENTRIES_PER_BLOCK];      
    int returnCode;       
    
    //Get buffer for rootDir		
	returnCode = Get_FS_Buffer(bufferCache, blockNum, &rootDirBuffer);
    KASSERT(returnCode == 0);
    
    //Get rootDir
    memcpy(rootDirectory, rootDirBuffer->data, sizeof(rootDirectory));    
    
    //print rootDir
    Print("-----------Printing DirEntries from Block %d-----------\n", blockNum);       
    int i;		
    int j;
	for(i = 0; i < GOSFS_DIR_ENTRIES_PER_BLOCK; i++){
		Print("Nr: %d | Size: %ld | Used: %d | Directory: %d | Filename: %s\n"
		,i
		,rootDirectory[i].size
		,((rootDirectory[i].flags & GOSFS_DIRENTRY_USED) == GOSFS_DIRENTRY_USED)
		,((rootDirectory[i].flags & GOSFS_DIRENTRY_ISDIRECTORY) == GOSFS_DIRENTRY_ISDIRECTORY)
		,rootDirectory[i].filename);
		Print("Blocklist: ");		
		for(j = 0; j < GOSFS_NUM_BLOCK_PTRS; j++){
			Print("%ld, ", rootDirectory[i].blockList[j]);
		}
		Print("\n");
	}
	Print("--------------------------------------------------------\n");
	Print("\n");  
	
	//release buffer
	returnCode = Release_FS_Buffer(bufferCache, rootDirBuffer);
	KASSERT(returnCode == 0);		
}
*/
void split(char **pathName, char** fileName, const char *path)
{
	(*fileName) = strdup(strrchr(path, '/'));
	(*fileName) ++;

	(*pathName) = strdup(path);
	(*pathName)[strlen(path) - strlen(*fileName) - 1] = 0;
}

int isNameAssigned(struct GOSFS_Instance *instance, ulong_t dirBlock, const char *dirName){
	
	struct FS_Buffer *dirBuffer = 0;
	struct GOSFS_Dir_Entry *dirEntry = 0;
	int returnCode;
	
	//Allocate space for arrays
	dirEntry = (struct GOSFS_Dir_Entry *)Malloc(GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));
	
	//get buffer	
	if((returnCode = Get_FS_Buffer(instance->bufferCache, dirBlock, &dirBuffer)) != 0)
	{
		Free(dirEntry);		
		return returnCode;
	}		
	
	//read dir entry	
	memcpy(dirEntry, dirBuffer->data, GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));	
	Release_FS_Buffer(instance->bufferCache, dirBuffer);		
	
	//iterate through directory to see if name already exists	
	int i;
	for(i = 0; i<GOSFS_DIR_ENTRIES_PER_BLOCK; i++)
	{	
		if((dirEntry[i].flags & GOSFS_DIRENTRY_USED) == 1){
			if(!(strcmp(dirEntry[i].filename, dirName))){
				Free(dirEntry);		
				return -1;
			}
		}			
	}	
	Free(dirEntry);		
	return 0;
}

int createDir(struct GOSFS_Instance *instance, ulong_t dirBlock, const char *dirName) 
{		
	int offset;
	int returnCode;
	int bitNumber;	
	struct GOSFS_Dir_Entry *directory = 0;	
	struct FS_Buffer *buffer = 0;	
	
	//Allocate space for arrays	
	directory = (struct GOSFS_Dir_Entry *)Malloc(GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));
		
	//get buffer for directory	
	if((returnCode = Get_FS_Buffer(instance->bufferCache, dirBlock, &buffer)) != 0)
	{		
		Free(directory);		
		return returnCode;
	}		
	
	//read directory	
	memcpy(directory, buffer->data, GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));	
	
	//find the right entry	
	for(offset = 0; offset<GOSFS_DIR_ENTRIES_PER_BLOCK; offset++)
	{	
		if((directory[offset].flags & GOSFS_DIRENTRY_USED) != GOSFS_DIRENTRY_USED)
			break;
	}
	
	if(offset >= GOSFS_DIR_ENTRIES_PER_BLOCK)
	{		
		Free(directory);
		Release_FS_Buffer(instance->bufferCache, buffer);		
		return EMFILE;
	}
	
	//get free block from blockbitmap	
	if((bitNumber = Find_First_Free_Bit(instance->superBlock->blockBitmap, instance->superBlock->size)) == -1)
	{		
		Free(directory);
		Release_FS_Buffer(instance->bufferCache, buffer);		
		return ENOMEM;
	}		
	
	Debug("empty slot found at %d. creating directory\n", offset);
	
	//updating dir entry	
	directory[offset].size = 0;	
	strcpy(directory[offset].filename, dirName);	
	directory[offset].blockList[0] = bitNumber;
	//setting flags
	directory[offset].flags = 0;
	directory[offset].flags |= GOSFS_DIRENTRY_USED;
	directory[offset].flags |= GOSFS_DIRENTRY_ISDIRECTORY;	
	//setting permissions
	directory[offset].acl[0].uid = 0;
	directory[offset].acl[0].permission = O_CREATE | O_READ | O_WRITE | O_EXCL;
	
	//write back dirEntry
	memcpy(buffer->data, directory, GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));
	Modify_FS_Buffer(instance->bufferCache, buffer);
	Sync_FS_Buffer(instance->bufferCache, buffer);
	Release_FS_Buffer(instance->bufferCache, buffer);	
	
	//get buffer for new directory block
	if((returnCode = Get_FS_Buffer(instance->bufferCache, bitNumber, &buffer)) != 0)
	{		
		Free(directory);		
		Release_FS_Buffer(instance->bufferCache, buffer);
		return returnCode;
	}		
	
	//clean up new directory
	memset( directory, '\0', GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));
	
	//write new directory to disk and release buffer
	memcpy(buffer->data, directory, GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));	
	Modify_FS_Buffer(instance->bufferCache, buffer);
	Sync_FS_Buffer(instance->bufferCache, buffer);
	Release_FS_Buffer(instance->bufferCache, buffer);		
	
	//updating bitmap
	Set_Bit(instance->superBlock->blockBitmap, bitNumber);
		
	//get buffer for superblock
	if((returnCode = Get_FS_Buffer(instance->bufferCache, GOSFS_SUPERBLOCK_BLOCKNR, &buffer)) != 0)
	{		
		Free(directory);
		Release_FS_Buffer(instance->bufferCache, buffer);		
		return returnCode;
	}
	
	//write back superBlock
	memcpy(buffer->data, instance->superBlock, sizeof(*instance->superBlock));
	Modify_FS_Buffer(instance->bufferCache, buffer);
	Sync_FS_Buffer(instance->bufferCache, buffer);
	Release_FS_Buffer(instance->bufferCache, buffer);
		
	//free allocated memory	
	Free(directory);
	
	Debug("directory successfully created in block %d\n", bitNumber);
	return 0;	
}	

int findInDir(struct GOSFS_Instance *instance, ulong_t dirBlock, const char *fileName, int searchDir)
{
	
    Debug("findInDir BlockNr %ld with name %s and is dir %d\n", dirBlock, fileName, searchDir);    
   
	
	int offset;
	int returnCode = 0;
	struct FS_Buffer *dirBuffer = 0;
	struct GOSFS_Dir_Entry *dirEntry = (struct GOSFS_Dir_Entry*)Malloc(GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));
	
	//get buffer to read directory entry
	if((returnCode = Get_FS_Buffer(instance->bufferCache, dirBlock, &dirBuffer)) != 0)
		return returnCode;
	memcpy(dirEntry,dirBuffer->data, GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));
	Release_FS_Buffer(instance->bufferCache, dirBuffer);	
	
	//find the right entry
	for(offset = 0; offset<GOSFS_DIR_ENTRIES_PER_BLOCK; offset++)
	{			
		if((searchDir && (((dirEntry[offset]).flags & GOSFS_DIRENTRY_ISDIRECTORY) == GOSFS_DIRENTRY_ISDIRECTORY))
			|| (!searchDir && !((dirEntry[offset].flags & GOSFS_DIRENTRY_ISDIRECTORY) == GOSFS_DIRENTRY_ISDIRECTORY)))
		{			
			if(((dirEntry[offset].flags & GOSFS_DIRENTRY_USED) == GOSFS_DIRENTRY_USED) && !(strcmp(fileName, dirEntry[offset].filename)))
			{
				Debug("entry found\n");
				//Free(dirEntry);
				return offset;
			}
		}
	}
	
	Debug("entry not found\n");
	//Free(dirEntry);
	return -1;
}

int createFile(struct Block_Device *dev, struct GOSFS_Instance *instance, ulong_t dirBlock, const char *fileName) 
{
	int offset;
	int returnCode = 0;
	struct FS_Buffer *dirBuffer = 0;
	struct FS_Buffer *superBlockBuffer = 0;
	struct GOSFS_Dir_Entry dirEntry[GOSFS_DIR_ENTRIES_PER_BLOCK];
	
	//get buffer to read directory entry
	if((returnCode = Get_FS_Buffer(instance->bufferCache, dirBlock, &dirBuffer)) != 0)
		return returnCode;
	memcpy(dirEntry, dirBuffer->data, sizeof(dirEntry));
	
	//find the right entry
	for(offset = 0; offset<GOSFS_DIR_ENTRIES_PER_BLOCK; offset++)
	{	
		if((dirEntry[offset].flags & GOSFS_DIRENTRY_USED) == 0)
			break;
	}
	
	if(offset >= GOSFS_DIR_ENTRIES_PER_BLOCK)
	{
		Release_FS_Buffer(instance->bufferCache, dirBuffer);
		return EMFILE;
	}
	
	Debug("empty slot found at %d. creating file\n", offset);
	dirEntry[offset].size = 0;
	strcpy(dirEntry[offset].filename, fileName);
	//setting the first block of this file
	int bitNumber = Find_First_Free_Bit(instance->superBlock->blockBitmap, Get_Num_Blocks(dev));
	Set_Bit(instance->superBlock->blockBitmap, bitNumber);
	dirEntry[offset].blockList[0] = bitNumber; 
	//setting the flags
	dirEntry[offset].flags = 0;
	dirEntry[offset].flags |= GOSFS_DIRENTRY_USED;
	//setting permissions
	dirEntry[offset].acl[0].uid = 0;
	dirEntry[offset].acl[0].permission = O_CREATE | O_READ | O_WRITE | O_EXCL;
	
	Debug("write back superBlock\n");
	if((returnCode = Get_FS_Buffer(instance->bufferCache, GOSFS_SUPERBLOCK_BLOCKNR, &superBlockBuffer)) != 0)
		return returnCode;
	memcpy(superBlockBuffer->data, instance->superBlock, sizeof(*instance->superBlock));
	Modify_FS_Buffer(instance->bufferCache, superBlockBuffer);
	Sync_FS_Buffer(instance->bufferCache, superBlockBuffer);
	Release_FS_Buffer(instance->bufferCache, superBlockBuffer);
	
	Debug("write back dirEntry\n");
	memcpy(dirBuffer->data, dirEntry, sizeof(dirEntry));
	Modify_FS_Buffer(instance->bufferCache, dirBuffer);
	Sync_FS_Buffer(instance->bufferCache, dirBuffer);
	Release_FS_Buffer(instance->bufferCache, dirBuffer);
	
	Debug("file successfully created\n");
	return offset;
}	

struct GOSFS_File* GOSFS_Lookup(struct GOSFS_Instance *instance, const char *path)
{	
	struct GOSFS_File *file = 0;		
	struct GOSFS_Dir_Entry *directory = 0;
	struct FS_Buffer *buffer = 0;	
	char *pathName =0;
	char *dirName = 0;
	int offset;
	int returnCode;
	
	//Allocate space for arrays	
	directory = (struct GOSFS_Dir_Entry *)Malloc(GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));
			
	Debug("creating gosfs file descriptor\n");
    file = (struct GOSFS_File*)Malloc(sizeof(*file));
    if (file == 0)
    	return 0;
    	
    file->dirBlock = GOSFS_ROOTDIR_BLOCKNR;
    
    Debug("search for directory\n");	

    //Special case: root directory.
    if (strcmp(path, "") == 0)
	{
		file->dirBlock = instance->superBlock->rootDirPointer;
		return file;
	}
    
    //else search correct dir entry	
	pathName = strdup(path);
	dirName = 0;	
	while(strcmp(pathName, "") != 0){
		if(strcmp(strchr(pathName, '/'),strrchr(pathName,'/'))){
			dirName = strdup(strchr(pathName, '/') + 1);
			dirName[strlen(dirName) - strlen(strchr(dirName, '/'))] = 0;
			pathName = strchr(pathName, '/') + 1;			
			
		}else{
			dirName = strdup(strchr(pathName, '/') + 1);
			pathName = "";				
		}	
		
		//find entry in current directory
		if((offset = findInDir(instance, file->dirBlock, dirName, 1)) == -1){
			//Debug("%s\n", Get_Error_String(ENOTFOUND));
			return 0;
		}
		
		
		//get buffer for directory		
		if((returnCode = Get_FS_Buffer(instance->bufferCache, file->dirBlock, &buffer)) != 0)
		{		
			Free(directory);
			//Debug("%s\n", Get_Error_String(returnCode));		
			return 0;
		}		
		
		//read directory		
		memcpy(directory, buffer->data, GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));
		Release_FS_Buffer(instance->bufferCache, buffer);
		file->dirBlock = directory[offset].blockList[0];				
	}
		
	//TODO("implementieren, wenn create directory fertig ist");
    
    return file;
}

/* ----------------------------------------------------------------------
 * Implementation of VFS operations
 * ---------------------------------------------------------------------- */

/*
 * Get metadata for given file.
 */
static int GOSFS_FStat(struct File *file, struct VFS_File_Stat *stat)
{
    //TODO("GeekOS filesystem FStat operation");
    return 0;
}

/*
 * Read data from current position in file.
 */
static int GOSFS_Read(struct File *file, void *buf, ulong_t numBytes)
{
        
    //TODO("GeekOS filesystem read operation");
    struct GOSFS_Dir_Entry *directory = 0;	
	struct FS_Buffer *buffer = 0;
	struct GOSFS_File *fileInfo = 0;
	struct GOSFS_Instance *instance = 0;
	int returnCode;	
	int currentBlock = -1;	
	char *blockData = 0;	
	char *output = 0;
	
    
    //check permission
    if((file->mode & O_READ) != O_READ){
    	return EACCESS;
    } 
    
    //get instance
    instance = file->mountPoint->fsData;
    
    //get fileInfo
    fileInfo = file->fsData;  
        
    //check if filelength is not exceeded
    if((file->endPos + numBytes) > (GOSFS_FS_BLOCK_SIZE * GOSFS_NUM_BLOCK_PTRS)){
    	return EMFILE;
    }    
	
	//Allocate space for array and blockData
	directory = (struct GOSFS_Dir_Entry *)Malloc(GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));
	blockData = (char *)Malloc(GOSFS_FS_BLOCK_SIZE);	
	output = (char *)Malloc(numBytes);	
	
			
	//get buffer for directory	
	if((returnCode = Get_FS_Buffer(instance->bufferCache, fileInfo->dirBlock, &buffer)) != 0)
	{		
		Free(directory);		
		Free(blockData);		
		return returnCode;
	}		
	
	//read directory and release buffer	
	memcpy(directory, buffer->data, GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));	
	Release_FS_Buffer(instance->bufferCache, buffer);	
	
	//get current block
	int i;
	for(i = GOSFS_NUM_BLOCK_PTRS - 1; i >= 0; i--){
		if(directory[fileInfo->offset].blockList[i] != 0){
			currentBlock = directory[fileInfo->offset].blockList[i];
			break;
		}
	}	
	if(currentBlock == -1)
		return ENOTFOUND;   
    
    //get buffer for currentBlock
    if((returnCode = Get_FS_Buffer(instance->bufferCache, currentBlock, &buffer)) != 0)
	{		
		Free(directory);		
		Free(blockData);		
		return returnCode;
	}	
	
	//copy data to blockData
	memcpy(blockData, buffer->data, GOSFS_FS_BLOCK_SIZE);
	Release_FS_Buffer(instance->bufferCache, buffer);
	
	//read data from blockdata
	if(file->filePos + numBytes > GOSFS_FS_BLOCK_SIZE){	
		/*
		//get number of Blocks needed		
		int numBlocks = (numBytes - 1) / GOSFS_FS_BLOCK_SIZE + 1;
		if(file->filePos != 0)
			numBlocks++;				
		
		//loop for reading file from disk
		int j;
		int k = 0;
		for(i = 0; i < numBlocks; i++){
			for(j = file->filePos; j < GOSFS_FS_BLOCK_SIZE; j++, k++){
				if((i == numBlocks - 1) && (numBytes - k == 0)){					
					break;					
				}					
				output[k] = blockData[j];				
			}					
			
			//only allocate new block if needed
			if(i < numBlocks - 1){
				//get new block to write to			
			currentBlock = Find_First_Free_Bit(instance->superBlock->blockBitmap, instance->superBlock->size);
						
			//update GOSFS_Dir_Entry and Superblock
			//1 superblock
			//get buffer for superblock
			if((returnCode = Get_FS_Buffer(instance->bufferCache, GOSFS_SUPERBLOCK_BLOCKNR, &buffer)) != 0)
			{		
				Free(directory);		
				Free(blockData);		
				return returnCode;
			}	
			
			//update superblock
			Set_Bit(instance->superBlock->blockBitmap, currentBlock);
			
			//write superblock to disk and release buffer
			memcpy(buffer->data, instance->superBlock, sizeof(*instance->superBlock));
			Modify_FS_Buffer(instance->bufferCache, buffer);
			Sync_FS_Buffer(instance->bufferCache, buffer);
			Release_FS_Buffer(instance->bufferCache, buffer);
			
			//2 Gosfs_dir_entry
			//get buffer for dir entry
			if((returnCode = Get_FS_Buffer(instance->bufferCache, fileInfo->dirBlock, &buffer)) != 0)
			{		
				Free(directory);		
				Free(blockData);		
				return returnCode;
			}		
			
			//get correct blockList entry
			int x = 0;
			while(directory[fileInfo->offset].blockList[x] != 0)
				x++;
			
			if(x >= GOSFS_NUM_BLOCK_PTRS){
				return EMFILE;
			}
			
			//update dir entry
			directory[fileInfo->offset].blockList[x] = currentBlock;
			directory[fileInfo->offset].size = file->endPos + numBytes;
			
			//write directory to disk and release buffer			
			memcpy(buffer->data, directory, GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));	
			Modify_FS_Buffer(instance->bufferCache, buffer);
			Sync_FS_Buffer(instance->bufferCache, buffer);
			Release_FS_Buffer(instance->bufferCache, buffer);
			
			
			//get buffer for new block
			if((returnCode = Get_FS_Buffer(instance->bufferCache, currentBlock, &buffer)) != 0)
			{		
				Free(directory);		
				Free(blockData);		
				return returnCode;
			}	
			
			//reset blockData
			memset( blockData, '\0', GOSFS_FS_BLOCK_SIZE);
			
			
			//update filePos
			file->filePos = 0;	
			}
			
					
		}*/
		
	}else{		
		//write output to buffer		
		//file->filePos = 0;
		memcpy(buf, blockData + file->filePos, numBytes);		
	}    
    
    //free allocated data
    Free(directory);
    Free(blockData);       
    
    return numBytes;   
}

/*
 * Write data to current position in file.
 */
static int GOSFS_Write(struct File *file, void *buf, ulong_t numBytes)
{
    struct GOSFS_Dir_Entry *directory = 0;	
	struct FS_Buffer *buffer = 0;
	struct GOSFS_File *fileInfo = 0;
	struct GOSFS_Instance *instance = 0;
	int returnCode;	
	int currentBlock = -1;	
	char *blockData = 0;	
	char *input = 0;    
    
    //check permission
    if((file->mode & O_WRITE) != O_WRITE){
    	return EACCESS;
    } 
    
    //get instance
    instance = file->mountPoint->fsData;
    
    //get fileInfo
    fileInfo = file->fsData;  
        
    //check if filelength is not exceeded
    if((file->endPos + numBytes) > (GOSFS_FS_BLOCK_SIZE * GOSFS_NUM_BLOCK_PTRS)){
    	return EMFILE;
    }    
	
	//Allocate space for array and blockData
	directory = (struct GOSFS_Dir_Entry *)Malloc(GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));
	blockData = (char *)Malloc(GOSFS_FS_BLOCK_SIZE);	
	input = (char *)Malloc(numBytes);	
	
	//get input
	input = (char *) buf;	
	
	//get buffer for directory	
	if((returnCode = Get_FS_Buffer(instance->bufferCache, fileInfo->dirBlock, &buffer)) != 0)
	{		
		Free(directory);		
		Free(blockData);		
		return returnCode;
	}		
	
	//read directory and release buffer	
	memcpy(directory, buffer->data, GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));	
	Release_FS_Buffer(instance->bufferCache, buffer);	
	
	//get current block
	int i;
	for(i = GOSFS_NUM_BLOCK_PTRS - 1; i >= 0; i--){
		if(directory[fileInfo->offset].blockList[i] != 0){
			currentBlock = directory[fileInfo->offset].blockList[i];
			break;
		}
	}	
	if(currentBlock == -1)
		return ENOTFOUND;    
    
    //get buffer for currentBlock
    if((returnCode = Get_FS_Buffer(instance->bufferCache, currentBlock, &buffer)) != 0)
	{		
		Free(directory);		
		Free(blockData);		
		return returnCode;
	}	
	
	//copy existing data to blockData
	memcpy(blockData, buffer->data, GOSFS_FS_BLOCK_SIZE);
	
	//write data to blockdata
	if(file->filePos + numBytes > GOSFS_FS_BLOCK_SIZE){
		//implement on the fly allocation of new block
		//get number of Blocks needed		
		int numBlocks = (numBytes - 1) / GOSFS_FS_BLOCK_SIZE + 1;
		if(file->filePos != 0)
			numBlocks++;				
		
		//loop for writing file to disk
		int j;
		int k = 0;
		for(i = 0; i < numBlocks; i++){
			for(j = file->filePos; j < GOSFS_FS_BLOCK_SIZE; j++, k++){
				if((i == numBlocks - 1) && (numBytes - k == 0)){					
					break;					
				}					
				blockData[j] = input[k];				
			}			
			
			//write current block back to disk
			memcpy(buffer->data, blockData, GOSFS_FS_BLOCK_SIZE);
			Modify_FS_Buffer(instance->bufferCache, buffer);
			Sync_FS_Buffer(instance->bufferCache, buffer);
			Release_FS_Buffer(instance->bufferCache, buffer);
			
			//only allocate new block if needed
			if(i < numBlocks - 1){
				//get new block to write to			
			currentBlock = Find_First_Free_Bit(instance->superBlock->blockBitmap, instance->superBlock->size);
						
			//update GOSFS_Dir_Entry and Superblock
			//1 superblock
			//get buffer for superblock
			if((returnCode = Get_FS_Buffer(instance->bufferCache, GOSFS_SUPERBLOCK_BLOCKNR, &buffer)) != 0)
			{		
				Free(directory);		
				Free(blockData);		
				return returnCode;
			}	
			
			//update superblock
			Set_Bit(instance->superBlock->blockBitmap, currentBlock);
			
			//write superblock to disk and release buffer
			memcpy(buffer->data, instance->superBlock, sizeof(*instance->superBlock));
			Modify_FS_Buffer(instance->bufferCache, buffer);
			Sync_FS_Buffer(instance->bufferCache, buffer);
			Release_FS_Buffer(instance->bufferCache, buffer);
			
			//2 Gosfs_dir_entry
			//get buffer for dir entry
			if((returnCode = Get_FS_Buffer(instance->bufferCache, fileInfo->dirBlock, &buffer)) != 0)
			{		
				Free(directory);		
				Free(blockData);		
				return returnCode;
			}		
			
			//get correct blockList entry
			int x = 0;
			while(directory[fileInfo->offset].blockList[x] != 0)
				x++;
			
			if(x >= GOSFS_NUM_BLOCK_PTRS){
				return EMFILE;
			}
			
			//update dir entry
			directory[fileInfo->offset].blockList[x] = currentBlock;
			directory[fileInfo->offset].size = file->endPos + numBytes;
			
			//write directory to disk and release buffer			
			memcpy(buffer->data, directory, GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));	
			Modify_FS_Buffer(instance->bufferCache, buffer);
			Sync_FS_Buffer(instance->bufferCache, buffer);
			Release_FS_Buffer(instance->bufferCache, buffer);
			
			
			//get buffer for new block
			if((returnCode = Get_FS_Buffer(instance->bufferCache, currentBlock, &buffer)) != 0)
			{		
				Free(directory);		
				Free(blockData);		
				return returnCode;
			}	
			
			//reset blockData
			memset( blockData, '\0', GOSFS_FS_BLOCK_SIZE);
			
			
			//update filePos
			file->filePos = 0;	
			}
					
		}
		
	}else{
		for(i = 0; i < numBytes;i++){
			blockData[file->filePos + i] = input[i];
		}		
		//write data back to disk
   		memcpy(buffer->data, blockData, GOSFS_FS_BLOCK_SIZE);
   		Modify_FS_Buffer(instance->bufferCache, buffer);
		Sync_FS_Buffer(instance->bufferCache, buffer);
		Release_FS_Buffer(instance->bufferCache, buffer);	
		
		//update fileinfos		
		file->endPos = file->endPos + numBytes;	
		file->filePos = file->filePos + numBytes;
		//TODO update GOSFS_DIR_ENTRY
		directory[fileInfo->offset].size = file->endPos;
		
		// write dirEntry back to disk
		if((returnCode = Get_FS_Buffer(instance->bufferCache, fileInfo->dirBlock, &buffer)) != 0)
		{		
			Free(directory);		
			Free(blockData);		
			return returnCode;
		}				
		memcpy(buffer->data, directory, GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));	
		Modify_FS_Buffer(instance->bufferCache, buffer);
		Sync_FS_Buffer(instance->bufferCache, buffer);
		Release_FS_Buffer(instance->bufferCache, buffer);	
	}    
    
    //free allocated data
    Free(directory);
    Free(blockData);    
       
    return numBytes;   
}

/*
 * Seek to a position in file.
 */
static int GOSFS_Seek(struct File *file, ulong_t pos)
{
    //TODO("GeekOS filesystem seek operation");
    return 0;
}

/*
 * Close a file.
 */
static int GOSFS_Close(struct File *file)
{
	
	
	Debug("closing file\n");
	Free(file->fsData);
	
	file->fsData = 0;
	file->ops = 0;
	file->mountPoint = 0;
    
    //TODO freeing the empty file struct causes an error - why?
    //Free(file);
    Debug("file closed\n");
    
    return 0;
    
}

/*static*/ struct File_Ops s_gosfsFileOps = {
    &GOSFS_FStat,
    &GOSFS_Read,
    &GOSFS_Write,
    &GOSFS_Seek,
    &GOSFS_Close,
    0, /* Read_Entry */
};

/*
 * Stat operation for an already open directory.
 */
static int GOSFS_FStat_Directory(struct File *dir, struct VFS_File_Stat *stat)
{
    //TODO("GeekOS filesystem FStat directory operation");
    return 0;
}

/*
 * Directory Close operation.
 */
static int GOSFS_Close_Directory(struct File *dir)
{
    //TODO("GeekOS filesystem Close directory operation");
    return GOSFS_Close(dir);
}

/*
 * Read a directory entry from an open directory.
 */
static int GOSFS_Read_Entry(struct File *dir, struct VFS_Dir_Entry *entry)
{	
	int returnCode;
	struct GOSFS_Instance *instance = dir->mountPoint->fsData;
	struct GOSFS_Dir_Entry *dirEntry = (struct GOSFS_Dir_Entry*)Malloc(GOSFS_DIR_ENTRIES_PER_BLOCK * sizeof(*dirEntry));
	struct GOSFS_File *gosFile = 0;
	struct FS_Buffer *fileBuffer = 0;
	struct VFS_File_Stat *stat = 0;
    //TODO("GeekOS filesystem Read_Entry operation");
    
    gosFile = dir->fsData;
    if((returnCode = Get_FS_Buffer(instance->bufferCache, gosFile->dirBlock, &fileBuffer)) != 0)
    		return returnCode;    	
    		
	memcpy(dirEntry, fileBuffer->data, GOSFS_DIR_ENTRIES_PER_BLOCK * sizeof(struct GOSFS_Dir_Entry));
	
	while((dirEntry[dir->filePos].flags & GOSFS_DIRENTRY_USED) == 0 
		&& dir->filePos < dir->endPos)
	{
		dir->filePos ++;
	}
	if (dir->filePos >= dir->endPos)
	{
		Release_FS_Buffer(instance->bufferCache, fileBuffer);
		return VFS_NO_MORE_DIR_ENTRIES; /* Reached the end of the directory. */
	}
	
	strcpy(entry->name, dirEntry[dir->filePos].filename);
    stat = &(entry->stats);
	//stat->isSetuid = 0;
	stat->size = dirEntry[dir->filePos].size;
	stat->isDirectory = ((dirEntry[dir->filePos].flags & GOSFS_DIRENTRY_ISDIRECTORY) == GOSFS_DIRENTRY_ISDIRECTORY);    	
	//to begin in next entry
	dir->filePos ++;
	
	Release_FS_Buffer(instance->bufferCache, fileBuffer);
    Free(dirEntry);
    return 0;
}

/*static*/ struct File_Ops s_gosfsDirOps = {
    &GOSFS_FStat_Directory,
    0, /* Read */
    0, /* Write */
    0, /* Seek */
    &GOSFS_Close_Directory,
    &GOSFS_Read_Entry,
};

/*
 * Open a file named by given path.
 */
static int GOSFS_Open(struct Mount_Point *mountPoint, const char *path, int mode, struct File **pFile)
{
    //TODO("GeekOS filesystem open operation");
    int returnCode;
    int filePos = 0;	//virtual block 0
    int endPos = 0;		//virtual block 0
    char *fileName = 0;
    char *pathName = 0;
    struct GOSFS_Instance *instance = mountPoint->fsData;
    struct GOSFS_File *file = 0;      
    struct FS_Buffer *buffer = 0;	
    struct GOSFS_Dir_Entry *directory = 0;	
    directory = (struct GOSFS_Dir_Entry *)Malloc(GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));   
    
    split(&pathName, &fileName, path);
    
    Debug("-------------------------\n");
    Debug("Open file \"%s\" in path \"%s\"\n", fileName, pathName);
    if((mode & O_READ) != 0)
    	Debug("Mode = O_READ\n");
    if((mode & O_WRITE) != 0)
    	Debug("Mode = O_WRITE\n");
    if((mode & O_CREATE) != 0)
    	Debug("Mode = O_CREATE\n");
    if((mode & O_EXCL) != 0)
    	Debug("Mode = O_EXCL\n");
    Debug("-------------------------\n");
    
    // Reject attempts to create or write
    //if ((mode & (O_WRITE | O_CREATE)) == 0)
	//	return EACCESS;
    
    Debug("lookup for direcotry\n");   
    file = GOSFS_Lookup(instance, pathName);    
    if(file == 0)
    	return ENOTFOUND;        
    
    
    Debug("find file in directory\n");      
    returnCode = findInDir(instance, file->dirBlock, fileName, 0);    
    if(returnCode < 0)
    {//create a file
    	
    	if((mode & O_CREATE) == 0)
    		return EACCESS;    	   	    	
    	
    	returnCode = createFile(mountPoint->dev, instance, file->dirBlock, fileName);      	
    	    	
    	if(returnCode < 0)
    		return returnCode;
    		
    	file->offset = returnCode;
    }
    else
    {//file exists
    	file->offset = returnCode;
    	
    	if((returnCode = Get_FS_Buffer(instance->bufferCache, file->dirBlock, &buffer)) != 0)
		{		
			Free(directory);		
			return returnCode;
		}
		
		//read directory		
		memcpy(directory, buffer->data, GOSFS_DIR_ENTRIES_PER_BLOCK*sizeof(struct GOSFS_Dir_Entry));
		Release_FS_Buffer(instance->bufferCache, buffer);	
		endPos = directory[file->offset].size;
		//filePos = directory[file->offset].size % GOSFS_FS_BLOCK_SIZE;
    	
    }
    
    Debug("creating file descriptor\n");
    (*pFile) = Allocate_File(
    	&s_gosfsFileOps,
    	filePos,
    	endPos,
    	file,
    	mode,
    	mountPoint
    );    
    
    
    return 0;
}

/*
 * Create a directory named by given path.
 */
static int GOSFS_Create_Directory(struct Mount_Point *mountPoint, const char *path)
{
    //TODO free pathName and dirName
    int returnCode;
    struct GOSFS_Instance *instance = mountPoint->fsData;
    struct GOSFS_File *file = 0;
    char *dirName = 0;
    char *pathName = 0;
    
    //get path and directory name
    split(&pathName, &dirName, path);
    Debug("Create dir \"%s\" in path \"%s\"\n", dirName, pathName);    
	
	//search for correct directory
    file = GOSFS_Lookup(instance, pathName);     
    if(file == 0)
    	return ENOTFOUND;       
    
    //check if dir already exists in rootdir
    if((returnCode = isNameAssigned(instance, file->dirBlock, dirName)) != 0){
		//Debug("%s\n", Get_Error_String(EEXISTS));
		return EEXIST;
	}
	
	//create dir
	if((returnCode = createDir(instance, file->dirBlock, dirName)) != 0){
		//PrintError(returnCode);
		return returnCode;
	} 	
    return 0;    
}

/*
 * Open a directory named by given path.
 */
static int GOSFS_Open_Directory(struct Mount_Point *mountPoint, const char *path, struct File **pDir)
{
	struct GOSFS_File *gosFile;
	Debug("open directory: \"%s\"\n", path);
	
	if(!strcmp(path, "/"))
		gosFile = GOSFS_Lookup(mountPoint->fsData, "");
	else
		gosFile = GOSFS_Lookup(mountPoint->fsData, path);
	if(gosFile == 0)
		return ENOTFOUND;
		
	Debug("directory found; creating file\n");
	(*pDir) = Allocate_File(
		&s_gosfsDirOps, 
		0,								//filePos 
		GOSFS_DIR_ENTRIES_PER_BLOCK,	//endPos
		gosFile,						//fsData
		0,								//mode - wird vom vfs gesetzt 
		0								//mountPoint - wird vom vfs gesetzt
	);
	
	if((*pDir) == 0)
		return EUNSPECIFIED;
	
	Debug("finished openDirectory\n");
    return 0;    
}

/*
 * Open a directory named by given path.
 */
static int GOSFS_Delete(struct Mount_Point *mountPoint, const char *path)
{
    //TODO("GeekOS filesystem delete operation");
    return 0;
}

/*
 * Get metadata (size, permissions, etc.) of file named by given path.
 */
static int GOSFS_Stat(struct Mount_Point *mountPoint, const char *path, struct VFS_File_Stat *stat)
{
	int returnCode;
	int offset;
	char *fileName;
	char *pathName;
	struct GOSFS_File *gosFile;
	struct GOSFS_Instance *instance = mountPoint->fsData;
	struct GOSFS_Dir_Entry *dirEntry = (struct GOSFS_Dir_Entry*)Malloc(GOSFS_DIR_ENTRIES_PER_BLOCK * sizeof(*dirEntry));
	struct FS_Buffer *fileBuffer = 0;

	
	split(&pathName, &fileName, path);
	Debug("ls in path \"%s\" for file \"%s\"\n", pathName, fileName);
		
	if(!strcmp(fileName, ""))
	{//root directory
		Debug("root dir selected\n");
		//stat->isSetuid = 0;
    	stat->size = 0;
    	stat->isDirectory = 1;    	
	}
	else
	{
		gosFile = GOSFS_Lookup(mountPoint->fsData, pathName);
		if(gosFile == 0)
			return ENOTFOUND;
		
		offset = findInDir(instance, gosFile->dirBlock, fileName, 0);
		if(offset < 0)
			offset = findInDir(instance, gosFile->dirBlock, fileName, 1);
		if(offset < 0)
		{
			Debug("file not found\n");
			//Free(fileName);
    		//Free(pathName);
    		Free(dirEntry);
			return ENOTFOUND;
		}
		
		Debug("file found\n");
		if((returnCode = Get_FS_Buffer(instance->bufferCache, gosFile->dirBlock, &fileBuffer)) != 0)
    		return returnCode;    	
    		
    	memcpy(dirEntry, fileBuffer->data, GOSFS_DIR_ENTRIES_PER_BLOCK * sizeof(struct GOSFS_Dir_Entry));    	
    	//stat->isSetuid = 0;
    	stat->size = dirEntry[offset].size;
    	stat->isDirectory = ((dirEntry[offset].flags & GOSFS_DIRENTRY_ISDIRECTORY) == GOSFS_DIRENTRY_ISDIRECTORY);    	
    	
    	Release_FS_Buffer(instance->bufferCache, fileBuffer);
	}
	
    //TODO("GeekOS filesystem stat operation");
    Debug("stat->isDirectory = %d\n", stat->isDirectory);
    Debug("finished GOSFS_Stat\n");   
    //Free(fileName);
    //Free(pathName);
    Free(dirEntry);
    return 0;
}

/*
 * Synchronize the filesystem data with the disk
 * (i.e., flush out all buffered filesystem data).
 */
static int GOSFS_Sync(struct Mount_Point *mountPoint)
{
    //TODO("GeekOS filesystem sync operation");
    return 0;
}

/*static*/ struct Mount_Point_Ops s_gosfsMountPointOps = {
    &GOSFS_Open,
    &GOSFS_Create_Directory,
    &GOSFS_Open_Directory,
    &GOSFS_Stat,
    &GOSFS_Sync,
    &GOSFS_Delete,
};





static int GOSFS_Format(struct Block_Device *blockDev)
{
    struct FS_Buffer_Cache *bufferCache = 0;
    struct FS_Buffer *rootDirBuffer = 0;
    struct FS_Buffer *superBlockBuffer = 0;
    struct GOSFS_Dir_Entry rootDirectory[GOSFS_DIR_ENTRIES_PER_BLOCK];    
    struct GOSFS_SuperBlock superBlock;
        
    int numBlocks;
    int returnCode = 0;        
    
    //Clean up rootDirectory
    memset( rootDirectory, '\0', sizeof(rootDirectory));
    
    //Get the number of blocks on blockDev (=bitmapsize)
    numBlocks = Get_Num_Blocks(blockDev); 
    
    //Create temporary BufferCache for filesystem
    bufferCache = Create_FS_Buffer_Cache(blockDev, GOSFS_FS_BLOCK_SIZE);
    KASSERT(bufferCache != 0);
    
    //Get buffer for block 1 for the root directory
    if((returnCode = Get_FS_Buffer(bufferCache, GOSFS_ROOTDIR_BLOCKNR, &rootDirBuffer)) != 0)
    	return returnCode;    
    
    //Write rootDirectory to disk and free buffer    
    memcpy(rootDirBuffer->data, rootDirectory, sizeof(rootDirectory));    
    Modify_FS_Buffer(bufferCache, rootDirBuffer);    
    if((returnCode = Sync_FS_Buffer(bufferCache, rootDirBuffer)) != 0)
    	return returnCode;
    
    if((returnCode = Release_FS_Buffer(bufferCache, rootDirBuffer)) != 0)
    	return returnCode;       
   
    //Fill in superblock with infos
   	memcpy(superBlock.magic, GOSFS_MAGIC_STRING, 4);   	
   	superBlock.rootDirPointer = GOSFS_ROOTDIR_BLOCKNR;   	
   	superBlock.size = numBlocks;
   	superBlock.blockBitmap = Create_Bit_Set(numBlocks);   
   	
   	//Update bitmap
    Set_Bit(superBlock.blockBitmap, GOSFS_ROOTDIR_BLOCKNR);
    Set_Bit(superBlock.blockBitmap, GOSFS_SUPERBLOCK_BLOCKNR);   	
   	
   	//Get buffer for block 0 for the superBlock
    if((returnCode = Get_FS_Buffer(bufferCache, GOSFS_SUPERBLOCK_BLOCKNR, &superBlockBuffer)) != 0)
    	return returnCode;
    
    //Write superBlock to disk and free buffer
    memcpy(superBlockBuffer->data, &superBlock, sizeof(superBlock));    
    Modify_FS_Buffer(bufferCache, superBlockBuffer);
    if((returnCode = Sync_FS_Buffer(bufferCache, superBlockBuffer)) != 0)
    	return returnCode;
    	
    if((returnCode = Release_FS_Buffer(bufferCache, superBlockBuffer)) != 0)
    	return returnCode;    
    
    //destroy bufferCache
    if((returnCode = Destroy_FS_Buffer_Cache(bufferCache)) != 0)
    	return returnCode;
   	//Test_Format(blockDev);   	
    
    Print("Device successfully formated\n");
    return returnCode;
   
}



static int GOSFS_Mount(struct Mount_Point *mountPoint)
{
    //TODO("GeekOS filesystem mount operation");	
	
	int returnCode;
	struct GOSFS_Instance *instance = 0;
	struct FS_Buffer *superBlockBuffer = 0;
    struct GOSFS_SuperBlock *superBlock;
	
    // Allocate instance.
    instance = (struct GOSFS_Instance*) Malloc(sizeof(*instance));
    if (instance == 0)
    {
		return ENOMEM;	
    }
    memset(instance, '\0', sizeof(*instance));    
	
	//Buffer anlegen und in instanz schreiben
	instance->bufferCache = Create_FS_Buffer_Cache(mountPoint->dev, GOSFS_FS_BLOCK_SIZE);
	
	//SuperBlock lesen und magic number prüfen	
	returnCode = Get_FS_Buffer(instance->bufferCache, GOSFS_SUPERBLOCK_BLOCKNR, &superBlockBuffer);
    if(returnCode != 0)
    {
    	Debug("Could not get FS_Buffer for superBlock");    	
    	Free(instance);
    	return returnCode;
    }    
	superBlock = (struct GOSFS_SuperBlock*)Malloc(sizeof(*superBlock));
	memcpy(superBlock, superBlockBuffer->data, sizeof(*superBlock));
	if(strcmp(superBlock->magic, GOSFS_MAGIC_STRING))
	{
		Debug("%s is not equals to %s\n", GOSFS_MAGIC_STRING, superBlock->magic);				
		Release_FS_Buffer(instance->bufferCache, superBlockBuffer);
		Destroy_FS_Buffer_Cache(instance->bufferCache);
		Free(&superBlock);
		Free(instance);
		return EINVALIDFS;
	}
	
	//setting superBlock to mountPoint
	instance->superBlock = superBlock;
	
	//setting fsData to mountPoint
	mountPoint->fsData = instance;
	
	//setting mountPointOps
	mountPoint->ops = &s_gosfsMountPointOps;
	
	//free not used memory	
	Release_FS_Buffer(instance->bufferCache, superBlockBuffer);	
	
	Print("Device successfully mounted\n");
	return 0;
}

static struct Filesystem_Ops s_gosfsFilesystemOps = {
    &GOSFS_Format,
    &GOSFS_Mount,
};

/* ----------------------------------------------------------------------
 * Public functions
 * ---------------------------------------------------------------------- */

void Init_GOSFS(void)
{    
    Register_Filesystem("gosfs", &s_gosfsFilesystemOps);        
}
