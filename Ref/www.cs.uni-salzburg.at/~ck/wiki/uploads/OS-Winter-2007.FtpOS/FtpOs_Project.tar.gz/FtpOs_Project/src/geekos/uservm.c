/*
 * Paging-based user mode implementation
 * Copyright (c) 2003,2004 David H. Hovemeyer <daveho@cs.umd.edu>
 * $Revision: 1.50 $
 * 
 * This is free software.  You are permitted to use,
 * redistribute, and modify it as specified in the file "COPYING".
 */

#include <geekos/paging.h>
#include <geekos/range.h>
#include <geekos/vfs.h>

#include <geekos/ktypes.h>
#include <geekos/kassert.h>
#include <geekos/defs.h>
#include <geekos/mem.h>
#include <geekos/string.h>
#include <geekos/malloc.h>
#include <geekos/int.h>
#include <geekos/gdt.h>
#include <geekos/segment.h>
#include <geekos/tss.h>
#include <geekos/kthread.h>
#include <geekos/argblock.h>
#include <geekos/user.h>

/* ----------------------------------------------------------------------
 * variables
 * ---------------------------------------------------------------------- */


#define DEFAULT_USER_STACK_SIZE 8192

/*
 * flag to indicate if debugging uservm code
 */
int debugUserVM = 1;
#define Debug(args...) if (debugUserVM) Print(args)

/* ----------------------------------------------------------------------
 * Private functions
 * ---------------------------------------------------------------------- */

/*
 * Create a new user context of given size
 */
static struct User_Context* Create_User_Context()
{	
	struct User_Context *context;
	
	context = (struct User_Context*)Malloc(sizeof(struct User_Context));
	KASSERT(context != NULL);
	
	/*
	context->memory = (char*)Malloc(size);
	context->size = size;
	*/
	context->refCount = 0;
	
	//LDT-Descriptor and Selector
	context->ldtDescriptor = Allocate_Segment_Descriptor();
	context->ldtSelector = Selector(
		KERNEL_PRIVILEGE,				//rpl requestor privilege level; should be KERNEL_PRIVILEGE
		true,							//segmentIsInGDT
		Get_Descriptor_Index(			//index of the segment descriptor
			context->ldtDescriptor
		)
	);
	
	//initialize LDT in GDT
	Init_LDT_Descriptor(
		context->ldtDescriptor,			//desc
		context->ldt,					//theLDT[]
		NUM_USER_LDT_ENTRIES			//numEntries
	);
	
	//CodeSegment-Descriptor and Selector
	Init_Code_Segment_Descriptor(
			&context->ldt[0],			//segment descriptor
		    USER_VM_START,				//baseAddr
		    0x80000,					//numPages
		    USER_PRIVILEGE				//privilegeLevel
	);
	context->csSelector = Selector(
		USER_PRIVILEGE,					//rpl requestor privilege level; should be KERNEL_PRIVILEGE
		false,							//segmentIsInGDT
		0								//index of the segment descriptor
	);
	
	//DataSegment-Descriptor and Selector
	Init_Data_Segment_Descriptor(
			&context->ldt[1],			//segment descriptor
		    USER_VM_START,				//baseAddr
		    0x80000,					//numPages
		    USER_PRIVILEGE				//privilegeLevel
	);
	context->dsSelector = Selector(
		USER_PRIVILEGE,					//rpl requestor privilege level; should be KERNEL_PRIVILEGE
		false,							//segmentIsInGDT
		1								//index of the segment descriptor
	);	
	
	return context;
}



static bool Validate_User_Memory(struct User_Context* userContext, ulong_t userAddr, ulong_t bufSize)
{
    ulong_t avail;

	/* maximale beschreibbare Speichergroese = 0xFFFFFFFF;
	 * das ist die groesse eines ulong_t
	 * => keine speicheradresse kann groesser sein
    if (userAddr >= userContext->size)
    {
    	Print("DEBUG: userAddr >= size\n");
        return false;
    }
	*/
	
    avail = userContext->size - userAddr;
    if (bufSize > avail)
    {
    	Print("DEBUG: bufSize > avail\n");
        return false;
    }

    return true;
}


pte_t * getPageTableEntry(pde_t* pageDirectory, ulong_t address){	
	
	ulong_t pageDirAddr =  address >> 22;
	ulong_t pageTabAddr = (address << 10) >> 22;
	//ulong_t offsetAddr  = (address << 20) >> 20;
	
	pde_t *pageDirEntry = (pde_t*) pageDirectory + pageDirAddr;
	pte_t* pageTabEntry = NULL;
	
	if(pageDirEntry->present)
	{
		pageTabEntry = (pte_t*)((pageDirEntry->pageTableBaseAddr) << 12);
		return (pageTabEntry + pageTabAddr);
	}
	else
	{
		return NULL;
	}
	/*
	pde_t *pageDirectoryEntry = pageDirectory + (address >> 22);
	ulong_t pageTableAddress = (address << 10) >> 22;
	pte_t *pageTableEntry = 0; 
		
	if(pageDirectoryEntry->present){
		pageTableEntry = (pte_t*) ((ulong_t) pageDirectoryEntry->pageTableBaseAddr << 12) + pageTableAddress;		
		return pageTableEntry;
	}
	else{
		return NULL;
	}
	*/
}

/*
 * allocates the needed pages
 * 
 * @param pageDir the allocated pages will be registert in this pageDir
 * @param destAddr the virtual address of the needed space
 * @param the size of needed memory
 * 
 * @return 1 if success and 0 when no memory is left
 */
int allocPages(ulong_t pageDir, ulong_t destAddr, ulong_t size)
{
	//page address must not be in kernel address space
	KASSERT(destAddr > 0);
	//KASSERT(destAddr >= USER_VM_START);
	
	uint_t i;
	ulong_t pageAddr;
	
	//split the destination address for pde and pte
	ulong_t pageDirAddr =  destAddr >> 22;
	ulong_t pageTabAddr = (destAddr << 10) >> 22;
	ulong_t offsetAddr  = (destAddr << 20) >> 20;

	//get the page pageDirEntry and create var for pageTabEntry
	pde_t *pageDirEntry = (pde_t*) pageDir + pageDirAddr;
	pte_t *pageTabEntry = NULL;
	
	//get the number of pages to allocate
	uint_t nrOfPages = ((size + offsetAddr - 1) / PAGE_SIZE) + 1;
	//uint_t nrOfPageDirEntr = ((pageTabAddr + nrOfPages - 1) / NUM_PAGE_TABLE_ENTRIES) + 1;
	
	for(i=0; i<nrOfPages; i++)
	{
		//switch to next pageDirEntry
		//to dis herer to get the debug messages right
		if(pageTabAddr >= NUM_PAGE_TABLE_ENTRIES)
		{ 
			Debug("allocPages-> switching to next pageDirEntry");
			pageDirAddr ++;
			pageTabAddr = 0;
			
			pageDirEntry = (pde_t*) pageDir + pageDirAddr;
			pageTabEntry = (pte_t*)(pageDirEntry->pageTableBaseAddr << 12);
		}
		
		//create new pageDirEntry (if neccessarry)
		if(pageDirEntry->present)
		{
			//20Bit Adresse um 12 shiften, damit eine 32 bit Adresse entsteht (Platzersparnis beim speichern)
			pageTabEntry = (pte_t*)(pageDirEntry->pageTableBaseAddr << 12);
			pageTabEntry += pageTabAddr;
		}
		else
		{
			//allocate page and delete content
			//pageTabEntry = (pte_t*)Alloc_Pageable_Page(NULL, 0);
			pageTabEntry = (pte_t*)Alloc_Page();
			if(pageTabEntry == 0)
				return 0;
			KASSERT(pageTabEntry != 0);
			
			//delet the page
			memset(pageTabEntry, 0, PAGE_SIZE);
			
			//format pageDir entry
	    	pageDirEntry->present = 1;
	    	pageDirEntry->flags = VM_USER | VM_WRITE | VM_READ;
	    	pageDirEntry->globalPage = 0;
	    	pageDirEntry->pageTableBaseAddr = (ulong_t)pageTabEntry >> 12;
	    	
	    	//Print("DEBUG: pageDirEntry->pageTableBaseAddr = %d\n", pageDirEntry->pageTableBaseAddr);
	    	//get the correct pageTabEntry from this pageTable
	    	pageTabEntry += pageTabAddr;
		}
		
		if(!pageTabEntry->present)
		{
			//Print("DEBUG: allocating page(2/2): %ld-%ld\n", pageDirAddr, pageTabAddr);
			pageAddr = (ulong_t)Alloc_Pageable_Page(pageTabEntry, (pageDirAddr << 22) | (pageTabAddr << 12));
			if(pageAddr == 0)
				return 0;
			KASSERT(pageAddr != 0);
			//Print("DEBUG: allocated page at addr: %ld\n", pageAddr);
			
			*((uint_t*)pageTabEntry) = 0;
			pageTabEntry->present = 1;
			pageTabEntry->flags = VM_USER | VM_WRITE | VM_READ;
			pageTabEntry->globalPage = 0;
			pageTabEntry->pageBaseAddr = pageAddr >> 12;
		} 
		else 
		{
			Debug("Waring: tried to allocate a already allocated page");
		}	
		
		//check for savety
		KASSERT(pageTabEntry->present);
		
		pageTabEntry ++;
		pageTabAddr ++;
	}
	
	//Print("DEBUG: allocPages - exit\n");
	return 1;
}

void copyToPages(ulong_t pageDir, ulong_t destInUser, void* srcInKernel, ulong_t sizeToCopy)
{
	//Print("DEBUG: copyToPages - entry\n");
	uint_t i;
	
	KASSERT(destInUser >= USER_VM_START);
	
	//split the destination address for pde and pte
	ulong_t pageDirAddr =  destInUser >> 22;
	ulong_t pageTabAddr = (destInUser << 10) >> 22;
	ulong_t offsetAddr  = (destInUser << 20) >> 20;
	
	//Print("DEBUG: pageDirAddr: %ld\n", pageDirAddr);
	//Print("DEBUG: pageTabAddr: %ld\n", pageTabAddr);
	//Print("DEBUG: offsetAddr : %ld\n", offsetAddr);
	
	uint_t nrOfPages = ((sizeToCopy + offsetAddr - 1) / PAGE_SIZE) + 1;
	
	pde_t *pageDirEntry = (pde_t*) pageDir + pageDirAddr;
	//Print("DEBUG: pageDirEntry->present = %d\n", pageDirEntry->present);
	//Print("DEBUG: pageDirEntry->pageTableBaseAddr = %d\n", pageDirEntry->pageTableBaseAddr);
	pte_t *pageTabEntry = (pte_t*) ((ulong_t)pageDirEntry->pageTableBaseAddr << 12);
	pageTabEntry += pageTabAddr;
	
	struct Page *page;
	
	for(i=0; i<nrOfPages; i++)
	{
		page = Get_Page(pageTabEntry->pageBaseAddr >> 12);
		page->flags &= ~PAGE_PAGEABLE;
		
		//Print("DEBUG: pageTabEntry->present = %d\n", pageTabEntry->present);
		//Print("DEBUG: pageTabEntry->pageBaseAddr = %d\n", pageTabEntry->pageBaseAddr);
		void* dest = (void*) ((pageTabEntry->pageBaseAddr << 12) + offsetAddr);
		void* src = srcInKernel;
		
		//Print("DEBUG: will copy to address %ld \n", (ulong_t)dest);
		size_t size = min(PAGE_SIZE - offsetAddr, sizeToCopy);
		
		KASSERT(dest > 0);
		KASSERT(src > 0);
		KASSERT(size > 0);
		memcpy(dest, src, size);
		
		page->flags |= PAGE_PAGEABLE;
		
		offsetAddr   =  0;
		srcInKernel  += size;
		sizeToCopy   -= size;
		pageTabEntry ++;
		pageTabAddr  ++;
		
		if(pageTabAddr >= NUM_PAGE_TABLE_ENTRIES)
		{
			pageDirEntry ++;
			pageTabEntry = (pte_t*) (pageDirEntry->pageTableBaseAddr << 12);
			pageTabAddr  = 0;
		}
		
	}
}

void Free_Page_Directory(pde_t* pageDir)
{
	int i, j;
	pde_t* currPde;
	pte_t* pageTab;
	pte_t* currPte;
    
	KASSERT(!Interrupts_Enabled());
    for(i = NUM_PAGE_DIR_ENTRIES >> 1; i<NUM_PAGE_DIR_ENTRIES; i++)
    {
    	currPde = pageDir + i;
    	//Print("cleaning page dir nr %d on addr %p\n", i, (void*)(i << 22 | currPde->pageTableBaseAddr << 12));
    	if(currPde->present)
    	{
    		KASSERT(currPde->pageTableBaseAddr != 0);
    		pageTab = (pte_t*)(currPde->pageTableBaseAddr << 12);
    		for(j = 0; j<NUM_PAGE_TABLE_ENTRIES; j++)
    		{
    			currPte = pageTab + j;
    			
    			if(currPte->present)
    			{
    				Free_Page((void*) (currPte->pageBaseAddr << 12));
    				*((ulong_t*)currPte) = 0;
    			}
    			else if(currPte->kernelInfo == KINFO_PAGE_ON_DISK)
    			{
    				Free_Space_On_Paging_File(currPte->pageBaseAddr);
    				*((ulong_t*)currPte) = 0;
    			}
    		}
    		Free_Page(pageTab);
    		*((ulong_t*)currPde) = 0;
    	}
    }
    Free_Page(pageDir);
}
/* ----------------------------------------------------------------------
 * Public functions
 * ---------------------------------------------------------------------- */

/*
 * Destroy a User_Context object, including all memory
 * and other resources allocated within it.
 */
void Destroy_User_Context(struct User_Context* context)
{
	/*
     * Hints:
     * - Free all pages, page tables, and page directory for
     *   the process (interrupts must be disabled while you do this,
     *   otherwise those pages could be stolen by other processes)
     * - Free semaphores, files, and other resources used
     *   by the process
     */
    //TODO("Destroy User_Context data structure after process exits");
    Free_Segment_Descriptor(context->ldtDescriptor);
	
    //Free(context->memory);
    Free_Page_Directory(context->pageDir);
    
    //SEMAPHORS ARE FREED IN KTHREAD.C
    
    Free(context);
    printBitmap();
}

/*
 * Load a user executable into memory by creating a User_Context
 * data structure.
 * Params:
 * exeFileData - a buffer containing the executable to load
 * exeFileLength - number of bytes in exeFileData
 * exeFormat - parsed ELF segment information describing how to
 *   load the executable's text and data segments, and the
 *   code entry point address
 * command - string containing the complete command to be executed:
 *   this should be used to create the argument block for the
 *   process
 * pUserContext - reference to the pointer where the User_Context
 *   should be stored
 *
 * Returns:
 *   0 if successful, or an error code (< 0) if unsuccessful
 */
int Load_User_Program(char *exeFileData, ulong_t exeFileLength,
    struct Exe_Format *exeFormat, const char *command,
    struct User_Context **pUserContext)
{	
    /*
     * Hints:
     * - This will be similar to the same function in userseg.c
     * - Determine space requirements for code, data, argument block,
     *   and stack
     * - Allocate pages for above, map them into user address
     *   space (allocating page directory and page tables as needed)
     * - Fill in initial stack pointer, argument block address,
     *   and code entry point fields in User_Context
     */
    //TODO("Load user program into address space");
    uint_t i;
    uint_t numArgs;
	ulong_t argBlockSize = 0;
	
	//Print("DEBUG: Loading UserProgram: %s\n", command);
	
	/*
     * Kopieren der ersten Hälfte der Kernel-Page-Table in die User-PageTable
     */
    ulong_t pageDir = (ulong_t)Alloc_Page();
	KASSERT(pageDir != 0);

	//create userContext with calculated size
	*pUserContext =  Create_User_Context();
	(*pUserContext)->pageDir	= (void*)pageDir;
	(*pUserContext)->size		= USER_VM_SIZE;
	(*pUserContext)->entryAddr	= exeFormat->entryAddr;

	memcpy((void*)pageDir, (void*)getKernelPageDir(), PAGE_SIZE >> 1);
	memset((void*)pageDir + (NUM_PAGE_DIR_ENTRIES >> 1), 0, PAGE_SIZE >> 1);
	//initPageDirEntries(pageDir);

	/*
     * copy segments to pages
     */
    for(i=0; i<exeFormat->numSegments; i++)
    {
    	// load segments to the memory
    	ulong_t fileOffset = exeFormat->segmentList[i].offsetInFile;
    	ulong_t fileLength = exeFormat->segmentList[i].lengthInFile;
    	ulong_t memLength  = exeFormat->segmentList[i].sizeInMemory;
    	ulong_t memOffset  = exeFormat->segmentList[i].startAddress;
    	
    	if(memLength == 0)
    	{
    		//Print("DEBUG: segment empty -> continue with next\n");
    		continue;
    	}
    	
    	//segment must be in range of 2GB
    	KASSERT(memOffset + memLength < 0x80000000);
    	//allocate the needed pages
    	allocPages(
    		pageDir,
    		memOffset + USER_VM_START,
    		memLength
    	);
    	//copy segment to the pages
    	copyToPages(
    		pageDir,
    		memOffset + USER_VM_START,
    		exeFileData + fileOffset,
    		fileLength
    	);
    }
	//get the size of used memory
	Get_Argument_Block_Size(
    		command,
    		&numArgs,
    		&argBlockSize);
	KASSERT(argBlockSize < PAGE_SIZE);
	
	//allocate pages for stack
	ulong_t destAddr = USER_VM_SIZE - Round_Up_To_Page(argBlockSize) - DEFAULT_USER_STACK_SIZE;
	(*pUserContext)->stackPointerAddr = destAddr + DEFAULT_USER_STACK_SIZE;
    allocPages(pageDir, destAddr + USER_VM_START, DEFAULT_USER_STACK_SIZE);
	//Print("DEBUG: stackPointerAddr = %p\n", (void*)destAddr);

    //allocate pages for argument block
    destAddr = Round_Down_To_Page(USER_VM_SIZE - argBlockSize);
    (*pUserContext)->argBlockAddr = destAddr;
    allocPages(pageDir, destAddr + USER_VM_START, argBlockSize);
	//Print("DEBUG: argBlockAddr = %p\n", (void*)destAddr);
	
	char* argBlockAddr = Malloc(argBlockSize);
	Format_Argument_Block(
			argBlockAddr,			//pointer to kernel buffer where argument block is being built
    		numArgs,				//number of command line arguments
    		destAddr,				//the address where the argument block will be located in user mode
    		command					//the command used to build the argument block
    );

    copyToPages(pageDir, destAddr + USER_VM_START, argBlockAddr, argBlockSize);
	Free(argBlockAddr);

	//Print("DEBUG: UserProgram loaded: %s\n", command);
	return 0;
}

/*
 * Copy data from user buffer into kernel buffer.
 * Returns true if successful, false otherwise.
 */
bool Copy_From_User(void* destInKernel, ulong_t srcInUser, ulong_t numBytes)
{
    /*
     * Hints:
     * - Make sure that user page is part of a valid region
     *   of memory
     * - Remember that you need to add 0x80000000 to user addresses
     *   to convert them to kernel addresses, because of how the
     *   user code and data segments are defined
     * - User pages may need to be paged in from disk before being accessed.
     * - Before you touch (read or write) any data in a user
     *   page, **disable the PAGE_PAGEABLE bit**.
     *
     * Be very careful with race conditions in reading a page from disk.
     * Kernel code must always assume that if the struct Page for
     * a page of memory has the PAGE_PAGEABLE bit set,
     * IT CAN BE STOLEN AT ANY TIME.  The only exception is if
     * interrupts are disabled; because no other process can run,
     * the page is guaranteed not to be stolen.
     */
    
    //TODO("Copy user data to kernel buffer"); 
	srcInUser += USER_VM_START;
	
    struct User_Context *uc = g_currentThread->userContext;
    
    //all buf must be in user-memory too
    if(!Validate_User_Memory(uc, srcInUser, numBytes))
	    return false;
    
    //use memcopy
    memcpy(destInKernel, (void*)srcInUser, numBytes);
 
    return true;
}

/*
 * Copy data from kernel buffer into user buffer.
 * Returns true if successful, false otherwise.
 */
bool Copy_To_User(ulong_t destInUser, void* srcInKernel, ulong_t bufSize)
{
    /*
     * Hints:
     * - Same as for Copy_From_User()
     * - Also, make sure the memory is mapped into the user
     *   address space with write permission enabled
     */
    //TODO("Copy kernel data to user buffer");
    destInUser += USER_VM_START;
    
    struct User_Context *uc = g_currentThread->userContext;
    
	if(!Validate_User_Memory(uc, destInUser, bufSize))
	    return false;
	
	//use memcopy insteads
    memcpy((void*)destInUser, srcInKernel, bufSize);
    
    return true;
}

/*
 * Switch to user address space.
 */
void Switch_To_Address_Space(struct User_Context *userContext)
{
    /*
     * - If you are still using an LDT to define your user code and data
     *   segments, switch to the process's LDT
     * - 
     */
    //TODO("Switch_To_Address_Space() using paging");
    Load_LDTR(userContext->ldtSelector);
    Set_PDBR(userContext->pageDir);
}
