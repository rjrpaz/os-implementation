/*
 * Segmentation-based user mode implementation
 * Copyright (c) 2001,2003 David H. Hovemeyer <daveho@cs.umd.edu>
 * $Revision: 1.23 $
 * 
 * This is free software.  You are permitted to use,
 * redistribute, and modify it as specified in the file "COPYING".
 */

#include <geekos/ktypes.h>
#include <geekos/kassert.h>
#include <geekos/defs.h>
#include <geekos/mem.h>
#include <geekos/string.h>
#include <geekos/malloc.h>
#include <geekos/int.h>
#include <geekos/gdt.h>
#include <geekos/segment.h>
#include <geekos/tss.h>
#include <geekos/kthread.h>
#include <geekos/argblock.h>
#include <geekos/user.h>

/* ----------------------------------------------------------------------
 * Variables
 * ---------------------------------------------------------------------- */

#define DEFAULT_USER_STACK_SIZE 8192


/* ----------------------------------------------------------------------
 * Private functions
 * ---------------------------------------------------------------------- */


/*
 * Create a new user context of given size
 */
static struct User_Context* Create_User_Context(ulong_t size)
{	
	struct User_Context *context;
	
	context = (struct User_Context*)Malloc(sizeof(struct User_Context));
	context->memory = (char*)Malloc(size);
	context->size = size;
	context->refCount = 0;
	
	if(context == NULL)
	{
		Print("Not enough memory to create user context");
		return NULL;
	}
	
	//LDT-Descriptor and Selector
	context->ldtDescriptor = Allocate_Segment_Descriptor();
	context->ldtSelector = Selector(
		KERNEL_PRIVILEGE,				//rpl requestor privilege level; should be KERNEL_PRIVILEGE
		true,							//segmentIsInGDT
		Get_Descriptor_Index(			//index of the segment descriptor
			context->ldtDescriptor
		)
	);
	
	//initialize LDT in GDT
	Init_LDT_Descriptor(
		context->ldtDescriptor,			//desc
		context->ldt,					//theLDT[]
		NUM_USER_LDT_ENTRIES			//numEntries
	);
	
	//CodeSegment-Descriptor and Selector
	Init_Code_Segment_Descriptor(
			&context->ldt[0],			//segment descriptor
		    (ulong_t)context->memory,	//baseAddr
		    size / PAGE_SIZE,			//numPages
		    USER_PRIVILEGE				//privilegeLevel
	);
	context->csSelector = Selector(
		USER_PRIVILEGE,					//rpl requestor privilege level; should be KERNEL_PRIVILEGE
		false,							//segmentIsInGDT
		0								//index of the segment descriptor
	);
	
	//DataSegment-Descriptor and Selector
	Init_Data_Segment_Descriptor(
			&context->ldt[1],			//segment descriptor
		    (ulong_t)context->memory,	//baseAddr
		    size / PAGE_SIZE,			//numPages
		    USER_PRIVILEGE				//privilegeLevel
	);
	context->dsSelector = Selector(
		USER_PRIVILEGE,					//rpl requestor privilege level; should be KERNEL_PRIVILEGE
		false,							//segmentIsInGDT
		1								//index of the segment descriptor
	);	
	
	return context;
}



static bool Validate_User_Memory(struct User_Context* userContext, ulong_t userAddr, ulong_t bufSize)
{
    ulong_t avail;

    if (userAddr >= userContext->size)
    {
    	Print("DEBUG: userAddr >= size\n");
        return false;
    }

    avail = userContext->size - userAddr;
    if (bufSize > avail)
    {
    	Print("DEBUG: bufSize > avail\n");
        return false;
    }

    return true;
}

/* ----------------------------------------------------------------------
 * Public functions
 * ---------------------------------------------------------------------- */

/*
 * Destroy a User_Context object, including all memory
 * and other resources allocated within it.
 */
void Destroy_User_Context(struct User_Context* userContext)
{
    /*
     * Hints:
     * - you need to free the memory allocated for the user process
     * - don't forget to free the segment descriptor allocated for the process's LDT
     */
	Free_Segment_Descriptor(userContext->ldtDescriptor);
    Free(userContext->memory);
    Free(userContext);
}

/*
 * Load a user executable into memory by creating a User_Context
 * data structure.
 * Params:
 * exeFileData - a buffer containing the executable to load
 * exeFileLength - number of bytes in exeFileData
 * exeFormat - parsed ELF segment information describing how to
 *   load the executable's text and data segments, and the
 *   code entry point address
 * command - string containing the complete command to be executed:
 *   this should be used to create the argument block for the
 *   process
 * pUserContext - reference to the pointer where the User_Context
 *   should be stored
 *
 * Returns:
 *   0 if successful, or an error code (< 0) if unsuccessful
 */
int Load_User_Program(
	char *exeFileData,
	ulong_t exeFileLength,
    struct Exe_Format *exeFormat,
    const char *command,
    struct User_Context **pUserContext)
{	
	int i;
	ulong_t size = 0;
	ulong_t argBlockSize = 0;
	ulong_t maxVirtualAddr = 0;
	ulong_t segSize = 0;
	unsigned int numArgs; 
	
	//get highest virtual sement-address and its segment-size
	for(i=0; i<exeFormat->numSegments; i++)
	{
		if(maxVirtualAddr < exeFormat->segmentList[i].startAddress)
		{
			maxVirtualAddr = exeFormat->segmentList[i].startAddress;
			segSize = exeFormat->segmentList[i].sizeInMemory;
		}
		
	}
	size += Round_Up_To_Page(maxVirtualAddr + segSize);
	
	//get the size of used memory
	Get_Argument_Block_Size(
    		command,
    		&numArgs,
    		&argBlockSize);
    		
	size += Round_Up_To_Page(DEFAULT_USER_STACK_SIZE + argBlockSize);
	
	//create userContext with calculated size
	*pUserContext =  Create_User_Context(size);
	
    /*
     * Hints:
     * - Determine where in memory each executable segment will be placed
     * - Determine size of argument block and where in memory it will
     *   be placed
     * - Copy each executable segment into memory
     */
    for(i=0; i<exeFormat->numSegments; i++)
    {
    	// load segments to the memory
    	int fileOffset = exeFormat->segmentList[i].offsetInFile;
    	int fileLength = exeFormat->segmentList[i].lengthInFile;
    	int memLength  = exeFormat->segmentList[i].sizeInMemory;
    	int memOffset  = exeFormat->segmentList[i].startAddress;
    	
    	//copy segment to user-memory
    	memcpy(
    		(*pUserContext)->memory + memOffset,
    		exeFileData + fileOffset,
    		fileLength
    	);
    	
    	//clean all space between fileLength and memLength
    	memset(
    		(*pUserContext)->memory + memOffset + fileLength,
    		0,
    		memLength - fileLength
    	);
    }
    
    /* Hints cont.:
     * - Format argument block in memory
     */
    Format_Argument_Block(
    		(*pUserContext)->memory + size - argBlockSize,	//pointer to kernel buffer where argument block is being built
    		numArgs,										//number of command line arguments
    		size - argBlockSize,							//the address where the argument block will be located in user mode
    		command											//the command used to build the argument block
    );
    
    /* Hints cont.:
     *  - In the created User_Context object, set code entry point address,
     *    argument block address,
     *    and initial kernel stack pointer address
     */
    (*pUserContext)->entryAddr = exeFormat->entryAddr;
    (*pUserContext)->argBlockAddr = size - argBlockSize;
    (*pUserContext)->stackPointerAddr = size - argBlockSize;
    
    return 0;
}

/*
 * Copy data from user memory into a kernel buffer.
 * Params:
 * destInKernel - address of kernel buffer
 * srcInUser - address of user buffer
 * bufSize - number of bytes to copy
 *
 * Returns:
 *   true if successful, false if user buffer is invalid (i.e.,
 *   doesn't correspond to memory the process has a right to
 *   access)
 */
bool Copy_From_User(void* destInKernel, ulong_t srcInUser, ulong_t bufSize)
{
    /*
     * Hints:
     * - the User_Context of the current process can be found
     *   from g_currentThread->userContext
     * - the user address is an index relative to the chunk
     *   of memory you allocated for it
     * - make sure the user buffer lies entirely in memory belonging
     *   to the process
     */
    struct User_Context *uc = g_currentThread->userContext;
    
    //all buf must be in user-memory too
    if(!Validate_User_Memory(uc, srcInUser, bufSize))
	    return false;
    
    //use memcopy instead
    memcpy(destInKernel, uc->memory + srcInUser, bufSize);
    //for(i=0; i<bufSize; i++)
    //	dest[i] = uc->memory[srcInUser + i];
    
    return true;
}

/*
 * Copy data from kernel memory into a user buffer.
 * Params:
 * destInUser - address of user buffer
 * srcInKernel - address of kernel buffer
 * bufSize - number of bytes to copy
 *
 * Returns:
 *   true if successful, false if user buffer is invalid (i.e.,
 *   doesn't correspond to memory the process has a right to
 *   access)
 */
bool Copy_To_User(ulong_t destInUser, void* srcInKernel, ulong_t bufSize)
{	
    /*
     * Hints: same as for Copy_From_User()
     */
	struct User_Context *uc = g_currentThread->userContext;
    
	if(!Validate_User_Memory(uc, destInUser, bufSize))
	    return false;
	
	//use memcopy insteads
    memcpy(uc->memory + destInUser, srcInKernel, bufSize);
    
    return true;
}

/*
 * Switch to user address space belonging to given
 * User_Context object.
 * Params:
 * userContext - the User_Context
 */
void Switch_To_Address_Space(struct User_Context *userContext)
{
    /*
     * Hint: you will need to use the lldt assembly language instruction
     * to load the process's LDT by specifying its LDT selector.
     */
    Load_LDTR(userContext->ldtSelector);
}

