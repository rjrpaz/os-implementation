/*
 * A user mode program which uses deep recursion
 * to test stack growth.
 */

#include <conio.h>
#include <string.h>

#define wasteMem 1024

void Recurse(int x)
{
    int stuff[wasteMem];  
    int test[wasteMem];  
    int i;
    for(i=0;i<wasteMem;i++){
    	stuff[i] = 10+i;
    }   
    for(i=0;i<wasteMem;i++){
    	test[i] = stuff[i]+i;
    }  
    for(i=0;i<wasteMem;i++){
    	test[i] = test[i]+i;
    }  
    for(i=0;i<1;i++){
    	Print("%d\n", test[i+10]);
    } 

    if (x == 0) return;

    stuff[0] = x;
    Print("calling Recurse\n");
    Recurse(x-1);
}

int main(int argc, char **argv)
{
    /* change recurse to 5-10 to see stack faults without page outs */
    int depth = 512;

    if (argc > 1) {
	depth = atoi(argv[1]);
	Print("Depth is %d\n", depth);
    }

    Recurse(depth);

	Print("Rec finished\n");
    return 0;
}

