/*
 * Paging (virtual memory) support
 * Copyright (c) 2003, Jeffrey K. Hollingsworth <hollings@cs.umd.edu>
 * Copyright (c) 2003,2004 David H. Hovemeyer <daveho@cs.umd.edu>
 * $Revision: 1.55 $
 * 
 * This is free software.  You are permitted to use,
 * redistribute, and modify it as specified in the file "COPYING".
 */

#include <geekos/string.h>
#include <geekos/int.h>
#include <geekos/idt.h>
#include <geekos/kthread.h>
#include <geekos/kassert.h>
#include <geekos/screen.h>
#include <geekos/mem.h>
#include <geekos/malloc.h>
#include <geekos/gdt.h>
#include <geekos/segment.h>
#include <geekos/user.h>
#include <geekos/vfs.h>
#include <geekos/crc32.h>
#include <geekos/paging.h>
#include <geekos/bitset.h>
#include <geekos/sem.h>

/* ----------------------------------------------------------------------
 * Public data
 * ---------------------------------------------------------------------- */

	pde_t* pageDir;

/* ----------------------------------------------------------------------
 * Private functions/data
 * ---------------------------------------------------------------------- */  
  
  struct Bit_Set *bitmap = NULL;
  struct Paging_Device* pd = NULL;
  int bitmapSize = 0;

#define SECTORS_PER_PAGE (PAGE_SIZE / SECTOR_SIZE)
//#define BLOCKS_FOR_PAGE 8

/*
 * flag to indicate if debugging paging code
 */
int debugFaults = 0;
#define Debug(args...) if (debugFaults) Print(args)


void checkPaging()
{
  unsigned long reg=0;
  __asm__ __volatile__( "movl %%cr0, %0" : "=a" (reg));
  Print("Paging on ? : %d\n", (reg & (1<<31)) != 0);
}


/*
 * Print diagnostic information for a page fault.
 */
static void Print_Fault_Info(uint_t address, faultcode_t faultCode)
{
    if(debugFaults == 1){
    	Print("\n");    	
    	extern uint_t g_freePageCount;
	    Print("Pid %d, Page Fault received, at address %p (%d pages free)\n",
	        g_currentThread->pid, (void*)address, g_freePageCount);
	    if (faultCode.protectionViolation)
	        Print ("   Protection Violation, ");
	    else
	        Print ("   Non-present page, ");
	    if (faultCode.writeFault)
	        Print ("Write Fault, ");
	    else
	        Print ("Read Fault, ");
	    if (faultCode.userModeFault)
	        Print ("in User Mode\n");
	    else
	        Print ("in Supervisor Mode\n");
    }    
}

int PageFault(pde_t * pagedir, ulong_t vaddr) {	
	//Get PageTableEntry
	pte_t * pageTableEntry = getPageTableEntry(pagedir, vaddr);
	if(pageTableEntry == NULL)
	{
		Debug("page table entry not found\n");
		return 0;
	}
	else if(pageTableEntry->kernelInfo != KINFO_PAGE_ON_DISK) 
	{
		Debug("page not on disk\n");
		Debug("virtual address : %p\n", (void*)vaddr);
		Debug("pageTableEntry->present      = %d\n", pageTableEntry->present);
		Debug("pageTableEntry->kernelInfo   = %d\n", pageTableEntry->kernelInfo);
		Debug("pageTableEntry->pageBaseAddr = %d\n", pageTableEntry->pageBaseAddr);
		return 0;
	}
	
	//Get Address
	int pageFileIndex = pageTableEntry->pageBaseAddr;
	
	//Allocate new Page
	void * paddr = Alloc_Pageable_Page(pageTableEntry, Round_Down_To_Page(vaddr));
	
	if(paddr == NULL) {
		Debug("Out of memory!\n");
		return -1;
	}	
	
	//pageTableEntry->present = 1;
	//Set address
	pageTableEntry->pageBaseAddr = (ulong_t) paddr >> 12;
	
	//Read from disk
	Enable_Interrupts();
	Read_From_Paging_File(paddr, Round_Down_To_Page(vaddr), pageFileIndex);
	Disable_Interrupts();
	
	//Free disk space
	Free_Space_On_Paging_File(pageFileIndex);
	return 1;
}

/*
 * Handler for page faults.
 * You should call the Install_Interrupt_Handler() function to
 * register this function as the handler for interrupt 14.
 */ 
/*static*/ void Page_Fault_Handler(struct Interrupt_State* state)
{
    ulong_t address;
	faultcode_t faultCode;	
	struct User_Context* userContext = g_currentThread->userContext;
	//Update clock for LRU
	updateClock();
	
    KASSERT(!Interrupts_Enabled());
    
    // Get the address that caused the page fault 
    address = Get_Page_Fault_Address();
    
    // Get the fault code 
    faultCode = *((faultcode_t *) &(state->errorCode));
    Print_Fault_Info(address, faultCode);
    
    KASSERT(address > 0);
    //KASSERT(address >= USER_VM_START);
    //KASSERT(faultCode.userModeFault);
    KASSERT(!faultCode.protectionViolation);
    
    if(faultCode.writeFault)
    {//write fault
    	int success = allocPages(
    		(ulong_t)userContext->pageDir,
    		Round_Down_To_Page(address),
    		PAGE_SIZE
    	);
    	
    	if(!success)
    	{
    		Debug("Out of memory!\n");
    		Exit(-1);			
    	}
    }
    else
    {//read fault
		if(!PageFault(userContext->pageDir, address))
		{
			//user mode falut -> just exit
			Debug("Error\n");		
			Dump_Interrupt_State(state);
	    	Exit(-1);	
		}
    }
}

void printBitmap(){
	if(debugFaults)
	{
		int i;
		for(i = 0; i < bitmapSize; i++){
			Print("%d", Is_Bit_Set(bitmap, i));
		}
		Print("\n");
	}
}

/**
 * initialize the page-table
 */
 uint_t initPageTable(uint_t* pageAddr, uint_t nrOfPages)
 {
 	Debug("initializing pageTable");
 	uint_t i;
 	pte_t* pageTableEntry;
 	uint_t pageTable;
 	
 	KASSERT(nrOfPages > 0);
 	KASSERT(nrOfPages <= NUM_PAGE_TABLE_ENTRIES);
 	
 	pageTable = (ulong_t) Alloc_Page();
 	KASSERT(pageTable != 0);
 	
 	pageTableEntry = (pte_t*) pageTable;
 	for(i=0; i<nrOfPages; i++)
 	{
 		*((uint_t*)pageTableEntry) = 0;
 		
 		pageTableEntry->present = 1;
    	pageTableEntry->flags = VM_WRITE | VM_NOCACHE;
	    pageTableEntry->globalPage = 1;
	    pageTableEntry->pageBaseAddr = (*pageAddr) >> 12;
	    
	    pageTableEntry ++;
	    (*pageAddr) += PAGE_SIZE;
 	}
 	
 	//if there are page table entries left, set them to 0
 	for(; i<NUM_PAGE_TABLE_ENTRIES; i++)
 	{
 		*((uint_t*)pageTableEntry) = 0;
 		pageTableEntry ++;
 	}
 	
 	return pageTable;
 }

/**
 * initialize the page-directory and the page tables
 */
uint_t initPageDir(uint_t nrOfPages)
{	
	Debug("initializing pageDirectory");
	uint_t i;
	uint_t nrOfPageDirEntries;
	uint_t pageAddr;
	uint_t pageDir;
	pde_t* pageDirEntry;
	
	/* Alzahl der Directory-Eintraege:
	 * nrOfPageDirEntries = nrOfPages/1024;
	 * Aber:
	 * 	- Sei nrOfPages = 10 => 10/1024 = 0;
	 * 	  bis 1024 muss es aber 1 sein => (nrOfPages/1024)+1;
	 *  - Sei nrOfPages = 1024 => 1024/1024 = 1;
	 * 	  hier muss aber nur eine Seite generiert werden, durch obige
	 *    regel würden aber 2 generiert => ((nrOfPages-1)/1024)+1;
	 */
	nrOfPageDirEntries = ((nrOfPages-1) / NUM_PAGE_TABLE_ENTRIES) + 1;
	KASSERT(nrOfPageDirEntries > 0);
	KASSERT(nrOfPageDirEntries <= NUM_PAGE_DIR_ENTRIES);
	
	pageDir = (ulong_t)Alloc_Page();
	KASSERT(pageDir != 0);
	
	pageAddr = 0;
	pageDirEntry = (pde_t*)pageDir;
	
    for(i=0; i<nrOfPageDirEntries; i++)
    {
    	*((uint_t*)pageDirEntry) = 0;
    	
    	pageDirEntry->present = 1;
    	pageDirEntry->flags = VM_WRITE;
    	pageDirEntry->globalPage = 1;
    	pageDirEntry->pageTableBaseAddr = initPageTable(&pageAddr, min(NUM_PAGE_TABLE_ENTRIES, nrOfPages)) >> 12;
    	
    	nrOfPages -= NUM_PAGE_TABLE_ENTRIES;
    	pageDirEntry ++;
    }
    
 	//if there are page directory entries left, set them to 0
    for(; i<NUM_PAGE_DIR_ENTRIES; i++)
    {
    	*((uint_t*)pageDirEntry) = 0;
    	pageDirEntry ++;
    }
    
    return pageDir;
}

/* ----------------------------------------------------------------------
 * Public functions
 * ---------------------------------------------------------------------- */

ulong_t min(ulong_t a, ulong_t b)
{
	return a<b ? a : b;
}

ulong_t getKernelPageDir()
{
	return (ulong_t) pageDir;
}

/*
 * Initialize virtual memory by building page tables
 * for the kernel and physical memory.
 */
void Init_VM(struct Boot_Info *bootInfo)
{	
	//TODO("Build initial kernel page directory and page tables");

    /*
     * Hints:
     * - Build kernel page directory and page tables
     */
    pageDir = (pde_t*) initPageDir(bootInfo->memSizeKB/4);
     
    /* - Do not map a page at address 0; this will help trap
     *   null pointer references
     */
	pte_t* pageTable = (pte_t*)(((pde_t*)pageDir)->pageTableBaseAddr << 12);
	pageTable->present = 0;
     
    /*
     *  - Call Enable_Paging() with the kernel page directory
     */
    Enable_Paging(pageDir);
    
    /* - Install an interrupt handler for interrupt 14,
     *   page fault
     */
    Install_Interrupt_Handler(14, Page_Fault_Handler);
}

/**
 * Initialize paging file data structures.
 * All filesystems should be mounted before this function
 * is called, to ensure that the paging file is available.
 */
void Init_Paging(void)
{
    //TODO("Initialize paging file data structures");
    
    pd = Get_Paging_Device();    
    KASSERT(pd != NULL);    

    //Init bitmap
    //Bitmap size is pd->numSectors/SECTORS_PER_PAGE since one page needs 8 sectors      
    bitmapSize = pd->numSectors/SECTORS_PER_PAGE;
    //Debug("numSectors: %ld\n", pd->numSectors);
    //Debug("SECTORS_PER_PAGE: %d\n", SECTORS_PER_PAGE);
    //Debug("PAGE_SIZE: %d\n", PAGE_SIZE);
    //Debug("SECTOR_SIZE: %d\n", SECTOR_SIZE);
    bitmap = Create_Bit_Set(bitmapSize);     
}

/**
 * Find a free bit of disk on the paging file for this page.
 * Interrupts must be disabled.
 * @return index of free page sized chunk of disk space in
 *   the paging file, or -1 if the paging file is full
 */
int Find_Space_On_Paging_File(void)
{
    //TODO("Find free page in paging file");
    
    //TODO: Dont comment KASSERT, just commented because of testing
    //KASSERT(!Interrupts_Enabled());    
    
    //Return actual address in paging file
    return Find_First_Free_Bit(bitmap, bitmapSize);    
}

/**
 * Free a page-sized chunk of disk space in the paging file.
 * Interrupts must be disabled.
 * @param pagefileIndex index of the chunk of disk space
 */
void Free_Space_On_Paging_File(int pagefileIndex)
{
    //TODO("Free page in paging file");
 	KASSERT(!Interrupts_Enabled());
 	KASSERT(0 <= pagefileIndex && pagefileIndex < bitmapSize);
    
    Clear_Bit(bitmap, pagefileIndex);  
}

/**
 * Write the contents of given page to the indicated block
 * of space in the paging file.
 * @param paddr a pointer to the physical memory of the page
 * @param vaddr virtual address where page is mapped in user memory
 * @param pagefileIndex the index of the page sized chunk of space
 *   in the paging file
 */
void Write_To_Paging_File(void *paddr, ulong_t vaddr, int pagefileIndex)
{
    //TODO("Write page data to paging file");
    struct Page *page = Get_Page((ulong_t) paddr);
    KASSERT(!(page->flags & PAGE_PAGEABLE)); // Page must be locked! 
    
    //Debug("PageFileIndex: 0 <= %d < %d\n", pagefileIndex, bitmapSize);
   	if(0 <= pagefileIndex && pagefileIndex < bitmapSize)
   	{
   		int i;
   		for(i=0;i<SECTORS_PER_PAGE;i++)
   		{
   			Block_Write(
   				pd->dev,
   				pagefileIndex*SECTORS_PER_PAGE + i + (pd->startSector),
   				paddr+i*SECTOR_SIZE
   			);   			
   		}
   		Set_Bit(bitmap,pagefileIndex); 
   	}
   	else
   	{
    	Print("Write_To_Paging_File: pagefileIndex out of range!\n");
    	Exit(-1);
    }
    //Debug("End of write to paging file\n");    
}

/**
 * Read the contents of the indicated block
 * of space in the paging file into the given page.
 * @param paddr a pointer to the physical memory of the page
 * @param vaddr virtual address where page will be re-mapped in
 *   user memory
 * @param pagefileIndex the index of the page sized chunk of space
 *   in the paging file
 */
//void Read_From_Paging_File(void *paddr, ulong_t vaddr, int pagefileIndex)
void Read_From_Paging_File(void *paddr, ulong_t vaddr, int pagefileIndex)
{
    //TODO("Read page data from paging file");
   	struct Page *page = Get_Page((ulong_t) paddr);
    page->flags = page->flags & ~PAGE_PAGEABLE;
    KASSERT(!(page->flags & PAGE_PAGEABLE)); /* Page must be locked! */
    
    if(0 <= pagefileIndex && pagefileIndex < bitmapSize)
    {
   		int i;
   		for(i=0;i<SECTORS_PER_PAGE;i++)
   		{
   			Block_Read(
   				pd->dev,
   				pagefileIndex*SECTORS_PER_PAGE + i + (pd->startSector),
   				paddr+i*SECTOR_SIZE
   			);   			
   		}
   		Clear_Bit(bitmap,pagefileIndex);   		
   	}
   	else
   	{
    	Print("Read_From_Paging_File: pagefileIndex out of range!\n");
    }         
    page->vaddr = vaddr;
	page->entry = getPageTableEntry(g_currentThread->userContext->pageDir, vaddr);
	//page->entry = entry;
	page->entry->present=1;
    page->flags |= PAGE_PAGEABLE;    
}

