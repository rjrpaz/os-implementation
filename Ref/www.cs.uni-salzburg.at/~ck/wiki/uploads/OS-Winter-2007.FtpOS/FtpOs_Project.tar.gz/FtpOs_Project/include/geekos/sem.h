#ifndef SEM_H_
#define SEM_H_

#define NR_OF_SEMAPHORS 20
#define MAX_SEM_NAME_LENGTH 25

void Init_Semaphors();

int sem_create(uint_t name, uint_t nameLength, uint_t initCount, struct Kernel_Thread* caller);
int sem_p(int semId, struct Kernel_Thread* caller);
int sem_v(int semId, struct Kernel_Thread* caller);
int sem_destroy(int semId, struct Kernel_Thread* caller);

#endif /*SEM_H_*/
