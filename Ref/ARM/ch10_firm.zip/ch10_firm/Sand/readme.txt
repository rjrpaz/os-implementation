
SandStone

  Sandstone is is simple firmware that setups the ARM Evaluator 7T
  board.

Processor Supported

  ARM7TDMI

Board Supported

  ARM Evaluator-7T


  If there are no errors the binary image is placed into build/image 
  directory and is given the name rom.bin. rom.bin can then be written
  to the Flash ROM and upon reset the Sandstone will run on the 
  Evaluator-7T. 

