
mpuSLOS

  mpuSLOS is a version of the SLOS operating system that makes use of the 
  ARM memory protection unit.

Processor Supported

  ARM940T

Board Supported

  ARM Integrator/AP


  If there are no errors the binary image is placed into build/image 
  directory and is given the name slos.bin. slos.bin can then be loaded 
  and executed on an Integrator/AP with ARM940T core module. 







 