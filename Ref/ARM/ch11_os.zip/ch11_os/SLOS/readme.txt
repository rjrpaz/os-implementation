
baseSLOS

  baseSLOS is a version of the SLOS operating system that does not use 
  hadrware assisted memory management.

Processor Supported

  ARM7TDMI

Board Supported

  ARM Evaluator-7T

  If there are no errors the binary image is placed into build/image 
  directory and is given the name slos.bin. slos.bin can then be loaded 
  and executed on an Evaluator-7T. 







 