#include "../libc/fmtout.h"
