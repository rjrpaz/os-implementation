/*************************************************************************/
/*
 * GeekOS master source distribution and/or project solution
 * Copyright (c) 2001,2003,2004 David H. Hovemeyer <daveho@cs.umd.edu>
 * Copyright (c) 2003 Jeffrey K. Hollingsworth <hollings@cs.umd.edu>
 *
 * This file is not distributed under the standard GeekOS license.
 * Publication or redistribution of this file without permission of
 * the author(s) is prohibited.
 */
/*************************************************************************/
#ifndef GEEKOS_CRC32_H
#define GEEKOS_CRC32_H

#include <stddef.h>
#include <geekos/ktypes.h>

void Init_CRC32(void);
ulong_t crc32(ulong_t crc, char const *buf, size_t len);

#endif /* GEEKOS_CRC32_H */
