/*************************************************************************/
/*
 * GeekOS master source distribution and/or project solution
 * Copyright (c) 2001,2003,2004 David H. Hovemeyer <daveho@cs.umd.edu>
 * Copyright (c) 2003 Jeffrey K. Hollingsworth <hollings@cs.umd.edu>
 *
 * This file is not distributed under the standard GeekOS license.
 * Publication or redistribution of this file without permission of
 * the author(s) is prohibited.
 */
/*************************************************************************/
/*
 * A acl test program for GeekOS user mode
 */

#include "libuser.h"

void Main(int argc, char *argv[])
{
    int ret;
    int perm;

    if (argc != 4) {
        Print("Usage: setacl <file> <uid> [r | w | rw | clear\n");
	Exit();
    }

    if (!strcmp(argv[3], "r")) {
        perm = O_READ;
    } else if (!strcmp(argv[3], "rw")) {
        perm = O_READ|O_WRITE;
    } else if (!strcmp(argv[3], "w")) {
        perm = O_WRITE;
    } else if (!strcmp(argv[3], "clear")) {
        perm = 0;
    } else {
        Print("Usage: setacl <file> <uid> [r | w | rw | clear\n");
	Exit();
    }

    ret = SetAcl(argv[1], atoi(argv[2]), perm);
    if (ret) {
        Print("SetAcl returned %d\n", ret);
    }
}
