/*************************************************************************/
/*
 * GeekOS master source distribution and/or project solution
 * Copyright (c) 2001,2003,2004,2006 David H. Hovemeyer <daveho@cs.umd.edu>
 * Copyright (c) 2003 Jeffrey K. Hollingsworth <hollings@cs.umd.edu>
 *
 * This file is not distributed under the standard GeekOS license.
 * Publication or redistribution of this file without permission of
 * the author(s) is prohibited.
 */
/*************************************************************************/
/*
 * System call handlers
 * Copyright (c) 2003, Jeffrey K. Hollingsworth <hollings@cs.umd.edu>
 * Copyright (c) 2003,2004,2006 David Hovemeyer <daveho@cs.umd.edu>
 * $Revision: 1.61 $
 * 
 * This is free software.  You are permitted to use,
 * redistribute, and modify it as specified in the file "COPYING".
 */

#include <geekos/syscall.h>
#include <geekos/errno.h>
#include <geekos/kthread.h>
#include <geekos/int.h>
#include <geekos/elf.h>
#include <geekos/malloc.h>
#include <geekos/screen.h>
#include <geekos/keyboard.h>
#include <geekos/string.h>
#include <geekos/user.h>
#include <geekos/timer.h>
#include <geekos/pipefs.h>
#include <geekos/vfs.h>

/*
 * Allocate a buffer for a user string, and
 * copy it into kernel space.
 * Interrupts must be disabled.
 */
static int Copy_User_String(ulong_t uaddr, ulong_t len, ulong_t maxLen, char **pStr)
{
    int rc = 0;
    char *str;

    /* Ensure that string isn't too long. */
    if (len > maxLen)
	return EINVALID;

    /* Allocate space for the string. */
    str = (char*) Malloc(len+1);
    if (str == 0) {
	rc = ENOMEM;
	goto done;
    }

    /* Copy data from user space. */
    if (!Copy_From_User(str, uaddr, len)) {
	rc = EINVALID;
	Free(str);
	goto done;
    }
    str[len] = '\0';

    /* Success! */
    *pStr = str;

done:
    return rc;
}

/*
 * Get a file for a specified file descriptor
 * from the current process.
 * Returns null if the file descriptor is not valid.
 */
static struct File *Get_File(int fd)
{
    KASSERT(g_currentThread != 0);
    KASSERT(g_currentThread->userContext != 0);

    if (fd < 0 || fd >= USER_MAX_FILES)
	return 0;

    return g_currentThread->userContext->fileList[fd];
}

/*
 * Get available file descriptor.
 * Returns -1 if file table is full.
 */
static int Get_Avail_FD(void)
{
    int i;

    KASSERT(g_currentThread != 0);
    KASSERT(g_currentThread->userContext != 0);

    for (i = 0; i < USER_MAX_FILES; ++i) {
	if (g_currentThread->userContext->fileList[i] == 0)
	    return i;
    }

    return -1;
}

/*
 * Get two available file descriptors.
 * Returns 0 if successful, error code if can't
 * allocate two fds.
 */
static int Get_Two_Avail_FDs(int *fd1, int *fd2)
{
    int nAlloc = 0, i;
    int *fdList[2] = {fd1, fd2};

    for (i = 0; nAlloc < 2 && i < USER_MAX_FILES; ++i) {
	if (g_currentThread->userContext->fileList[i] == 0) {
	    *(fdList[nAlloc]) = i;
	    ++nAlloc;
	}
    }

    return (nAlloc == 2) ? 0 : EMFILE;
}

/*
 * Null system call.
 * Does nothing except immediately return control back
 * to the interrupted user program.
 * Params:
 *  state - processor registers from user mode
 *
 * Returns:
 *   always returns the value 0 (zero)
 */
static int Sys_Null(struct Interrupt_State* state)
{
    return 0;
}

/*
 * Exit system call.
 * The interrupted user process is terminated.
 * Params:
 *   state->ebx - process exit code
 * Returns:
 *   Never returns to user mode!
 */
static int Sys_Exit(struct Interrupt_State* state)
{
    Exit(state->ebx);
    /* We will never get here. */
}

/*
 * Print a string to the console.
 * Params:
 *   state->ebx - user pointer of string to be printed
 *   state->ecx - number of characters to print
 * Returns: 0 if successful, -1 if not
 */
static int Sys_PrintString(struct Interrupt_State* state)
{
    int rc = 0;
    uint_t length = state->ecx;
    uchar_t* buf = 0;

    if (length > 0) {
	/* Copy string into kernel. */
	if ((rc = Copy_User_String(state->ebx, length, 1023, (char**) &buf)) != 0)
	    goto done;

	/* Write to console. */
	Put_Buf(buf, length);
    }

done:
    if (buf != 0)
	Free(buf);
    return rc;
}

/*
 * Get a single key press from the console.
 * Suspends the user process until a key press is available.
 * Params:
 *   state - processor registers from user mode
 * Returns: the key code
 */
static int Sys_GetKey(struct Interrupt_State* state)
{
    return Wait_For_Key();
}

/*
 * Set the current text attributes.
 * Params:
 *   state->ebx - character attributes to use
 * Returns: always returns 0
 */
static int Sys_SetAttr(struct Interrupt_State* state)
{
    Set_Current_Attr((uchar_t) state->ebx);
    return 0;
}

/*
 * Get the current cursor position.
 * Params:
 *   state->ebx - pointer to user int where row value should be stored
 *   state->ecx - pointer to user int where column value should be stored
 * Returns: 0 if successful, -1 otherwise
 */
static int Sys_GetCursor(struct Interrupt_State* state)
{
    int row, col;
    Get_Cursor(&row, &col);
    if (!Copy_To_User(state->ebx, &row, sizeof(int)) ||
	!Copy_To_User(state->ecx, &col, sizeof(int)))
	return -1;
    return 0;
}

/*
 * Set the current cursor position.
 * Params:
 *   state->ebx - new row value
 *   state->ecx - new column value
 * Returns: 0 if successful, -1 otherwise
 */
static int Sys_PutCursor(struct Interrupt_State* state)
{
    return Put_Cursor(state->ebx, state->ecx) ? 0 : -1;
}

/*
 * Create a new user process.
 * Params:
 *   state->ebx - user address of name of executable
 *   state->ecx - length of executable name
 *   state->edx - user address of command string
 *   state->esi - length of command string
 *   state->edi == stdin file descriptor in low 16 bits, stdout file descriptor in high 16 bits
 * Returns: pid of process if successful, error code (< 0) otherwise
 */
static int Sys_Spawn(struct Interrupt_State* state)
{
    int rc;
    char *program = 0;
    char *command = 0;
    struct File *stdInput, *stdOutput;
    struct Kernel_Thread *process;

    /* Copy program name and command from user space. */
    if ((rc = Copy_User_String(state->ebx, state->ecx, VFS_MAX_PATH_LEN, &program)) != 0 ||
	(rc = Copy_User_String(state->edx, state->esi, 1023, &command)) != 0)
	goto done;

    Enable_Interrupts();

    /*
     * Get stdin and stdout for new process from parent's file table.
     */
    stdInput = Get_File(state->edi & 0xff);
    stdOutput = Get_File(state->edi >> 16);

    /*
     * Now that we have collected the program name and command string
     * from user space, we can try to actually spawn the process.
     */
    rc = Spawn(program, command, stdInput, stdOutput, &process);
    if (rc == 0) {
	KASSERT(process != 0);
	rc = process->pid;
    }

    Disable_Interrupts();

done:
    if (program != 0)
	Free(program);
    if (command != 0)
	Free(command);

    return rc;
}

/*
 * Wait for a process to exit.
 * Params:
 *   state->ebx - pid of process to wait for
 * Returns: the exit code of the process,
 *   or error code (< 0) on error
 */
static int Sys_Wait(struct Interrupt_State* state)
{
    int exitCode;
    struct Kernel_Thread *kthread = Lookup_Thread(state->ebx);
    if (kthread == 0)
	return -1;

    Enable_Interrupts();
    exitCode = Join(kthread);
    Disable_Interrupts();

    return exitCode;
}

/*
 * Get pid (process id) of current thread.
 * Params:
 *   state - processor registers from user mode
 * Returns: the pid of the current thread
 */
static int Sys_GetPID(struct Interrupt_State* state)
{
    return g_currentThread->pid;
}

/*
 * Set the scheduling policy.
 * Params:
 *   state->ebx - policy,
 *   state->ecx - number of ticks in quantum
 * Returns: 0 if successful, -1 otherwise
 */
static int Sys_SetSchedulingPolicy(struct Interrupt_State* state)
{
    TODO("SetSchedulingPolicy system call");
}

/*
 * Get the time of day.
 * Params:
 *   state - processor registers from user mode
 *
 * Returns: value of the g_numTicks global variable
 */
static int Sys_GetTimeOfDay(struct Interrupt_State* state)
{
    return g_numTicks;
}

/*
 * Create a semaphore.
 * Params:
 *   state->ebx - user address of name of semaphore
 *   state->ecx - length of semaphore name
 *   state->edx - initial semaphore count
 * Returns: the global semaphore id
 */
static int Sys_CreateSemaphore(struct Interrupt_State* state)
{
    TODO("CreateSemaphore system call");
}

/*
 * Acquire a semaphore.
 * Assume that the process has permission to access the semaphore,
 * the call will block until the semaphore count is >= 0.
 * Params:
 *   state->ebx - the semaphore id
 *
 * Returns: 0 if successful, error code (< 0) if unsuccessful
 */
static int Sys_P(struct Interrupt_State* state)
{
    TODO("P (semaphore acquire) system call");
}

/*
 * Release a semaphore.
 * Params:
 *   state->ebx - the semaphore id
 *
 * Returns: 0 if successful, error code (< 0) if unsuccessful
 */
static int Sys_V(struct Interrupt_State* state)
{
    TODO("V (semaphore release) system call");
}

/*
 * Destroy a semaphore.
 * Params:
 *   state->ebx - the semaphore id
 *
 * Returns: 0 if successful, error code (< 0) if unsuccessful
 */
static int Sys_DestroySemaphore(struct Interrupt_State* state)
{
    TODO("DestroySemaphore system call");
}

/*
 * Mount a filesystem.
 * Params:
 * state->ebx - contains a pointer to the Mount_Syscall_Args structure
 *   which contains the block device name, mount prefix,
 *   and filesystem type
 *
 * Returns:
 *   0 if successful, error code if unsuccessful
 */
static int Sys_Mount(struct Interrupt_State *state)
{
    int rc = 0;
    struct VFS_Mount_Request *args = 0;

    /* Allocate space for VFS_Mount_Request struct. */
    if ((args = (struct VFS_Mount_Request *) Malloc(sizeof(struct VFS_Mount_Request))) == 0) {
	rc = ENOMEM;
	goto done;
    }

    /* Copy the mount arguments structure from user space. */
    if (!Copy_From_User(args, state->ebx, sizeof(struct VFS_Mount_Request))) {
	rc = EINVALID;
	goto done;
    }

    /* Ensure that the strings are properly nul-terminated. */
    if (strnlen(args->devname, sizeof(args->devname)) == sizeof(args->devname) ||
	strnlen(args->prefix, sizeof(args->prefix)) == sizeof(args->prefix) ||
	strnlen(args->fstype, sizeof(args->fstype)) == sizeof(args->fstype)) {
	rc = EINVALID;
	goto done;
    }

    Enable_Interrupts();
    rc = Mount(args->devname, args->prefix, args->fstype);
    Disable_Interrupts();

done:
    if (args != 0) Free(args);
    return rc;
}

/*
 * Open a file.
 * Params:
 *   state->ebx - address of user string containing path of file to open
 *   state->ecx - length of path
 *   state->edx - file mode flags
 *
 * Returns: a file descriptor (>= 0) if successful,
 *   or an error code (< 0) if unsuccessful
 */
static int Sys_Open(struct Interrupt_State *state)
{
    int fd, rc;
    char *path = 0;
    struct File *file;

    if ((fd = Get_Avail_FD()) < 0) {
	rc = EMFILE;
	goto done;
    }

    if ((rc = Copy_User_String(state->ebx, state->ecx, VFS_MAX_PATH_LEN, &path)) != 0)
	goto done;

    Enable_Interrupts();
    rc = Open(path, (int) state->edx, &file);
    Disable_Interrupts();

    if (rc == 0) {
	g_currentThread->userContext->fileList[fd] = file;
	rc = fd;
    }

done:
    if (path != 0)
	Free(path);
    return rc;
}

/*
 * Open a directory.
 * Params:
 *   state->ebx - address of user string containing path of directory to open
 *   state->ecx - length of path
 *
 * Returns: a file descriptor (>= 0) if successful,
 *   or an error code (< 0) if unsuccessful
 */
static int Sys_OpenDirectory(struct Interrupt_State *state)
{
    int fd, rc;
    char *path = 0;
    struct File *dir;

    /* Get an available file descriptor. */
    fd = Get_Avail_FD();
    if (fd < 0) {
	rc = EMFILE;
	goto done;
    }

    /* Copy in the path. */
    if ((rc = Copy_User_String(state->ebx, state->ecx, VFS_MAX_PATH_LEN, &path)) != 0)
	goto done;

    /* Call into VFS Open_Directory() function. */
    Enable_Interrupts();
    rc = Open_Directory(path, &dir);
    Disable_Interrupts();

    /* If directory successfully opened, add it to process file table. */
    if (rc == 0)
	g_currentThread->userContext->fileList[fd] = dir;

done:
    if (path != 0)
	Free(path);
    return (rc == 0) ? fd : rc;
}

/*
 * Close an open file or directory.
 * Params:
 *   state->ebx - file descriptor of the open file or directory
 * Returns: 0 if successful, or an error code (< 0) if unsuccessful
 */
static int Sys_Close(struct Interrupt_State *state)
{
    int fd = state->ebx, rc;
    struct File *file = Get_File(fd);

    if (file == 0)
	return EINVALID;

    Enable_Interrupts();
    rc = Close(file);
    Disable_Interrupts();

    if (rc == 0)
	g_currentThread->userContext->fileList[fd] = 0;
    return rc;
}

/*
 * Delete a file.
 * Params:
 *   state->ebx - address of user string containing path to delete
 *   state->ecx - length of path
 *
 * Returns: 0 if successful, error code (< 0) if unsuccessful
 */
static int Sys_Delete(struct Interrupt_State *state)
{
    TODO("Delete system call");
}

/*
 * Read from an open file.
 * Params:
 *   state->ebx - file descriptor to read from
 *   state->ecx - user address of buffer to read into
 *   state->edx - number of bytes to read
 *
 * Returns: number of bytes read, 0 if end of file,
 *   or error code (< 0) on error
 */
static int Sys_Read(struct Interrupt_State *state)
{
    int rc;
    void *buf = 0;
    ulong_t uaddr = state->ecx;
    ulong_t len = state->edx;
    struct File *file;

    file = Get_File(state->ebx);
    if (file == 0) {
	rc = EINVALID;
	goto done;
    }

    if ((buf = Malloc(len)) == 0) {
	rc = ENOMEM;
	goto done;
    }

    Enable_Interrupts();
    rc = Read(file, buf, len);
    Disable_Interrupts();

    if (rc > 0 && !Copy_To_User(uaddr, buf, rc))
	rc = EINVALID;

done:
    if (buf != 0) {
	Free(buf);
    }
    return rc;
}

/*
 * Read a directory entry from an open directory handle.
 * Params:
 *   state->ebx - file descriptor of the directory
 *   state->ecx - user address of struct VFS_Dir_Entry to copy entry into
 * Returns: 0 if successful, error code (< 0) if unsuccessful
 */
static int Sys_ReadEntry(struct Interrupt_State *state)
{
    int rc;
    struct VFS_Dir_Entry dirent;
    struct File *dir;

    /* FIXME: should not allocate dir entry on stack */

    /* Look up file descriptor */
    dir = Get_File(state->ebx);
    if (dir == 0) {
	rc = EINVALID;
	goto done;
    }

    /* Call into VFS */
    Enable_Interrupts();
    rc = Read_Entry(dir, &dirent);
    Disable_Interrupts();

    /* If entry was successfully read from directory, copy into user buffer */
    if (rc == 0 && !Copy_To_User(state->ecx, &dirent, sizeof(struct VFS_Dir_Entry)))
	rc = EINVALID;

done:
    return rc;
}

/*
 * Write to an open file.
 * Params:
 *   state->ebx - file descriptor to write to
 *   state->ecx - user address of buffer get data to write from
 *   state->edx - number of bytes to write
 *
 * Returns: number of bytes written,
 *   or error code (< 0) on error
 */
static int Sys_Write(struct Interrupt_State *state)
{
    /*
     * FIXME: we copy the entire user buffer into a kernel heap buffer;
     * would be much better to arrange IO directly from user memory
     */
    int rc;
    ulong_t uaddr, len;
    struct File *file;
    void *buf = 0;

    file = Get_File(state->ebx);
    if (file == 0) {
	rc = EINVALID;
	goto done;
    }

    uaddr = state->ecx;
    len = state->edx;

    if (len == 0) {
	rc = 0;
	goto done;
    }

    if ((buf = Malloc(len)) == 0) {
	rc = ENOMEM;
	goto done;
    }
    if (!Copy_From_User(buf, uaddr, len)) {
	rc = EINVALID;
	goto done;
    }

    Enable_Interrupts();
    rc = Write(file, buf, len);
    Disable_Interrupts();

done:
    if (buf != 0)
	Free(buf);
    return rc;
}

/*
 * Get file metadata.
 * Params:
 *   state->ebx - address of user string containing path of file
 *   state->ecx - length of path
 *   state->edx - user address of struct VFS_File_Stat object to store metadata in
 *
 * Returns: 0 if successful, error code (< 0) if unsuccessful
 */
static int Sys_Stat(struct Interrupt_State *state)
{
    int rc = 0;
    char *path = 0;
    struct VFS_File_Stat stat;

    /* Copy the path into kernel space. */
    if ((rc = Copy_User_String(state->ebx, state->ecx, VFS_MAX_PATH_LEN, &path)) != 0)
	goto done;

    /*
     * Call VFS Stat() operation. 
     * Interrupts must be enabled for VFS calls.
     */
    Enable_Interrupts();
    rc = Stat(path, &stat);
    Disable_Interrupts();

    if (rc != 0)
	goto done;

    /* Copy result into user stat buffer. */
    if (!Copy_To_User(state->edx, &stat, sizeof(stat))) {
	rc = EINVALID;
	goto done;
    }

done:
    if (path != 0)
	Free(path);
    return rc;
}

/*
 * Get metadata of an open file.
 * Params:
 *   state->ebx - file descriptor to get metadata for
 *   state->ecx - user address of struct VFS_File_Stat object to store metadata in
 *
 * Returns: 0 if successful, error code (< 0) if unsuccessful
 */
static int Sys_FStat(struct Interrupt_State *state)
{
    int rc;
    struct File *file;
    struct VFS_File_Stat stat;

    file = Get_File(state->ebx);
    if (file == 0)
	return EINVALID;

    if ((rc = FStat(file, &stat)) != 0)
	goto done;

    if (!Copy_To_User(state->ecx, &stat, sizeof(stat)))
	rc = EINVALID;

done:
    return rc;
}

/*
 * Change the access position in a file
 * Params:
 *   state->ebx - file descriptor 
 *   state->ecx - position in file
 *
 * Returns: 0 if successful, error code (< 0) if unsuccessful
 */
static int Sys_Seek(struct Interrupt_State *state)
{
    TODO("Seek system call");
}

/*
 * Create directory
 * Params:
 *   state->ebx - address of user string containing path of new directory
 *   state->ecx - length of path
 *
 * Returns: 0 if successful, error code (< 0) if unsuccessful
 */
static int Sys_CreateDir(struct Interrupt_State *state)
{
    int rc;
    char *path = 0;

    if ((rc = Copy_User_String(state->ebx, state->ecx, VFS_MAX_PATH_LEN, &path)) != 0)
	goto done;

    Enable_Interrupts();
    rc = Create_Directory(path);
    Disable_Interrupts();

done:
    if (path != 0)
	Free(path);
    return rc;
}

/*
 * Flush filesystem buffers
 * Params: none 
 * Returns: 0 if successful, error code (< 0) if unsuccessful
 */
static int Sys_Sync(struct Interrupt_State *state)
{
    int rc;

    Enable_Interrupts();
    rc = Sync();
    Disable_Interrupts();

    return rc;
}
/*
 * Format a device
 * Params:
 *   state->ebx - address of user string containing device to format
 *   state->ecx - length of device name string
 *   state->edx - address of user string containing filesystem type 
 *   state->esi - length of filesystem type string

 * Returns: 0 if successful, error code (< 0) if unsuccessful
 */
static int Sys_Format(struct Interrupt_State *state)
{
    int rc = 0;
    char *devname = 0, *fstype = 0;

    if ((rc = Copy_User_String(state->ebx, state->ecx, BLOCKDEV_MAX_NAME_LEN, &devname)) != 0 ||
	(rc = Copy_User_String(state->edx, state->esi, VFS_MAX_FS_NAME_LEN, &fstype)) != 0)
	goto done;

    Enable_Interrupts();
    rc = Format(devname, fstype);
    Disable_Interrupts();

done:
    if (devname != 0)
	Free(devname);
    if (fstype != 0)
	Free(fstype);
    return rc;
}

static int Sys_CreatePipe(struct Interrupt_State *state)
{
    int rc = 0;
    int readfd, writefd;
    struct File *readFile = 0, *writeFile = 0;

    Enable_Interrupts();

    /* Allocate file descriptors and create the pipe */
    rc = Get_Two_Avail_FDs(&readfd, &writefd);
    if (rc == 0)
	rc = Create_Pipe(&readFile, &writeFile);

    Disable_Interrupts();

    if (rc != 0)
	goto done;

    /* Copy file descriptor numbers to user space */
    if (!Copy_To_User(state->ebx, &readfd, sizeof(int)) ||
	!Copy_To_User(state->ecx, &writefd, sizeof(int))) {
	rc = EINVALID;
	goto done;
    }

    /* Populate user file table */
    g_currentThread->userContext->fileList[readfd] = readFile;
    g_currentThread->userContext->fileList[writefd] = writeFile;

done:

    if (rc != 0) {
	if (readFile != 0)
	    Close(readFile);
	if (writeFile != 0)
	    Close(writeFile);
    }
    return rc;
}

static int Sys_IsATTY(struct Interrupt_State* state)
{
    int rc;
    struct File *file;

    file = Get_File(state->ebx);
    if (file == 0) {
	rc = EINVALID;
	goto done;
    }

    rc = (file->mode & O_TTY) != 0;

done:
    return rc;
}

/*
 * Global table of system call handler functions.
 */
const Syscall g_syscallTable[] = {
    Sys_Null,
    Sys_Exit,
    Sys_PrintString,
    Sys_GetKey,
    Sys_SetAttr,
    Sys_GetCursor,
    Sys_PutCursor,
    Sys_Spawn,
    Sys_Wait,
    Sys_GetPID,
    /* Scheduling and semaphore system calls. */
    Sys_SetSchedulingPolicy,
    Sys_GetTimeOfDay,
    Sys_CreateSemaphore,
    Sys_P,
    Sys_V,
    Sys_DestroySemaphore,
    /* File I/O system calls. */
    Sys_Mount,
    Sys_Open,
    Sys_OpenDirectory,
    Sys_Close,
    Sys_Delete,
    Sys_Read,
    Sys_ReadEntry,
    Sys_Write,
    Sys_Stat,
    Sys_FStat,
    Sys_Seek,
    Sys_CreateDir,
    Sys_Sync,
    Sys_Format,
    /* Pipe system calls. */
    Sys_CreatePipe,
    Sys_IsATTY,
};

/*
 * Number of system calls implemented.
 */
const int g_numSyscalls = sizeof(g_syscallTable) / sizeof(Syscall);
