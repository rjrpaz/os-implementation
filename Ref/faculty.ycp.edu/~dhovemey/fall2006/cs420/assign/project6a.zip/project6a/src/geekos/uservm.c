/*************************************************************************/
/*
 * GeekOS master source distribution and/or project solution
 * Copyright (c) 2001,2003,2004 David H. Hovemeyer <daveho@cs.umd.edu>
 * Copyright (c) 2003 Jeffrey K. Hollingsworth <hollings@cs.umd.edu>
 *
 * This file is not distributed under the standard GeekOS license.
 * Publication or redistribution of this file without permission of
 * the author(s) is prohibited.
 */
/*************************************************************************/
/*
 * Paging-based user mode implementation
 * Copyright (c) 2003,2004 David H. Hovemeyer <daveho@cs.umd.edu>
 * $Revision: 1.50 $
 * 
 * This is free software.  You are permitted to use,
 * redistribute, and modify it as specified in the file "COPYING".
 */

#include <geekos/int.h>
#include <geekos/mem.h>
#include <geekos/paging.h>
#include <geekos/malloc.h>
#include <geekos/string.h>
#include <geekos/argblock.h>
#include <geekos/kthread.h>
#include <geekos/range.h>
#include <geekos/vfs.h>
#include <geekos/user.h>

int userDebug = 0;
#define Debug(args...) if (userDebug) Print("uservm: " args)

/* ----------------------------------------------------------------------
 * Private functions
 * ---------------------------------------------------------------------- */

#define MAX_USER_STACK_SIZE (1024*1024*2)

static ulong_t Get_Current_Stack_Size(struct User_Context *userContext)
{
    KASSERT(userContext->stackPointerAddr > userContext->stackBottom);
    return userContext->stackPointerAddr - userContext->stackBottom;
}

/*
 * Allocate a span of user pages.
 */
static bool Allocate_User_Page_Span(struct User_Context *userContext,
    ulong_t start, ulong_t size, int flags)
{
    ulong_t offset;
    extern ulong_t g_numTicks;

    for (offset = 0; offset < size; offset += PAGE_SIZE) {
	ulong_t addr = start + offset;
	ulong_t userVA = addr + USER_VM_START;
	pte_t *pageTable;
	void *paddr;
	struct Page *page;

	KASSERT(addr < USER_VM_SIZE);

	pageTable = Ensure_Page_Table_Exists(userContext->pageDir, userVA, flags|VM_WRITE);
	if (pageTable == 0)
	    return false;

	paddr = Lookup_Page(pageTable, userVA);
	if (paddr == 0) {
	    paddr = Alloc_Pageable_Page(&pageTable[PAGE_TABLE_INDEX(userVA)], userVA);
	    if (paddr == 0)
		return false;
	    memset(paddr, '\0', PAGE_SIZE);
	    Add_PTE(pageTable, userVA, paddr, flags);
	}

	/* Update clock field of page. */
	page = Get_Page((ulong_t) paddr);
	KASSERT(page != 0);
	page->clock = g_numTicks;
    }

    return true;
}

/*
 * Copy segment data from a file into user memory.
 */
static bool Copy_Segment_Data(struct User_Context *userContext,
    char *exeFileData, ulong_t exeFileLength, struct Exe_Segment *segment)
{
    ulong_t start = Round_Down_To_Page(segment->startAddress);
    ulong_t offsetInPage = segment->startAddress & PAGE_MASK;
    char *fileData = exeFileData + segment->offsetInFile;
    ulong_t bytesRemaining = segment->lengthInFile;
    ulong_t addr;

    Debug("length in file=%lu, size in mem=%lu\n",segment->lengthInFile,segment->sizeInMemory);

    /* FIXME: range check */
    if (segment->offsetInFile + segment->lengthInFile > exeFileLength)
	return false;

    KASSERT(segment->lengthInFile <= segment->sizeInMemory);

    for (addr = start; bytesRemaining > 0; addr += PAGE_SIZE) {
	ulong_t userVA = addr + USER_VM_START;
	void *page;
	ulong_t len;

	KASSERT(offsetInPage == 0 || fileData == (exeFileData + segment->offsetInFile));

	page = Lookup_Page_From_PD(userContext->pageDir, userVA);
	KASSERT(page != 0);

	/* Copy data into page. */
	len = PAGE_SIZE - offsetInPage;
	if (len > bytesRemaining)
	    len = bytesRemaining;
	memcpy(((char*)page) + offsetInPage, fileData, len);
	fileData += len;
	bytesRemaining -= len;
	offsetInPage = 0UL;
    }
    KASSERT(bytesRemaining == 0);

    return true;
}

typedef void (*UK_Copy_Func)(void* kaddr, ulong_t uaddr, ulong_t numBytes);

/**
 * Copy data from user buffer into kernel buffer.
 * Page containing user data must be locked!
 */
static void UK_Copy_In(void *kaddr, ulong_t uaddr, ulong_t numBytes)
{
    memcpy(kaddr, (void*) uaddr, numBytes);
}

/**
 * Copy data from kernel buffer into user buffer.
 * Page containing user data must be locked!
 */
static void UK_Copy_Out(void *kaddr, ulong_t uaddr, ulong_t numBytes)
{
    memcpy((void*) uaddr, kaddr, numBytes);
}

/**
 * Common implementation function for copyin and copyout.
 * Traverses the user buffer one page at a time, locking each
 * page into memory and copying the relevant part of the page.
 * @param kaddr address of kernel buffer
 * @param uaddr address of user buffer
 * @param numBytes number of bytes to be copied
 * @param copyfunc function to copy to/from user space
 * @return true if the entire region can be copied, false if not
 */
static bool User_Kernel_Copy(void *kaddr, ulong_t uaddr, ulong_t numBytes, UK_Copy_Func copyfunc)
{
    ulong_t userVA = uaddr + USER_VM_START;
    ulong_t numCopied = 0;
    struct User_Context *userContext = g_currentThread->userContext;

    KASSERT(userContext != 0);

    if (!Check_Range_Proper(userVA, numBytes))
	return false;

    while (numCopied < numBytes) {
	ulong_t pageVA = Round_Down_To_Page(userVA);
	ulong_t toCopy = PAGE_SIZE;

	if (!Lock_Page(userContext, pageVA))
	    return false;

	if (!Is_Page_Multiple(userVA))
	    toCopy -= (userVA & (PAGE_SIZE-1));

	if (toCopy > numBytes)
	    toCopy = numBytes;

	/* FIXME: need to check for write to read-only user memory! */

	copyfunc(kaddr, userVA, toCopy);

	Unlock_Page(userContext, pageVA);

	userVA = Round_Down_To_Page(userVA + PAGE_SIZE);
	kaddr = (void*) ((char*)kaddr + toCopy);
	numCopied += toCopy;
    }

    return true;
}

/* ----------------------------------------------------------------------
 * Public functions
 * ---------------------------------------------------------------------- */

/*
 * Destroy a User_Context object, including all memory
 * and other resources allocated within it.
 */
void Destroy_User_Context(struct User_Context* context)
{
    unsigned i;

    /* Disable interrupts while freeing pageable memory. */
    Disable_Interrupts();

    /*
     * Traverse user portion of address space,
     * freeing pages and page tables
     */
    for (i = NUM_KERNEL_PD_ENTRIES; i < NUM_PAGE_DIR_ENTRIES; ++i) {
	pde_t pde = context->pageDir[i];
	ulong_t baseAddr = i * VM_PT_SPAN;

	/* Is there are page table in this page directory slot? */
	if (pde.present) {
	    unsigned j;
	    pte_t *pageTable = Lookup_Page_Table(context->pageDir, baseAddr);

	    KASSERT(pageTable != 0);

	    /* Free all of the pages in this page table */
	    for (j = 0; j < NUM_PAGE_TABLE_ENTRIES; ++j) {
		pte_t pte = pageTable[j];
		ulong_t pageAddr = baseAddr + (j * PAGE_SIZE);

		if (pte.present) {
		    /* Page is mapped into memory, so free it */
		    void *page = Lookup_Page(pageTable, pageAddr);
		    KASSERT(page != 0);
		    Free_Page(page);
		} else if (pte.kernelInfo & KINFO_PAGE_ON_DISK) {
		    /* Page is on disk; just purge it from the paging file */
		    Free_Space_On_Paging_File(pte.pageBaseAddr);
		}
	    }

	    /* Free the page table */
	    Free_Page(pageTable);
	}
    }

    /*
     * Now that we've freed all pageable memory, we can
     * re-enable interrupts.
     */
    Enable_Interrupts();

    /* Free the page directory */
    Free_Page(context->pageDir);

    /* FIXME: free semaphores */

    /* Close open files. */
    for (i = 0; i < USER_MAX_FILES; ++i) {
	struct File *file = context->fileList[i];
	if (file != 0) {
	    Close(file);
	    context->fileList[i] = 0;
	}
    }

    /* Now we can free the user context */
    Free(context);
}

/*
 * Load a user executable into memory by creating a User_Context
 * data structure.
 * Params:
 * exeFileData - a buffer containing the executable to load
 * exeFileLength - number of bytes in exeFileData
 * exeFormat - parsed ELF segment information describing how to
 *   load the executable's text and data segments, and the
 *   code entry point address
 * command - string containing the complete command to be executed:
 *   this should be used to create the argument block for the
 *   process
 * pUserContext - reference to the pointer where the User_Context
 *   should be stored
 *
 * Returns:
 *   0 if successful, or an error code (< 0) if unsuccessful
 */
int Load_User_Program(char *exeFileData, ulong_t exeFileLength,
    struct Exe_Format *exeFormat, const char *command,
    struct User_Context **pUserContext)
{
    int i;
    ulong_t maxva = 0;
    unsigned numArgs;
    ulong_t argBlockSize;
    struct User_Context *userContext = 0;
    ulong_t avail;
    ulong_t argBlockAddr;

    /* Determine size required for argument block */
    Get_Argument_Block_Size(command, &numArgs, &argBlockSize);
    argBlockSize = Round_Up_To_Page(argBlockSize);
    argBlockAddr = USER_VM_SIZE - argBlockSize;

    /* Determine highest virtual address used by executable code/data */
    for (i = 0; i < exeFormat->numSegments; ++i) {
	struct Exe_Segment *segment = &exeFormat->segmentList[i];
	ulong_t topva = segment->startAddress + segment->sizeInMemory;  /* FIXME: range check */

	if (topva > maxva)
	    maxva = topva;
    }
    maxva = Round_Up_To_Page(maxva);

    /*
     * Make sure there is enough room for everything (executable code/data,
     * user stack, and argument block).
     */
    avail = USER_VM_SIZE;
    if (maxva > avail)
	goto fail;
    avail -= maxva;
    if (argBlockSize > avail)
	goto fail;
    avail -= argBlockSize;
    if (MAX_USER_STACK_SIZE > avail)
	goto fail;

    /* Create user context */
    userContext = (struct User_Context*) Malloc(sizeof(*userContext));
    if (userContext == 0)
	goto fail;

    /* Create page directory for address space */
    userContext->pageDir = (pde_t*) Alloc_Page();
    if (userContext->pageDir == 0)
	goto fail;
    memset(userContext->pageDir, '\0', PAGE_SIZE);

    /* Copy kernel address space entries from the kernel page directory */
    KASSERT(NUM_KERNEL_PD_ENTRIES == 512);
    memcpy(userContext->pageDir, g_kernelPageDir, NUM_KERNEL_PD_ENTRIES * sizeof(pde_t));

    /*
     * All virtual memory setup has to be done with interrupts
     * disabled.  This is lame, but because we have no way to lock
     * the pages to prevent them from being stolen by other
     * processes, necessary.
     * TODO: this could be avoided by using Alloc_Page, and then
     * manually marking the pages as PAGE_PAGEABLE and setting
     * the PTEs in the Page objects after the segment data has been
     * copied in.
     */
    Disable_Interrupts();

    /* Map executable segments into virtual memory. */
    for (i = 0; i < exeFormat->numSegments; ++i) {
	struct Exe_Segment *segment = &exeFormat->segmentList[i];
	ulong_t start = Round_Down_To_Page(segment->startAddress);
	ulong_t end = Round_Up_To_Page(segment->startAddress + segment->sizeInMemory);

	/* Create an allocated region of memory for the segment */
	if (!Allocate_User_Page_Span(userContext, start, end - start, VM_USER|segment->protFlags))
	    goto fail;

	/* Copy executable code and data into the segment */
	if (!Copy_Segment_Data(userContext, exeFileData, exeFileLength, segment))
	    goto fail;
    }

    /*
     * Build argument block
     * We put this at the top of the address space
     */
    {
	char *buf;
	ulong_t offset;

	Debug("argBlock at %lx\n", argBlockAddr);

	if (!Allocate_User_Page_Span(userContext, argBlockAddr, argBlockSize, RO_USER_VM_FLAGS))
	    goto fail;
	buf = (char*) Malloc(argBlockSize);
	if (buf == 0)
	    goto fail;
	Format_Argument_Block(buf, numArgs, argBlockAddr, command);
	for (offset = 0; offset < argBlockSize; offset += PAGE_SIZE) {
	    ulong_t userVA = USER_VM_START + argBlockAddr + offset;
	    void *page = Lookup_Page_From_PD(userContext->pageDir, userVA);
	    KASSERT(page != 0);
	    memcpy(page, buf + offset, PAGE_SIZE);
	}
	Free(buf);
    }

    /* Set up initial stack page */
    userContext->stackBottom = argBlockAddr - PAGE_SIZE;
    Debug("Stack page at %lx\n", userContext->stackBottom);
    if (!Allocate_User_Page_Span(userContext, userContext->stackBottom,
				PAGE_SIZE, RW_USER_VM_FLAGS))
	goto fail;

    /*
     * Fill in fields required to actually start the process;
     * entry address and such
     */
    userContext->entryAddr = exeFormat->entryAddr;
    userContext->argBlockAddr = argBlockAddr;
    userContext->stackPointerAddr = argBlockAddr;

    /* The user context is not attached to any thread yet */
    userContext->refCount = 0;

    /* No files are open yet. */
    memset(userContext->fileList, '\0', sizeof(userContext->fileList));

    /* User context is set up and ready to go */
    Enable_Interrupts();

    *pUserContext = userContext;
    return 0;

fail:
    Debug("Exe loading failed\n");

    /* Clean up allocated resources */
    if (userContext != 0)
	Destroy_User_Context(userContext);
    return -1;
}

/*
 * Copy data from user buffer into kernel buffer.
 * Returns true if successful, false otherwise.
 */
bool Copy_From_User(void* destInKernel, ulong_t srcInUser, ulong_t numBytes)
{
    return User_Kernel_Copy(destInKernel, srcInUser, numBytes, UK_Copy_In);
}

/*
 * Copy data from kernel buffer into user buffer.
 * Returns true if successful, false otherwise.
 */
bool Copy_To_User(ulong_t destInUser, void* srcInKernel, ulong_t numBytes)
{
    return User_Kernel_Copy(srcInKernel, destInUser, numBytes, UK_Copy_Out);
}

/*
 * Switch to user address space.
 */
void Switch_To_Address_Space(struct User_Context *userContext)
{
    Set_PDBR(userContext->pageDir);
}

/*
 * Lock a page into user memory, paging it in if necessary.
 */
bool Lock_Page(struct User_Context *userContext, ulong_t userVA)
{
    pte_t *pageTable, *entry;
    struct Page *page;

    KASSERT(!Interrupts_Enabled());
    KASSERT(Is_Page_Multiple(userVA));

    /*
     * Get the page table entry for the page.
     * If there is no page table covering the page, then it is obviously
     * not a legitimate part of the user address space.
     */
    pageTable = Lookup_Page_Table(userContext->pageDir, userVA);
    if (pageTable == 0)
	return false;
    entry = &pageTable[PAGE_TABLE_INDEX(userVA)];

    if (!entry->present) {
	/* Page in the page if it's on disk. */
	if (entry->kernelInfo & KINFO_PAGE_ON_DISK) {
	    Debug("Lock_Page(): paging in page @%lx\n", userVA);
	    page = Page_In_Locked(pageTable, entry, userVA);
	    if (page == 0)
		return false;
	    KASSERT((page->flags & PAGE_PAGEABLE) == 0);
	} else {
	    /* This is probably a bad user pointer passed to the kernel. */
	    return false;
	}
    } else {
	/* Page is mapped. Lock it. */
	void *paddr = Lookup_Page(pageTable, userVA);
	page = Get_Page((ulong_t) paddr);
	KASSERT(page->flags & PAGE_PAGEABLE);
	page->flags &= ~(PAGE_PAGEABLE);
    }

    KASSERT((page->flags & PAGE_PAGEABLE) == 0);
    return true;
}

void Unlock_Page(struct User_Context *userContext, ulong_t userVA)
{
    void *paddr;
    struct Page *page;

    KASSERT(!Interrupts_Enabled());
    KASSERT(Is_Page_Multiple(userVA));

    /* Page must be mapped and locked (not pageable). */
    paddr = Lookup_Page_From_PD(userContext->pageDir, userVA);
    KASSERT(paddr != 0);
    page = Get_Page((ulong_t) paddr);
    KASSERT((page->flags & PAGE_PAGEABLE) == 0);

    page->flags |= PAGE_PAGEABLE;
}

/*
 * Handle a user-space page fault.
 * Return true if fault handled successfully, so that
 * the faulting access can be retried.
 * Return false if the fault is fatal and the process
 * should be killed.
 */
bool Handle_User_Page_Fault(ulong_t address, faultcode_t faultCode)
{
    struct User_Context *userContext = g_currentThread->userContext;
    ulong_t userAddress;
    pte_t *pageTable;

    KASSERT(userContext != 0);
    KASSERT(Is_Page_Multiple(userContext->stackBottom));
    KASSERT(address >= USER_VM_START);

    /* Translate virtual address into "logical" user address */
    userAddress = address - USER_VM_START;

    Debug("Handling user page fault @%lx (stack %lx-%lx)\n",
	userAddress, userContext->stackBottom, userContext->stackPointerAddr);

    pageTable = Lookup_Page_Table(userContext->pageDir, address);

    /*
     * See if the access is to a page that was paged out
     * to disk.  If so, page it back in.
     */
    if (pageTable != 0) {
	pte_t *entry = &pageTable[PAGE_TABLE_INDEX(address)];
	if (entry->kernelInfo & KINFO_PAGE_ON_DISK)
	    return Page_In(pageTable, entry, address) != 0;
    }

    /*
     * Is this access in the stack red zone?
     * We allow accesses at most one page below the current
     * stack bottom.
     */
    if (userAddress < userContext->stackBottom &&
	userAddress >= userContext->stackBottom - PAGE_SIZE) {
	ulong_t currentStackSize;
	ulong_t newStackBottom;

	Debug("Access @%lx in stack red zone\n", userAddress);

	/* Is stack at maximum size? */
	currentStackSize = Get_Current_Stack_Size(userContext);
	if (currentStackSize >= MAX_USER_STACK_SIZE) {
	    Debug("User stack has reached maximum size!\n");
	    return false;
	}

	/* Stack can grow.  Try to add another page. */
	newStackBottom = Round_Down_To_Page(userAddress);
	if (!Allocate_User_Page_Span(userContext, newStackBottom, PAGE_SIZE, RW_USER_VM_FLAGS)) {
	    Debug("Failed to allocate memory for stack growth!\n");
	    return false;
	}

	/* Success! */
	userContext->stackBottom = newStackBottom;
	return true;
    }

    return false;
}

