/*************************************************************************/
/*
 * GeekOS master source distribution and/or project solution
 * Copyright (c) 2001,2003,2004 David H. Hovemeyer <daveho@cs.umd.edu>
 * Copyright (c) 2003 Jeffrey K. Hollingsworth <hollings@cs.umd.edu>
 *
 * This file is not distributed under the standard GeekOS license.
 * Publication or redistribution of this file without permission of
 * the author(s) is prohibited.
 */
/*************************************************************************/
/*
 * Symbol mangling macros
 * Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
 * $Revision: 1.6 $
 * 
 * The _S macro mangles a symbol name into whatever format is
 * needed for external linkage.  E.g., prepend an underscore
 * for PECOFF.
 */

#ifndef GEEKOS_SYMBOL_H
#define GEEKOS_SYMBOL_H

#ifdef NEED_UNDERSCORE
#  define _S(sym) "_" #sym
#else
#  define _S(sym) #sym
#endif

#endif  /* GEEKOS_SYMBOL_H */
