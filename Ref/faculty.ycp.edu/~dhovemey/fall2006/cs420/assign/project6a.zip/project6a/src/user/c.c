/*************************************************************************/
/*
 * GeekOS master source distribution and/or project solution
 * Copyright (c) 2001,2003,2004 David H. Hovemeyer <daveho@cs.umd.edu>
 * Copyright (c) 2003 Jeffrey K. Hollingsworth <hollings@cs.umd.edu>
 *
 * This file is not distributed under the standard GeekOS license.
 * Publication or redistribution of this file without permission of
 * the author(s) is prohibited.
 */
/*************************************************************************/
/*
 * A test program for GeekOS user mode
 */

#include <conio.h>
#include <geekos/syscall.h>

int main(int argc, char **argv)
{
    int badsys = -1, rc;

    Print_String("I am the c program\n");

    /* Make an illegal system call */
    __asm__ __volatile__ (
	SYSCALL
	: "=a" (rc)
	: "a" (badsys)
    );

    return 0;
}
