/*************************************************************************/
/*
 * GeekOS master source distribution and/or project solution
 * Copyright (c) 2001,2003,2004 David H. Hovemeyer <daveho@cs.umd.edu>
 * Copyright (c) 2003 Jeffrey K. Hollingsworth <hollings@cs.umd.edu>
 *
 * This file is not distributed under the standard GeekOS license.
 * Publication or redistribution of this file without permission of
 * the author(s) is prohibited.
 */
/*************************************************************************/
/*
 * GeekOS file system
 * Copyright (c) 2004, David H. Hovemeyer <daveho@cs.umd.edu>
 * $Revision: 1.54 $
 *
 * This is free software.  You are permitted to use,
 * redistribute, and modify it as specified in the file "COPYING".
 */

#include <limits.h>
#include <geekos/errno.h>
#include <geekos/kassert.h>
#include <geekos/screen.h>
#include <geekos/malloc.h>
#include <geekos/string.h>
#include <geekos/bitset.h>
#include <geekos/synch.h>
#include <geekos/bufcache.h>
#include <geekos/list.h>
#include <geekos/gosfs.h>

/* ----------------------------------------------------------------------
 * Private data and functions
 * ---------------------------------------------------------------------- */

int gosfsDebug = 0;
#define Debug(args...) if (gosfsDebug) Print(args)

#define GOSFS_MAGIC		0xab060472

#define NUM_INDIRECT_DATA_BLOCKS \
    (GOSFS_NUM_INDIRECT_BLOCKS * GOSFS_NUM_PTRS_PER_BLOCK)

#define BITS_PER_FS_BLOCK (GOSFS_FS_BLOCK_SIZE*8)

#define FIRST_BITMAP_BLOCK 1

/*
 * This structure occupies the first sector (512 bytes)
 * of the filesystem.  The main things it tells us are
 * how many fs blocks are used for the free block bitmap,
 * and where the root directory is located.
 */
struct GOSFS_Superblock {
    ulong_t magic;			/*!< Magic number. Must match GOSFS_MAGIC. */
    ulong_t numBlocks;			/*!< Overall number of blocks in the filesystem. */
    ulong_t numBitmapBlocks;		/*!< Number of fs blocks used for free block bitmap. */
    struct GOSFS_Dir_Entry rootDirEntry;/*!< Root directory entry. */
};

/*
 * In-memory data structure for the overall filesystem.
 * Stored in fsData field of Mount_Point.
 */
struct GOSFS_Instance {
    struct FS_Buffer_Cache *cache;	/*!< Buffer cache. */
    struct GOSFS_Node *rootNode;	/*!< Root directory node. */
    struct Mutex lock;			/*!< For synchronization of fs operations. */
    struct GOSFS_Superblock superblock;	/*!< Copy of superblock. */
};

struct GOSFS_Node;
DEFINE_LIST(GOSFS_Node_List, GOSFS_Node);

/*
 * A node in the tree of open directories and files.
 */
struct GOSFS_Node {
    /*
     * A cached copy of the node's directory entry.
     * Care must be taken to keep this in sync with the
     * entry on disk.
     */
    struct GOSFS_Dir_Entry dirEntry;

    /*
     * Place in the in-memory filesystem tree.
     */
    struct GOSFS_Node *parent;		/*!< Parent directory node. */
    int refcount;			/*!< Refcount of node. */

    /*
     * These fields identify how to find the directory entry
     * for this node.
     */
    ulong_t dirBlockNum;		/*!< Block number of directory block containing this node's entry. */
    uint_t direntOffset;		/*!< Byte offset of node's directory entry in block. */

    DEFINE_LINK(GOSFS_Node_List, GOSFS_Node);
    struct GOSFS_Node_List childList;
};

#define NODE_ISDIR(node) ((node)->dirEntry.flags & GOSFS_DIRENTRY_ISDIRECTORY)
#define NODE_FILENAME(node) ((node)->dirEntry.filename)
#define NODE_FILESIZE(node) ((node)->dirEntry.size)
#define NODE_SETFILESIZE(node, sz) ((node)->dirEntry.size = (sz))
#define NODE_BLOCKLIST(node,index) ((node)->dirEntry.blockList[(index)])
#define NODE_SETBLOCKLIST(node,index,value) \
    ((node)->dirEntry.blockList[(index)] = (value))
#define NODE_DIRBLOCKNUM(node) ((node)->dirBlockNum)
#define NODE_DIRENTOFFSET(node) ((node)->direntOffset)

#define NODE_ADDREF(node) \
do { (node)->refcount++; Debug("Add ref %s\n", (node)->dirEntry.filename); } while (0)

#define NODE_DELREF(node) \
do { (node)->refcount--; Debug("Del ref %s\n", (node)->dirEntry.filename); } while (0)

IMPLEMENT_LIST(GOSFS_Node_List, GOSFS_Node);

/*
 * Populate a directory entry.
 * Block pointers will not be set - must be set by caller
 * in order for the storage for the file to be valid.
 */
static void Make_Dir_Entry(struct GOSFS_Dir_Entry *entry,
    ulong_t size, ulong_t flags, const char *filename, int uid, int permission)
{
    memset(entry, '\0', sizeof(*entry));

    entry->size = size;
    entry->flags = flags;
    KASSERT(strlen(filename) <= GOSFS_FILENAME_MAX);
    strcpy(entry->filename, filename);
    entry->acl[0].uid = uid;
    entry->acl[0].permission = permission;
}

/*
 * Populate given struct VFS_File_Stat object from given directory entry.
 */
static void Copy_Stat(struct VFS_File_Stat *stat, struct GOSFS_Dir_Entry *entry)
{
    uint_t i;

    stat->size = entry->size;
    stat->isDirectory = (entry->flags & GOSFS_DIRENTRY_ISDIRECTORY) ? 1 : 0;
    stat->isSetuid = (entry->flags & GOSFS_DIRENTRY_SETUID) ? 1 : 0;
    for (i = 0; i < VFS_MAX_ACL_ENTRIES; ++i)
	stat->acls[i] = entry->acl[i];
}

/*
 * Populate given dirEntry object from given directory entry.
 */
static void Copy_Dir_Entry(struct VFS_Dir_Entry *entry, struct GOSFS_Dir_Entry *dentry)
{
    KASSERT(sizeof(entry->name) >= GOSFS_FILENAME_MAX+1);

    strcpy(entry->name, dentry->filename);
    Copy_Stat(&entry->stats, dentry);
}

/*
 * Create a node.
 * If successful, returns a node with a refcount of 1.
 */
static struct GOSFS_Node *Create_Node(
    struct GOSFS_Instance *instance,
    struct GOSFS_Node *parent, struct GOSFS_Dir_Entry *entry,
    ulong_t dirBlockNum, uint_t direntOffset)
{
    struct GOSFS_Node *node;

    /* Make sure lock is held during the tree modification. */
    KASSERT(IS_HELD(&instance->lock));

    node = Malloc(sizeof(*node));
    if (node != 0) {
	memcpy(&node->dirEntry, entry, sizeof(struct GOSFS_Dir_Entry));
	node->parent = parent;
	if (parent != 0) {
	    NODE_ADDREF(parent);
	    Add_To_Back_Of_GOSFS_Node_List(&parent->childList, node);
	}
	node->refcount = 1;
	node->dirBlockNum = dirBlockNum;
	node->direntOffset = direntOffset;
	Clear_GOSFS_Node_List(&node->childList);

	Debug("Create_Node: node=%p, dirent=%p, dirblock=%lu, offset=%u, filesize=%lu\n",
	    node, entry,
	    NODE_DIRBLOCKNUM(node), NODE_DIRENTOFFSET(node), NODE_FILESIZE(node));
    }

    return node;
}

/*
 * Destroy a node.
 * It must have a zero refcount, and must
 * not have any children, or be part of its
 * parent's list of children.
 */
static void Destroy_Node(struct GOSFS_Instance *instance, struct GOSFS_Node *node)
{
#ifndef NDEBUG
    struct GOSFS_Node *p;

    /*
     * Make sure the node has been removed from its
     * parent's child list.
     */
    if (node->parent != 0) {
	for (p = Get_Front_Of_GOSFS_Node_List(&node->parent->childList);
	     p != 0;
	     p = Get_Next_In_GOSFS_Node_List(p))
	    KASSERT(p != node);
    }
#endif

    /* Make sure lock is held during the tree modification. */
    KASSERT(IS_HELD(&instance->lock));

    KASSERT(node->refcount == 0);
    KASSERT(Is_GOSFS_Node_List_Empty(&node->childList));

    Free(node);
}

/*
 * Release a reference to a node.
 * If the node's refcount reaches zero, it is
 * destroyed (and removed from its parent).
 * If the parent's refcount reaches zero, it is
 * deleted, and so on.
 */
static void Release_Node(struct GOSFS_Instance *instance, struct GOSFS_Node *node)
{
    KASSERT(node != 0);

    /* Make sure lock is held during the tree modification. */
    KASSERT(IS_HELD(&instance->lock));

    while (node != 0) {
	struct GOSFS_Node *parent = node->parent;

	/* Remove the reference to the node. */
	KASSERT(node->refcount > 0);
	NODE_DELREF(node);

	if (node->refcount > 0)
	    /* Node still has references, so no need to destroy it */
	    break;

	/* Node has no more references... */
	Debug("Destroy %s\n", NODE_FILENAME(node));

	/* Remove node from parent's list of children */
	KASSERT(parent != 0);
	Remove_From_GOSFS_Node_List(&parent->childList, node);
	Destroy_Node(instance, node);

	/* Continue to parent (to delete child's reference) */
	node = parent;
    }
}

/*
 * Allocate a filesystem block.
 */
static int Allocate_Block(struct GOSFS_Instance *instance, ulong_t *dataBlockNum)
{
    int rc = ENOSPACE;
    ulong_t i, result = 0;
    int freeBit = 0;
    bool done = false;

    /*
     * Scan through bitmap blocks to find an unused block.
     */
    for (i = FIRST_BITMAP_BLOCK;
	 !done && i < FIRST_BITMAP_BLOCK + instance->superblock.numBitmapBlocks;
	 ++i) {
	struct FS_Buffer *buf;
	int rc2;

	Debug("Bitmap block == %lu\n", i);
	/* Bring bitmap block into memory. */
	if ((rc = Get_FS_Buffer(instance->cache, i, &buf)) != 0)
	    goto done;

	/* Search for free bit. */
	freeBit = Find_First_Free_Bit(buf->data, BITS_PER_FS_BLOCK);

	if (freeBit >= 0) {
	    done = true;
	    result = ((i - FIRST_BITMAP_BLOCK) * BITS_PER_FS_BLOCK) + freeBit;
	    Debug("Allocated block %lu\n", result);

	    if (result >= instance->superblock.numBlocks) {
		/* Went off the end of the bitmap. */
		rc = ENOSPACE;
	    } else {
		/* Found a free block. Clear it and mark it as used. */
		struct FS_Buffer *dataBuf;

		if ((rc = Get_FS_Buffer(instance->cache, result, &dataBuf)) == 0) {
		    /* Clear memory in block */
		    memset(dataBuf->data, '\0', GOSFS_FS_BLOCK_SIZE);
		    Modify_FS_Buffer(instance->cache, dataBuf);

		    /* Attempt to sync the newly cleared block. */
		    if ((rc = Release_FS_Buffer(instance->cache, dataBuf)) == 0) {
			/* Block synced - mark it as used. */
			Set_Bit(buf->data, freeBit);
			Modify_FS_Buffer(instance->cache, buf);
		    }
		}
	    }
	}

	/* FIXME: could have multiple errors here */
	rc2 = Release_FS_Buffer(instance->cache, buf);
	if (rc == 0 && rc2 != 0)
	    rc = rc2;
    }

    if (result == 0)
	rc = ENOSPACE;
    else if (rc == 0)
	*dataBlockNum = result;

done:
    return rc;
}

/*
 * Copy node's metadata into its directory entry in the buffer
 * cache, where it will (eventually) make its way out to disk.
 */
static int Sync_Node(struct GOSFS_Instance *instance, struct GOSFS_Node *node)
{
    int rc;
    struct FS_Buffer *dirBuf;
    struct GOSFS_Dir_Entry *dirent;

    /*
     * The root node is the only node with a directory entry in the reserved
     * portion of the filesystem.
     */
    KASSERT(NODE_DIRBLOCKNUM(node) >= FIRST_BITMAP_BLOCK + instance->superblock.numBitmapBlocks
	|| node == instance->rootNode);

    if ((rc = Get_FS_Buffer(instance->cache, NODE_DIRBLOCKNUM(node), &dirBuf)) != 0)
	goto done;
    dirent = (struct GOSFS_Dir_Entry*) (((char*)dirBuf->data) + node->direntOffset);

    Debug("Sync_Node: node=%p, dirbuf=%p, data=%p, dirent=%p, dirblock=%lu, offset=%u, filesize = %lu\n",
	node, dirBuf, dirBuf->data, dirent,
	NODE_DIRBLOCKNUM(node), NODE_DIRENTOFFSET(node), NODE_FILESIZE(node));
    memcpy(dirent, &node->dirEntry, sizeof(*dirent));
    Modify_FS_Buffer(instance->cache, dirBuf);

    /* FIXME: flush buffer to disk now */

    rc = Release_FS_Buffer(instance->cache, dirBuf);

done:
    return rc;
}

/*
 * Get a buffer for a single fs block of file or directory whose
 * node is given.  If "create" is true and the requested block
 * does not exist, the block is created.
 */
static int Get_File_Buffer(struct GOSFS_Instance *instance, struct GOSFS_Node *node,
    ulong_t fileBlockNum, bool create, ulong_t *pBlockNum, struct FS_Buffer **pBuf)
{
    int rc;
    ulong_t dataBlockNum;

    /*
     * Find the filesystem block containing the file data.
     */
    if (fileBlockNum < GOSFS_NUM_DIRECT_BLOCKS) {
	/*
	 * Direct block requested.
	 */
	dataBlockNum = NODE_BLOCKLIST(node, fileBlockNum);

	if (dataBlockNum == 0 && create) {
	    if ((rc = Allocate_Block(instance, &dataBlockNum)) == 0) {
		/* Allocated a block: add it to the file.  */
		NODE_SETBLOCKLIST(node, fileBlockNum, dataBlockNum);
		Debug("Sync after allocate file block\n");
		rc = Sync_Node(instance, node);
	    }
	    if (rc != 0)
		goto done;
	}
    } else if (fileBlockNum < GOSFS_NUM_DIRECT_BLOCKS + NUM_INDIRECT_DATA_BLOCKS) {
	/*
	 * Indirect block requested.
	 */
	ulong_t indirectBlockIndex = (fileBlockNum - GOSFS_NUM_DIRECT_BLOCKS) / GOSFS_NUM_PTRS_PER_BLOCK;
	ulong_t indirectBlockEntry = (fileBlockNum - GOSFS_NUM_DIRECT_BLOCKS) % GOSFS_NUM_PTRS_PER_BLOCK;
	ulong_t indirectBlockNum;
	struct FS_Buffer *indirectBuf;

	/* Find the indirect block */
	indirectBlockNum = NODE_BLOCKLIST(node, indirectBlockIndex);
	/* FIXME: if indirectBlockNum == 0, the indirect block doesn't exist yet */

	/* Get buffer for the indirect block. */
	rc = Get_FS_Buffer(instance->cache, indirectBlockNum, &indirectBuf);
	if (rc != 0)
	    goto done;

	/* Get the number of the data block from the indirect block */
	dataBlockNum = ((ulong_t*) indirectBuf->data)[indirectBlockEntry];

	Release_FS_Buffer(instance->cache, indirectBuf);
    } else {
	/*
	 * Doubly indirect block requested.
	 * FIXME: implement
	 */
	rc = EUNSUPPORTED;
	goto done;
    }

    /*
     * If dataBlockNum == 0, then the requested data block
     * doesn't exist, or we should have created it but
     * didn't because the implementation isn't complete.
     */
    if (dataBlockNum == 0) {
	rc = create ? EUNSUPPORTED : EINVALID;
    } else {
	/* Inform caller of data block number */
	if (pBlockNum != 0)
	    *pBlockNum = dataBlockNum;

	/* Get a buffer for the data block */
	rc = Get_FS_Buffer(instance->cache, dataBlockNum, pBuf);
    }

done:
    return rc;
}

/*
 * Callback function for Scan_Directory.
 * Returns true if scan should continue, false if not.
 */
typedef bool (*Scan_Directory_Callback)(
    struct GOSFS_Instance *instance, struct GOSFS_Node *parent,
    struct FS_Buffer *buf, /* Buffer containing the directory entry - in case callback wants to modify it */
    ulong_t fsBlockNum, uint_t dirEntryNum,
    struct GOSFS_Dir_Entry *dentry, void *data
);

/*
 * Scan all entries in a directory on disk, invoking a callback on each one.
 */
static int Scan_Directory(struct GOSFS_Instance *instance, struct GOSFS_Node *dirNode,
    Scan_Directory_Callback callback, void *data)
{
    int rc = 0;
    ulong_t numDirBlocks, blockNum;
    bool keepGoing = true;

    KASSERT(NODE_ISDIR(dirNode));

    KASSERT(NODE_FILESIZE(dirNode) % GOSFS_FS_BLOCK_SIZE == 0);
    numDirBlocks = NODE_FILESIZE(dirNode) / GOSFS_FS_BLOCK_SIZE;

    for (blockNum = 0; keepGoing && blockNum < numDirBlocks; ++blockNum) {
	struct FS_Buffer *dirBuf;
	struct GOSFS_Dir_Entry *dirEntryList;
	ulong_t dirBlockNum;
	uint_t i;

	if ((rc = Get_File_Buffer(instance, dirNode, blockNum, false, &dirBlockNum, &dirBuf)) != 0)
	    goto done;
	dirEntryList = (struct GOSFS_Dir_Entry *) dirBuf->data;

	for (i = 0; i < GOSFS_DIR_ENTRIES_PER_BLOCK; ++i) {
	    struct GOSFS_Dir_Entry *dentry = &dirEntryList[i];
	    if (!callback(instance, dirNode, dirBuf, dirBlockNum, i, dentry, data)) {
		keepGoing = false;
		break;
	    }
	}

	Release_FS_Buffer(instance->cache, dirBuf);
    }

done:
    return rc;
}

struct Search_Directory_Closure {
    const char *name;
    size_t len;
    struct GOSFS_Node *node;
    int rc;
};

static bool Search_Directory_Callback(struct GOSFS_Instance *instance, struct GOSFS_Node *parent,
    struct FS_Buffer *buf,
    ulong_t fsBlockNum, uint_t dirEntryNum,
    struct GOSFS_Dir_Entry *dentry, void *data)
{
    struct Search_Directory_Closure *closure = (struct Search_Directory_Closure*) data;

    KASSERT(closure->len <= GOSFS_FILENAME_MAX);

    if (dentry->flags & GOSFS_DIRENTRY_USED &&
	memcmp(closure->name, dentry->filename, closure->len) == 0 &&
	dentry->filename[closure->len] == '\0') {
	/*
	 * Found the entry on disk.
	 * Create a node for it.
	 */
	closure->node = Create_Node(instance, parent, dentry, fsBlockNum, dirEntryNum * sizeof(*dentry));
	if (closure->node == 0)
	    closure->rc = ENOMEM;

	/* Do not continue with scan of directory. */
	return false;
    }

    return true;
}

/*
 * Search for given name in given directory.
 * If successful, increments the refcount of the
 * file's node.
 */
static int Search_Directory(struct GOSFS_Instance *instance, struct GOSFS_Node *parent,
    const char *name, size_t len, struct GOSFS_Node **pNode)
{
    int rc = 0;
    struct GOSFS_Node *node;
    struct Search_Directory_Closure closure = {name, len, 0, ENOTFOUND};

    /* Ensure name searched for doesn't exceed the max filename length. */
    if (len > GOSFS_FILENAME_MAX)
	return ENOTFOUND;

    /* Search children already in memory. */
    for (node = Get_Front_Of_GOSFS_Node_List(&parent->childList);
	 node != 0;
	 node = Get_Next_In_GOSFS_Node_List(node)) {
	const char *nodeFileName = NODE_FILENAME(node);
	if (memcmp(name, nodeFileName, len) == 0 && nodeFileName[len] == '\0') {
	    KASSERT(strlen(nodeFileName) == len);
	    NODE_ADDREF(node); /* Add a reference to the node */
	    goto done; /* Found it */
	}
    }

    /* Search all directory entries on disk. */
    if ((rc = Scan_Directory(instance, parent, &Search_Directory_Callback, (void*) &closure)) != 0)
	goto done;

    /* See if we found the node on disk. */
    if (closure.node != 0)
	node = closure.node;
    else {
	KASSERT(closure.rc < 0);
	rc = closure.rc;
    }

done:
    if (node != 0) {
	*pNode = node;
    } else {
	KASSERT(rc < 0);
    }
    return rc;
}

/*
 * Look up a GOSFS_Node for given path.
 * If successful, a refcount will be added to the node.
 * The instance lock must be held.
 */
static int Lookup_Node(struct GOSFS_Instance *instance, const char *path, struct GOSFS_Node **pNode)
{
    int rc;
    struct GOSFS_Node *node = instance->rootNode;

    KASSERT(IS_HELD(&instance->lock));
    KASSERT(path[0] == '/');

    /* Add a reference to the root node to start with */
    NODE_ADDREF(node);

    for (;;) {
	const char *sep;
	size_t len;
	struct GOSFS_Node *child;

	/* Skip slash characters */
	while (*path == '/')
	    ++path;

	Debug("Lookup: %s\n", path);

	if (*path == '\0') {
	    break; /* Seach complete */
	}

	/*
	 * There are more path elements, so current node must
	 * be a directory to continue.
	 */
	if (!NODE_ISDIR(node)) {
	    rc = ENOTDIR;
	    goto fail;
	}

	/* Get first path component and look it up in current directory */
	sep = strchr(path, '/');
	len = (sep != 0) ? sep - path : strlen(path);
	if ((rc = Search_Directory(instance, node, path, len, &child)) != 0)
	    goto fail;

	/* Skip current directory component. */
	path += len;

	/*
	 * Release reference to current node,
	 * and continue to node of next path component.
	 */
	Release_Node(instance, node);
	node = child;
    }

    *pNode = node;
    return 0;

fail:
    Release_Node(instance, node);
    return rc;
}

struct Create_File_Closure {
    const char *filename;
    bool isDir;
    int permission;
    struct GOSFS_Node *node;
    int rc;
};

static bool Create_File_Callback(
    struct GOSFS_Instance *instance, struct GOSFS_Node *parent,
    struct FS_Buffer *buf,
    ulong_t fsBlockNum, uint_t dirEntryNum,
    struct GOSFS_Dir_Entry *dentry, void *data)
{
    struct Create_File_Closure *closure = (struct Create_File_Closure*) data;

    KASSERT(closure->node == 0);

    if (!(dentry->flags & GOSFS_DIRENTRY_USED)) {
	ulong_t flags = GOSFS_DIRENTRY_USED | (closure->isDir ? GOSFS_DIRENTRY_ISDIRECTORY : 0);
	/* Fill in the directory entry. */
	Make_Dir_Entry(dentry, 0, flags, closure->filename, 0 /* FIXME: uid */, closure->permission);

	/* Create a node to represent the new file. */
	Debug("Before Create_Node: dirbuf=%p, data=%p\n", buf, buf->data);
	closure->node = Create_Node(instance, parent, dentry, fsBlockNum, dirEntryNum * sizeof(struct GOSFS_Dir_Entry));

	if (closure->node == 0) {
	    memset(dentry, '\0', sizeof(*dentry)); /* Back out modification to dir buffer */
	    closure->rc = ENOMEM;
	} else {
	    Debug("Create file using entry %u\n", dirEntryNum);

	    /*
	     * Successfully created the node for the file.
	     * Note that the directory buffer has been modified,
	     * and we're done.
	     */
	    Modify_FS_Buffer(instance->cache, buf);
	    closure->rc = 0;
	}

	return false; /* Don't continue scanning the directory */
    }

    return true;
}

/*
 * Create a file or directory.
 */
static int Create_File(struct GOSFS_Instance *instance, struct GOSFS_Node *parent, 
    const char *filename, bool isDir, int permission, struct GOSFS_Node **pChild)
{
    int rc;
    struct Create_File_Closure closure = {filename, isDir, permission, 0, ENOSPACE};
    struct GOSFS_Node *node = 0;

    KASSERT(IS_HELD(&instance->lock));
    KASSERT(NODE_ISDIR(parent));

    if (strlen(filename) > GOSFS_FILENAME_MAX)
	return ENAMETOOLONG;

    /*
     * Attempt to create the file in the existing data blocks for
     * the directory.
     */
    if ((rc = Scan_Directory(instance, parent, &Create_File_Callback, (void*) &closure)) != 0)
	goto done;

    /* If no available entry was found, then we need to grow the directory. */
    if (closure.rc == ENOSPACE) {
	struct FS_Buffer *dirBuf;
	ulong_t nextDirBlock, fsBlockNum;
	bool result;

	KASSERT(NODE_FILESIZE(parent) % GOSFS_FS_BLOCK_SIZE == 0);
	nextDirBlock = NODE_FILESIZE(parent) / GOSFS_FS_BLOCK_SIZE;

	/* Add a new empty data block to the end of the directory */
	if ((rc = Get_File_Buffer(instance, parent, nextDirBlock, true, &fsBlockNum, &dirBuf)) != 0)
	    goto done;
	Modify_FS_Buffer(instance->cache, dirBuf);
	memset(dirBuf->data, '\0', GOSFS_FS_BLOCK_SIZE);

	/* Attempt to create an entry for the new file in the new data block */
	result = Create_File_Callback(instance, parent, dirBuf, fsBlockNum, 0,
	    (struct GOSFS_Dir_Entry*) dirBuf->data, &closure);
	KASSERT(result == false);

	if ((rc = Release_FS_Buffer(instance->cache, dirBuf)) != 0)
	    goto done;

	/* File created successfully - update metadata (size) of directory */
	NODE_SETFILESIZE(parent, NODE_FILESIZE(parent) + GOSFS_FS_BLOCK_SIZE);
	if ((rc = Sync_Node(instance, parent)) != 0)
	    goto done;
    }

    if (closure.node != 0)
	node = closure.node; /* Successfully created the file */
    else
	rc = closure.rc; /* Couldn't create the file */

done:
    if (node != 0) {
	*pChild = node;
    } else {
	KASSERT(rc < 0);
    }
    return rc;
}

/*
 * Common implementation for closing files and directories.
 */
static int Do_Close(struct File *file)
{
    struct GOSFS_Instance *instance = (struct GOSFS_Instance*) file->mountPoint->fsData;
    struct GOSFS_Node *node = (struct GOSFS_Node*) file->fsData;

    Debug("Close: node refcount = %d\n", node->refcount);

    Mutex_Lock(&instance->lock);
    Release_Node(instance, node);
    Mutex_Unlock(&instance->lock);

    return 0;
}

typedef void (*IO_Callback)(struct GOSFS_Instance *instance, struct FS_Buffer *buf,
    int off, ulong_t len, void *data);

static void Do_Read_Xfer(struct GOSFS_Instance *instance, struct FS_Buffer *buf,
    int off, ulong_t len, void *data)
{
    if (buf != 0)
	memcpy(data, ((char*) buf->data) + off, len);
    else
	/* Reading from a hole in the file */
	memset(data, '\0', len);
}

static void Do_Write_Xfer(struct GOSFS_Instance *instance, struct FS_Buffer *buf,
    int off, ulong_t len, void *data)
{
    memcpy(((char*) buf->data) + off, data, len);
    Modify_FS_Buffer(instance->cache, buf);
}

/*
 * Common implementation of file reads and writes.
 */
static int GOSFS_Do_IO(struct GOSFS_Instance *instance, struct GOSFS_Node *node,
    struct File *file, void *data_, ulong_t numBytes, bool create,
    IO_Callback callback)
{
    int rc = 0;
    int pos;
    ulong_t blockNum;
    char *data = (char*) data_;

    pos = file->filePos;
    blockNum = pos / GOSFS_FS_BLOCK_SIZE;

    while (numBytes > 0) {
	struct FS_Buffer *buf = 0;
	int off;
	ulong_t len;

	rc = Get_File_Buffer(instance, node, blockNum, create, 0, &buf);

	if (!(rc == 0 || (!create && rc == EINVALID)))
	    goto done;

	off = pos % GOSFS_FS_BLOCK_SIZE;
	len = GOSFS_FS_BLOCK_SIZE - off;
	if (len > numBytes)
	    len = numBytes;
	Debug("pos=%d, len=%lu\n", pos, len);

	callback(instance, buf, off, len, data);

	if (buf != 0 && (rc = Release_FS_Buffer(instance->cache, buf)) != 0)
	    goto done;

	data += len;
	numBytes -= len;
	pos += len;

	KASSERT(numBytes == 0 || pos % GOSFS_FS_BLOCK_SIZE == 0);
    }

done:
    return rc;
}

/*
 * Create or open a file or directory.
 */
static int Do_Create_File(struct GOSFS_Instance *instance, const char *path, bool isDir, int mode,
    struct GOSFS_Node **pNode)
{
    int rc;
    size_t filenameLen;
    struct GOSFS_Node *node = 0, *parent;
    char *filename, *parentPath = 0;

    /* Split path into parent path and filename. */
    filename = strrchr(path, '/');
    KASSERT(filename != 0);
    ++filename;
    parentPath = (char*) Malloc((filename - path) + 1);
    if (parentPath == 0) {
	rc = ENOMEM;
	goto done;
    }
    memcpy(parentPath, path, filename - path);
    parentPath[filename - path] = '\0';

    filenameLen = strlen(filename);
    if (filenameLen == 0) {
	rc = EINVALID;
	goto done;
    }

    /* Find the parent node. */
    if ((rc = Lookup_Node(instance, parentPath, &parent)) != 0)
	goto done;
    KASSERT(parent != 0);
    Debug("open/create: got node\n");

    /* Look up or create child node. */
    Debug("Search directory...\n");
    if ((rc = Search_Directory(instance, parent, filename, filenameLen, &node)) == 0) {
	/* File or directory already exists */
	if (mode & O_EXCL) {
	    Release_Node(instance, node);
	    rc = EEXIST;
	}
    } else {
	/* Node doesn't exist yet, so create it. */
	Debug("File doesn't exist yet, creating it...\n");
	rc = Create_File(instance, parent, filename, isDir, mode & ~(O_CREATE|O_EXCL), &node);
	Debug("File creation %s\n", rc == 0 ? "succeeded": "failed");
    }

    /*
     * Regardless of whether we succeeded or failed,
     * we need to release the reference to the parent node.
     */
    Debug("Releasing parent\n");
    Release_Node(instance, parent);
    Debug("done releasing parent\n");

    if (rc == 0) {
	KASSERT(node != 0);
	*pNode = node;
    }

done:
    if (parentPath != 0)
	Free(parentPath);
    return rc;
}

/*
 * Common implementation of FStat() for files and directories.
 */
static int Do_FStat(struct File *file, struct VFS_File_Stat *stat)
{
    struct GOSFS_Node *node = (struct GOSFS_Node*) file->fsData;
    Copy_Stat(stat, &node->dirEntry);
    return 0;
}

/* ----------------------------------------------------------------------
 * Implementation of VFS operations
 * ---------------------------------------------------------------------- */

/*
 * Get metadata for given file.
 */
static int GOSFS_FStat(struct File *file, struct VFS_File_Stat *stat)
{
    return Do_FStat(file, stat);
}

/*
 * Read data from current position in file.
 */
static int GOSFS_Read(struct File *file, void *buf, ulong_t numBytes)
{
    int rc;
    struct GOSFS_Instance *instance = (struct GOSFS_Instance*) file->mountPoint->fsData;
    struct GOSFS_Node *node = (struct GOSFS_Node*) file->fsData;

    Mutex_Lock(&instance->lock);

    Debug("GOSFS_Read() - file size = %lu\n", NODE_FILESIZE(node));

    /* Are we at EOF? */
    if (file->filePos >= NODE_FILESIZE(node)) {
	rc = 0;
    } else {
	/* Disallow reads beyond end of file. */
	ulong_t canRead = NODE_FILESIZE(node) - file->filePos;
	if (numBytes > canRead)
	    numBytes = canRead;

	rc = GOSFS_Do_IO(instance, node, file, buf, numBytes, false, &Do_Read_Xfer);

	/* If IO succeeded, update file position */
	if (rc == 0) {
	    file->filePos += numBytes;
	    rc = numBytes;
	}
    }

    Mutex_Unlock(&instance->lock);

    return rc;
}

/*
 * Write data to current position in file.
 */
static int GOSFS_Write(struct File *file, void *buf, ulong_t numBytes)
{
    int rc;
    struct GOSFS_Instance *instance = (struct GOSFS_Instance*) file->mountPoint->fsData;
    struct GOSFS_Node *node = (struct GOSFS_Node*) file->fsData;

    /*
     * FIXME: we really should have a better way to guard against
     * simultaneous access to files (i.e., one that doesn't serialize
     * all filesystem operations).  One possibility would be to
     * have a filesystem tree lock for modifications to the node tree,
     * and per-file locks for file accesses.
     */
    Mutex_Lock(&instance->lock);

    rc = GOSFS_Do_IO(instance, node, file, buf, numBytes, true, &Do_Write_Xfer);

    if (rc == 0) {
	/* Write was successful, so update file position and length. */
	file->filePos += numBytes;
	if (file->filePos > NODE_FILESIZE(node)) {
	    NODE_SETFILESIZE(node, file->filePos);
	    Debug("Sync after write/append\n");
	    rc = Sync_Node(instance, node);
	    if (rc == 0)
		rc = numBytes;
	}
    }

    Mutex_Unlock(&instance->lock);

    return rc;
}

/*
 * Seek to a position in file.
 */
static int GOSFS_Seek(struct File *file, ulong_t pos)
{
    struct GOSFS_Node *node = (struct GOSFS_Node*) file->fsData;

    if (pos > INT_MAX || pos > (ulong_t) NODE_FILESIZE(node))
	return EINVALID;

    file->filePos = (int) pos;

    return 0;
}

/*
 * Close a file.
 */
static int GOSFS_Close(struct File *file)
{
    return Do_Close(file);
}

/*
 * Clone a file.
 * The clone will access the same underlying file as the
 * original, but read/write/seek operations, etc. will be distinct.
 * Returns 0 if successful, or an error code if unsuccessful.
 */
static int GOSFS_Clone(struct File *file, struct File **pClone)
{
    struct File *clone;

    /* Make a duplicate File object. */
    clone = Allocate_File(file->ops, file->filePos, file->endPos, file->fsData, file->mode, file->mountPoint);
    if (clone == 0)
	return ENOMEM;

    /* The clone now has a reference to the original file's node */
    NODE_ADDREF((struct GOSFS_Node*) file->fsData);

    *pClone = clone;

    return 0;
}

/*static*/ struct File_Ops s_gosfsFileOps = {
    &GOSFS_FStat,
    &GOSFS_Read,
    &GOSFS_Write,
    &GOSFS_Seek,
    &GOSFS_Close,
    0, /* Read_Entry */
    &GOSFS_Clone,
};

/*
 * Stat operation for an already open directory.
 */
static int GOSFS_FStat_Directory(struct File *dir, struct VFS_File_Stat *stat)
{
    return Do_FStat(dir, stat);
}

/*
 * Directory Close operation.
 */
static int GOSFS_Close_Directory(struct File *dir)
{
    return Do_Close(dir);
}

/*
 * Read a directory entry from an open directory.
 */
static int GOSFS_Read_Entry(struct File *dir, struct VFS_Dir_Entry *entry)
{
    int rc = 0;
    struct GOSFS_Instance *instance = (struct GOSFS_Instance*) dir->mountPoint->fsData;
    struct GOSFS_Node *dirNode = (struct GOSFS_Node*) dir->fsData;
    ulong_t numDirBlocks, entryBlock;
    struct FS_Buffer *dirBuf = 0;
    struct GOSFS_Dir_Entry *entryList;
    bool done = false;

    Mutex_Lock(&instance->lock);

    /* Did an earlier Read_Entry() operation reach the end? */
    if (dir->endPos) {
	rc = 1;
	goto done;
    }

    /* Compute current number of directory entries in directory */
    KASSERT(NODE_FILESIZE(dirNode) % GOSFS_FS_BLOCK_SIZE == 0);
    numDirBlocks = NODE_FILESIZE(dirNode) / GOSFS_FS_BLOCK_SIZE;
    Debug("Directory contains %lu blocks\n", numDirBlocks);

    while (!done) {
	/* Which directory block is the current entry in? */
	entryBlock = dir->filePos / GOSFS_DIR_ENTRIES_PER_BLOCK;
	if (entryBlock >= numDirBlocks) {
	    /* Reached the end */
	    dir->endPos = 1;
	    rc = 1;
	    goto done;
	}

	Debug("Get directory block %lu...", entryBlock);
	/* Get the directory block. */
	if ((rc = Get_File_Buffer(instance, dirNode, entryBlock, false, 0, &dirBuf)) != 0)
	    goto done;
	KASSERT(dirBuf != 0);
	entryList = (struct GOSFS_Dir_Entry*) dirBuf->data;
	KASSERT(entryList != 0);
	Debug("Got it\n");

	/*
	 * Scan the remaining part of the directory block looking
	 * for the next used directory entry.
	 */
	while (dir->filePos < GOSFS_DIR_ENTRIES_PER_BLOCK) {
	    struct GOSFS_Dir_Entry *dentry = &entryList[dir->filePos % GOSFS_DIR_ENTRIES_PER_BLOCK];

	    dir->filePos++;

	    if (dentry->flags & GOSFS_DIRENTRY_USED) {
		/*
		 * Found a populated directory entry.
		 * Copy it into caller's buffer and we're done.
		 */
		Copy_Dir_Entry(entry, dentry);
		done = true;
		break;
	    }
	}

	Release_FS_Buffer(instance->cache, dirBuf);
    }

done:
    Mutex_Unlock(&instance->lock);
    return rc;
}

/*static*/ struct File_Ops s_gosfsDirOps = {
    &GOSFS_FStat_Directory,
    0, /* Read */
    0, /* Write */
    0, /* Seek */
    &GOSFS_Close_Directory,
    &GOSFS_Read_Entry,
};

/*
 * Open a file named by given path.
 */
static int GOSFS_Open(struct Mount_Point *mountPoint, const char *path, int mode, struct File **pFile)
{
    struct GOSFS_Instance *instance = (struct GOSFS_Instance*) mountPoint->fsData;
    int rc = 0;
    struct GOSFS_Node *node = 0;
    struct File *file;

    Debug("GOSFS_Open(\"%s\",%d)\n", path, mode);

    Mutex_Lock(&instance->lock);

    /* Special case: the root directory cannot be created */
    if ((mode & O_CREATE) && strcmp(path, "/") == 0) {
	rc = EEXIST;
	goto done;
    }

    /*
     * Find or create the node for the named file.
     */
    if (mode & O_CREATE) {
	/* Create new file, or open existing file (if O_EXCL is not set). */
	rc = Do_Create_File(instance, path, false, mode, &node);
	if (rc != 0)
	    goto done;

    } else {
	/* Open existing file. */
	if ((rc = Lookup_Node(instance, path, &node)) != 0)
	    goto done;
    }
    KASSERT(node != 0);

    /* Create a new File object. */
    file = Allocate_File(&s_gosfsFileOps, 0, 0, node, 0, 0);
    if (file == 0) {
	Release_Node(instance, node);
	rc = ENOMEM;
	goto done;
    }

    Debug("Open: node refcount=%d\n", node->refcount);
    *pFile = file;

done:
    Mutex_Unlock(&instance->lock);

    return rc;
}

/*
 * Create a directory named by given path.
 */
static int GOSFS_Create_Directory(struct Mount_Point *mountPoint, const char *path)
{
    int rc;
    struct GOSFS_Instance *instance = (struct GOSFS_Instance*) mountPoint->fsData;
    struct GOSFS_Node *dirNode = 0;

    Mutex_Lock(&instance->lock);
    rc = Do_Create_File(instance, path, true, O_READ|O_WRITE|O_EXCL, &dirNode);
    if (rc == 0) {
	KASSERT(dirNode != 0);
	Release_Node(instance, dirNode);
    }

    Mutex_Unlock(&instance->lock);

    return rc;
}

/*
 * Open a directory named by given path.
 */
static int GOSFS_Open_Directory(struct Mount_Point *mountPoint, const char *path, struct File **pDir)
{
    struct GOSFS_Instance *instance = (struct GOSFS_Instance*) mountPoint->fsData;
    int rc = 0;
    struct GOSFS_Node *dirNode = 0;
    struct File *dir;

    Mutex_Lock(&instance->lock);

    if ((rc = Lookup_Node(instance, path, &dirNode)) != 0)
	goto done;

    dir = Allocate_File(&s_gosfsDirOps, 0, 0, dirNode, 0, 0);
    if (dir == 0) {
	rc = ENOMEM;
	goto done;
    }

    *pDir = dir;

done:
    if (rc != 0) {
	if (dirNode != 0)
	    Release_Node(instance, dirNode);
    }

    Mutex_Unlock(&instance->lock);

    return rc;
}

/*
 * Open a directory named by given path.
 */
static int GOSFS_Delete(struct Mount_Point *mountPoint, const char *path)
{
    TODO("GeekOS filesystem delete operation");
}

/*
 * Get metadata (size, permissions, etc.) of file named by given path.
 */
static int GOSFS_Stat(struct Mount_Point *mountPoint, const char *path, struct VFS_File_Stat *stat)
{
    int rc;
    struct GOSFS_Instance *instance = (struct GOSFS_Instance*) mountPoint->fsData;
    struct GOSFS_Node *node;

    Mutex_Lock(&instance->lock);

    if ((rc = Lookup_Node(instance, path, &node)) != 0)
	goto done;

    Copy_Stat(stat, &node->dirEntry);
    Release_Node(instance, node);

done:
    Mutex_Unlock(&instance->lock);
    return rc;
}

/*
 * Synchronize the filesystem data with the disk
 * (i.e., flush out all buffered filesystem data).
 */
static int GOSFS_Sync(struct Mount_Point *mountPoint)
{
    int rc;
    struct GOSFS_Instance *instance = (struct GOSFS_Instance*) mountPoint->fsData;

    Mutex_Lock(&instance->lock);
    rc = Sync_FS_Buffer_Cache(instance->cache);
    Mutex_Unlock(&instance->lock);

    return rc;
}

/*static*/ struct Mount_Point_Ops s_gosfsMountPointOps = {
    &GOSFS_Open,
    &GOSFS_Create_Directory,
    &GOSFS_Open_Directory,
    &GOSFS_Stat,
    &GOSFS_Sync,
    &GOSFS_Delete,
};

static int GOSFS_Format(struct Block_Device *blockDev)
{
    int rc = 0;
    ulong_t numFSBlocks, numBitmapBytes, numBitmapBlocks, rootDirBlock;
    ulong_t i;
    struct GOSFS_Superblock *superblock = 0;
    struct FS_Buffer *buf;
    struct FS_Buffer_Cache *cache = 0;

    /*
     * Determine overall number of fs blocks,
     * size of bitmap, and location of root directory.
     */
    numFSBlocks = Get_Num_Blocks(blockDev) / GOSFS_SECTORS_PER_FS_BLOCK;
    Debug("Formatting %s as gosfs: %ld fs blocks\n", blockDev->name, numFSBlocks);
    numBitmapBytes = numFSBlocks / 8 + ((numFSBlocks%8 == 0) ? 0 : 1);
    Debug("Bytes needed for bitmap: %ld\n", numBitmapBytes);
    numBitmapBlocks = numBitmapBytes / GOSFS_FS_BLOCK_SIZE;
    if (numBitmapBytes % GOSFS_FS_BLOCK_SIZE != 0)
	numBitmapBlocks++;
    rootDirBlock = FIRST_BITMAP_BLOCK + numBitmapBlocks;
    if (rootDirBlock >= numFSBlocks) {
	rc = EINVALID;
	goto done;
    }

    /*
     * Hack: we assume that all preallocated blocks will be marked
     * in the first bitmap block.  With 2 blocks (superblock and initial
     * root directory block) reserved for non-bitmap purposes, this limits
     * the total number of blocks in the filesystem to
     *
     *   ((blkSize*8)-2) * (blkSize*8)
     *
     * For 4K blocks, the maximum filesystem size is thus 4,397,778,075,648
     * bytes.  I can live with this limitation for now.  It will be
     * easy to remove later.
     */
    if (rootDirBlock >= BITS_PER_FS_BLOCK) {
	rc = EINVALID;
	goto done;
    }

    /*
     * Create a temporary buffer cache.
     */
    cache = Create_FS_Buffer_Cache(blockDev, GOSFS_FS_BLOCK_SIZE);

    /*
     * Write superblock.
     */
    if ((rc = Get_FS_Buffer(cache, 0, &buf)) != 0)
	goto done;
    Modify_FS_Buffer(cache, buf);
    superblock = (struct GOSFS_Superblock*) buf->data;
    superblock->magic = GOSFS_MAGIC;
    superblock->numBlocks = numFSBlocks;
    superblock->numBitmapBlocks = numBitmapBlocks;
    Make_Dir_Entry(&superblock->rootDirEntry,
	GOSFS_FS_BLOCK_SIZE,				/* size */
	GOSFS_DIRENTRY_USED|GOSFS_DIRENTRY_ISDIRECTORY,	/* flags */
	"[rootdir]",					/* filename */
	0,						/* uid */
	O_READ|O_WRITE					/* permission */
    );
    superblock->rootDirEntry.blockList[0] = rootDirBlock; /* root directory location */
    Release_FS_Buffer(cache, buf);

    /*
     * Write bitmap.
     * Initially, the only used pages are the superblock,
     * bitmap pages, and the root directory page.
     */
    for (i = FIRST_BITMAP_BLOCK; i < rootDirBlock; ++i) {
	if ((rc = Get_FS_Buffer(cache, i, &buf)) != 0)
	    goto done;
	Modify_FS_Buffer(cache, buf);

	memset(buf->data, '\0', GOSFS_FS_BLOCK_SIZE);

	if (i == FIRST_BITMAP_BLOCK) {
	    uchar_t *bits = (uchar_t*) buf->data;
	    uint_t j;

	    /*
	     * This is the first bitmap block.
	     * Mark the superblock, bitmap blocks, and initial root directory
	     * block as in use.
	     */
	    for (j = 0; j <= rootDirBlock; ++j)
		Set_Bit(bits, j);
	}

	Release_FS_Buffer(cache, buf);
    }

    /*
     * Write initial (empty) root directory.
     */
    if ((rc = Get_FS_Buffer(cache, rootDirBlock, &buf)) != 0)
	goto done;
    Modify_FS_Buffer(cache, buf);
    memset(buf->data, '\0', GOSFS_FS_BLOCK_SIZE);
    Release_FS_Buffer(cache, buf);

done:
    /*
     * Destroy the fs buffer cache, which has the
     * side-effect of writing its contents out to the disk.
     * If there were no other failures, then a sucessful
     * sync means the overall format operation was successful.
     */
    if (cache != 0) {
	int syncRC = Destroy_FS_Buffer_Cache(cache);
	if (rc == 0 && syncRC != 0)
	    /*
	     * Filesystem creation appeared to succeed, but we
	     * couldn't sync filesystem data to disk.
	     * Therefore, the entire fs format operation fails.
	     */
	    rc = syncRC;
    }
    return rc;
}

static int GOSFS_Mount(struct Mount_Point *mountPoint)
{
    int rc = 0;
    struct GOSFS_Instance *instance = 0;
    struct FS_Buffer *superBuf = 0;
    struct GOSFS_Superblock *superblock;

    /* Create filesystem instance object. */
    instance = (struct GOSFS_Instance*) Malloc(sizeof(*instance));
    if (instance == 0)
	goto memfail;
    memset(instance, '\0', sizeof(*instance));
    Mutex_Init(&instance->lock);

    Mutex_Lock(&instance->lock);

    /* Create buffer cache. */
    instance->cache = Create_FS_Buffer_Cache(mountPoint->dev, GOSFS_FS_BLOCK_SIZE);
    if (instance->cache == 0)
	goto memfail;

    /* Get the buffer containing the superblock. */
    if ((rc = Get_FS_Buffer(instance->cache, 0, &superBuf)) != 0)
	goto fail;

    /* Verify that superblock looks reasonable. */
    superblock = (struct GOSFS_Superblock*) superBuf->data;
    if (superblock->magic != GOSFS_MAGIC) {
	rc = EINVALIDFS;
	goto fail;
    }
    /* FIXME: should inspect other filesystem params */

    /* Create node for the root directory. */
    instance->rootNode = Create_Node(
	instance,
	0,				/* parent */
	&superblock->rootDirEntry,	/* dirEntry */
	0UL,				/* dirBlockNum */
	((char*) &superblock->rootDirEntry) - ((char*)superblock) /* direntOffset */
    );
    if (instance->rootNode == 0)
	goto memfail;
    NODE_ADDREF(instance->rootNode);
    KASSERT(NODE_ISDIR(instance->rootNode));

    /* Copy superblock */
    memcpy(&instance->superblock, superblock, sizeof(struct GOSFS_Superblock));

    /* We're done with the superblock for now. */
    Release_FS_Buffer(instance->cache, superBuf);

    /* Fill in Mount_Point structure for the mounted filesystem instance. */
    mountPoint->ops = &s_gosfsMountPointOps;
    mountPoint->fsData = instance;

    Print("GOSFS mount on %s looks good!\n", mountPoint->dev->name);

    Mutex_Unlock(&instance->lock);

    return 0;

memfail:
    rc = ENOMEM;
fail:
    if (instance != 0) {
	/* Release superblock buffer, destroy buffer cache. */
	if (instance->cache != 0) {
	    if (superBuf != 0)
		Release_FS_Buffer(instance->cache, superBuf);
	    Destroy_FS_Buffer_Cache(instance->cache);
	}

	/* Free root node and instance. */
	if (instance->rootNode != 0)
	    Destroy_Node(instance, instance->rootNode);
	Free(instance);
    }
    return rc;
}

static struct Filesystem_Ops s_gosfsFilesystemOps = {
    &GOSFS_Format,
    &GOSFS_Mount,
};

/* ----------------------------------------------------------------------
 * Public functions
 * ---------------------------------------------------------------------- */

void Init_GOSFS(void)
{
    Register_Filesystem("gosfs", &s_gosfsFilesystemOps);
}

