/*************************************************************************/
/*
 * GeekOS master source distribution and/or project solution
 * Copyright (c) 2001,2003,2004,2006 David H. Hovemeyer <daveho@cs.umd.edu>
 * Copyright (c) 2003 Jeffrey K. Hollingsworth <hollings@cs.umd.edu>
 *
 * This file is not distributed under the standard GeekOS license.
 * Publication or redistribution of this file without permission of
 * the author(s) is prohibited.
 */
/*************************************************************************/
/*
 * Paging (virtual memory) support
 * Copyright (c) 2003, Jeffrey K. Hollingsworth <hollings@cs.umd.edu>
 * Copyright (c) 2003,2004,2006 David H. Hovemeyer <daveho@cs.umd.edu>
 * $Revision: 1.59 $
 * 
 * This is free software.  You are permitted to use,
 * redistribute, and modify it as specified in the file "COPYING".
 */

#include <geekos/string.h>
#include <geekos/int.h>
#include <geekos/idt.h>
#include <geekos/kthread.h>
#include <geekos/kassert.h>
#include <geekos/screen.h>
#include <geekos/mem.h>
#include <geekos/malloc.h>
#include <geekos/gdt.h>
#include <geekos/segment.h>
#include <geekos/user.h>
#include <geekos/vfs.h>
#include <geekos/crc32.h>
#include <geekos/paging.h>

/* ----------------------------------------------------------------------
 * Public data
 * ---------------------------------------------------------------------- */

/*
 * The single page directory for all kernel-mode-only threads.
 */
pde_t* g_kernelPageDir;

/* ----------------------------------------------------------------------
 * Private functions/data
 * ---------------------------------------------------------------------- */

#define SECTORS_PER_PAGE (PAGE_SIZE / SECTOR_SIZE)

/*
 * Flag to indicate if debugging paging code
 */
int debugFaults = 0;
#define Debug(args...) if (debugFaults) Print(args)

IMPLEMENT_LIST(Disk_Page_List, Disk_Page);

/*
 * Freelist of Disk_Pages.
 * Each free Disk_Page represents an available page-sized chunk
 * of the paging file.
 */
static struct Disk_Page_List s_diskPageFreelist;

/*
 * Block of memory allocated for Disk_Pages.
 */
static struct Disk_Page *s_diskPageList;


/*
 * Print diagnostic information for a page fault.
 */
static void Print_Fault_Info(uint_t address, faultcode_t faultCode)
{
    extern uint_t g_freePageCount;

    Print("Pid %d, Page Fault received, at address %x (%d pages free)\n",
        g_currentThread->pid, address, g_freePageCount);
    if (faultCode.protectionViolation)
        Print ("   Protection Violation, ");
    else
        Print ("   Non-present page, ");
    if (faultCode.writeFault)
        Print ("Write Fault, ");
    else
        Print ("Read Fault, ");
    if (faultCode.userModeFault)
        Print ("in User Mode\n");
    else
        Print ("in Supervisor Mode\n");
}

/*
 * Handler for page faults.
 * You should call the Install_Interrupt_Handler() function to
 * register this function as the handler for interrupt 14.
 */
/*static*/ void Page_Fault_Handler(struct Interrupt_State* state)
{
    ulong_t address;
    faultcode_t faultCode;

    KASSERT(!Interrupts_Enabled());

    /* Get the address that caused the page fault */
    address = Get_Page_Fault_Address();
    Debug("Page fault @%lx\n", address);

    /* Get the fault code */
    faultCode = *((faultcode_t *) &(state->errorCode));

    /* Handle user page fault */
    if (faultCode.userModeFault && Handle_User_Page_Fault(address, faultCode))
	return;

    /* Default behavior: kill the current thread */
    Print("Unexpected page fault!\n");
    Print_Fault_Info(address, faultCode);
    Dump_Interrupt_State(state);
    Exit(-1);
}


/*
 * Perform I/O to read or write a page in the paging file.
 */
static void Page_IO(void *paddr, int pagefileIndex,
    int (*Perform_IO)(struct Block_Device *dev, int blockNum, void *buf),
    const char *desc)
{
    struct Paging_Device *pagedev = Get_Paging_Device();
    uint_t i;

    KASSERT(pagedev != 0);

    /* Read or write the data of the page */
    for (i = 0; i < SECTORS_PER_PAGE; ++i) {
	ulong_t blockNum = (pagefileIndex * SECTORS_PER_PAGE) + pagedev->startSector + i;
	int rc = Perform_IO(pagedev->dev, blockNum, ((char*) paddr) + i*SECTOR_SIZE);
	if (rc < 0)
	    /* FIXME: we should probably just return the error code to the caller */
	    Panic("Failed paging file %s: %d\n", desc, rc);
    }
}

/*
 * Page in function.  Reads a page on disk back into the
 * user address space.  If locked is set, then the page remains
 * unpageable.
 */
static struct Page *Do_Page_In(pte_t *pageTable, pte_t *entry, ulong_t address, bool locked)
{
    void *paddr;
    struct Page *page;
    ulong_t vaddr = Round_Down_To_Page(address);
    extern ulong_t g_numTicks;

    KASSERT(!Interrupts_Enabled());

    Debug("Page in disk page at %d\n", entry->pageBaseAddr);

    /* Allocate a page */
    paddr = Alloc_Pageable_Page(entry, vaddr);
    if (paddr == 0) {
	Debug("Out of memory for user page fault\n");
	return 0;
    }

    /* Make page temporarily unpageable */
    page = Get_Page((ulong_t) paddr);
    KASSERT(page->flags & PAGE_PAGEABLE);
    page->flags &= ~(PAGE_PAGEABLE);

    /* Do the page IO */
    Enable_Interrupts();
    Read_From_Paging_File(paddr, vaddr, entry->pageBaseAddr);
    Disable_Interrupts();

    /* Update clock field of page */
    page->clock = g_numTicks;

    /* Free the space in the paging file */
    Free_Space_On_Paging_File(entry->pageBaseAddr);

    /* Map the page back into the address space */
    Add_PTE(pageTable, vaddr, paddr, RW_USER_VM_FLAGS);

    if (!locked)
	/* Page can be made pageable again */
	page->flags |= PAGE_PAGEABLE;

    return page;
}

/* ----------------------------------------------------------------------
 * Public functions
 * ---------------------------------------------------------------------- */

/*
 * Add a page directory entry.
 */
void Add_PDE(pde_t *pageDir, ulong_t addr, pte_t *pageTable, int flags)
{
    pde_t entry = {0};

    KASSERT((addr & VM_PT_SPAN_MASK) == addr);
    KASSERT(Is_Page_Multiple((ulong_t) pageTable));

    entry.present = 1;
    entry.flags = flags;
    entry.pageTableBaseAddr = ((ulong_t) pageTable) >> 12;

    pageDir[PAGE_DIRECTORY_INDEX(addr)] = entry;
}

/*
 * Clear a page directory entry.
 */
void Clear_PDE(pde_t *pageDir, ulong_t addr)
{
    pde_t entry = {0};

    KASSERT((addr & VM_PT_SPAN_MASK) == addr);

    pageDir[PAGE_DIRECTORY_INDEX(addr)] = entry;
}

/*
 * Add a page table entry.
 */
void Add_PTE(pte_t *pageTable, ulong_t addr, void *paddr, int flags)
{
    pte_t entry = {0};
#ifndef NDEBUG
    struct Page *page = Get_Page((ulong_t) paddr);
#endif

    KASSERT(Is_Page_Multiple(addr));
    KASSERT(Is_Page_Multiple((ulong_t) paddr));
#ifndef NDEBUG
    /*
     * Important sanity check. Pages not marked as allocated should
     * never be mapped into a user address space.
     */
    KASSERT(((ulong_t)paddr < USER_VM_START) || (page->flags & PAGE_ALLOCATED));
#endif

    entry.present = 1;
    entry.flags = flags;
    entry.pageBaseAddr = ((ulong_t) paddr) >> 12;

    pageTable[PAGE_TABLE_INDEX(addr)] = entry;
}

/*
 * Clear a page table entry.
 */
void Clear_PTE(pte_t *pageTable, ulong_t addr)
{
    pte_t entry = {0};
    KASSERT(Is_Page_Multiple(addr));
    pageTable[PAGE_TABLE_INDEX(addr)] = entry;
}

/*
 * Ensure a page table for given user space address exists,
 * allocating one if needed.
 * Returns a pointer to the page table for the user address
 * if successful, or a null pointer if unsuccessful.
 */
pte_t *Ensure_Page_Table_Exists(pde_t *pageDir, ulong_t addr, int flags)
{
    pte_t *pageTable;

    KASSERT(addr >= USER_VM_START);

    /* Add a page table if needed. */
    pageTable = Lookup_Page_Table(pageDir, addr);
    if (pageTable == 0) {
	/* Allocate a page table */
	pageTable = Alloc_Page();
	if (pageTable != 0) {
	    /* Critical: make sure all entries in page table are cleared! */
	    memset(pageTable, '\0', PAGE_SIZE);

	    /* Add the page table to the page directory */
	    Add_PDE(pageDir, addr & VM_PT_SPAN_MASK, pageTable, flags);
	}
    }

    return pageTable;
}

/*
 * Get the address of a page table from given page directory
 * for given virtual address.
 */
pte_t *Lookup_Page_Table(pde_t *pageDir, ulong_t addr)
{
    return (pte_t*) (pageDir[PAGE_DIRECTORY_INDEX(addr)].pageTableBaseAddr << 12);
}

/*
 * Get address of a page table entry from given page directory
 * for given virtual address.
 */
pte_t *Lookup_Page_Table_Entry(pde_t *pageDir, ulong_t vaddr)
{
    pte_t *pageTable = Lookup_Page_Table(pageDir, vaddr);
    if (pageTable == 0)
	return 0;
    return &pageTable[PAGE_TABLE_INDEX(vaddr)];
}

/*
 * Get the address of a page from given page table
 * for given virtual address.
 */
void *Lookup_Page(pte_t *pageTable, ulong_t addr)
{
    return (void*) (pageTable[PAGE_TABLE_INDEX(addr)].pageBaseAddr << 12);
}

/*
 * Get the address of a page from given page directory
 * for given virtual address.
 */
void *Lookup_Page_From_PD(pde_t *pageDir, ulong_t addr)
{
    pte_t *pageTable = Lookup_Page_Table(pageDir, addr);
    if (pageTable == 0)
	return 0;
    return Lookup_Page(pageTable, addr);
}

/*
 * Get the Disk_Page object corresponding to given index.
 */
struct Disk_Page *Get_Disk_Page(ulong_t index)
{
    KASSERT(index >= 0);
    KASSERT(Get_Paging_Device() != 0);
    KASSERT(index < Get_Paging_Device()->numSectors / SECTORS_PER_PAGE);

    return &s_diskPageList[index];
}

/*
 * Get the index of a particular Disk_Page object.
 */
ulong_t Get_Disk_Page_Index(struct Disk_Page *diskPage)
{
    KASSERT(diskPage != 0);
    KASSERT(s_diskPageList != 0);
    KASSERT(diskPage >= s_diskPageList);
    KASSERT(Get_Paging_Device() != 0);
    KASSERT(diskPage < s_diskPageList + (Get_Paging_Device()->numSectors / SECTORS_PER_PAGE));

    return diskPage - s_diskPageList;
} 

/*
 * Page in a page currently paged out to disk.
 * The page is left in an unpageable state - i.e., locked in memory.
 * This allows the page contents to be safely accessed from 
 * kernel mode.
 */
struct Page *Page_In_Locked(pte_t *pageTable, pte_t *entry, ulong_t address)
{
    return Do_Page_In(pageTable, entry, address, true);
}

/*
 * Page in a page currently paged out to disk.
 */
struct Page *Page_In(pte_t *pageTable, pte_t *entry, ulong_t address)
{
    return Do_Page_In(pageTable, entry, address, false);
}


/*
 * Initialize virtual memory by building page tables
 * for the kernel and physical memory.
 */
void Init_VM(struct Boot_Info *bootInfo)
{
    ulong_t numKernelPageTables;
    ulong_t i, j, addr;
    pte_t *pageTable;
    int vmFlags = VM_WRITE
	;

    Print("Initializing virtual memory and paging...\n");

    /* Allocate a page directory for the kernel. */
    g_kernelPageDir = (pde_t *) Alloc_Page();
    KASSERT(g_kernelPageDir != 0);

    /*
     * Figure out how many page tables are required for
     * kernel space.  This is based on the about of physical memory.
     * We need one page table per 4M of memory.
     */
    numKernelPageTables = bootInfo->memSizeKB / VM_KB_PER_PT_SPAN;
    if ((bootInfo->memSizeKB % VM_KB_PER_PT_SPAN) != 0)
	++numKernelPageTables;

    /* Initialize page tables to identity map all of physical memory. */
    Debug("  Allocating %lu kernel page tables\n", numKernelPageTables);
    for (i = 0; i < numKernelPageTables; ++i) {
	/* Allocate a page table */
	pageTable = Alloc_Page();
	KASSERT(pageTable != 0);

	/*
	 * Add an entry to the page directory pointing to the
	 * page table.
	 */
	Add_PDE(g_kernelPageDir, i * VM_PT_SPAN, pageTable, vmFlags);

	/* Add page table entries for all pages in the span */
	memset(pageTable, '\0', PAGE_SIZE);
	for (j = 0, addr = i * VM_PT_SPAN; j < NUM_PAGE_TABLE_ENTRIES; ++j, addr += PAGE_SIZE) {
	    Add_PTE(pageTable, addr, (void*) addr, vmFlags);
	}
    }

    /*
     * Special cases:
     * The PTE for address 0 is cleared, in order to trap null pointer references.
     * The PTE for video memory is marked as not cached.
     */
    pageTable = Lookup_Page_Table(g_kernelPageDir, 0);
    Clear_PTE(pageTable, 0);
    pageTable = Lookup_Page_Table(g_kernelPageDir, VIDMEM_ADDR & VM_PT_SPAN_MASK);
    Add_PTE(pageTable, VIDMEM_ADDR, VIDMEM, vmFlags | VM_NOCACHE);

    /* Turn on the MMU! */
    Enable_Paging(g_kernelPageDir);

    /* Install the page fault handler */
    Install_Interrupt_Handler(14, Page_Fault_Handler);
}

/**
 * Initialize paging file data structures.
 * All filesystems should be mounted before this function
 * is called, to ensure that the paging file is available.
 */
void Init_Pagefile(void)
{
    struct Paging_Device *pagedev;
    ulong_t numDiskPages, i;

    /* Get the paging device */
    pagedev = Get_Paging_Device();
    if (pagedev == 0) {
	Print("Warning: no paging device\n");
	return;
    }

    Print("Initializing paging data structures...\n");

    /*
     * Allocate list of Disk_Page objects, one for each
     * page that will be stored in the paging file
     */
    numDiskPages = pagedev->numSectors / SECTORS_PER_PAGE;
    s_diskPageList = (struct Disk_Page*) Malloc(sizeof(struct Disk_Page) * numDiskPages);
    if (s_diskPageList == 0) {
	Print("Error: could not allocate memory for disk page list\n");
	return;
    }

    /* Initialize the disk page freelist */
    for (i = 0; i < numDiskPages; ++i)
	Add_To_Back_Of_Disk_Page_List(&s_diskPageFreelist, &s_diskPageList[i]);
}

/**
 * Find a free bit of disk on the paging file for this page.
 * Interrupts must be disabled.
 * @return index of free page sized chunk of disk space in
 *   the paging file, or -1 if the paging file is full
 */
int Find_Space_On_Paging_File(void)
{
    struct Disk_Page *diskPage;

    KASSERT(!Interrupts_Enabled());

    if (Is_Disk_Page_List_Empty(&s_diskPageFreelist))
	return -1;

    diskPage = Remove_From_Front_Of_Disk_Page_List(&s_diskPageFreelist);
    return (int) Get_Disk_Page_Index(diskPage);
}

/**
 * Free a page-sized chunk of disk space in the paging file.
 * Interrupts must be disabled.
 * @param pagefileIndex index of the chunk of disk space
 */
void Free_Space_On_Paging_File(int pagefileIndex)
{
    struct Disk_Page *diskPage = Get_Disk_Page(pagefileIndex);
    KASSERT(!Interrupts_Enabled());
    Add_To_Back_Of_Disk_Page_List(&s_diskPageFreelist, diskPage);
}

/**
 * Write the contents of given page to the indicated block
 * of space in the paging file.
 * @param paddr a pointer to the physical memory of the page
 * @param vaddr virtual address where page is mapped in user memory
 * @param pagefileIndex the index of the page sized chunk of space
 *   in the paging file
 */
void Write_To_Paging_File(void *paddr, ulong_t vaddr, int pagefileIndex)
{
    struct Page *page = Get_Page((ulong_t) paddr);
    struct Disk_Page *diskPage = Get_Disk_Page(pagefileIndex);

    KASSERT(!(page->flags & PAGE_PAGEABLE)); /* Page must be locked! */

    diskPage->crc = crc32(0, paddr, PAGE_SIZE);
    diskPage->vaddr = vaddr;
    Page_IO(paddr, pagefileIndex, Block_Write, "write");
    Debug("PageIO: Wrote paddr=%p, crc=%lx, index=%d\n", paddr, diskPage->crc, pagefileIndex);
}

/**
 * Read the contents of the indicated block
 * of space in the paging file into the given page.
 * @param paddr a pointer to the physical memory of the page
 * @param vaddr virtual address where page will be re-mapped in
 *   user memory
 * @param pagefileIndex the index of the page sized chunk of space
 *   in the paging file
 */
void Read_From_Paging_File(void *paddr, ulong_t vaddr, int pagefileIndex)
{
    struct Page *page = Get_Page((ulong_t) paddr);
    ulong_t crc;
    struct Disk_Page *diskPage = Get_Disk_Page(pagefileIndex);

    KASSERT(!(page->flags & PAGE_PAGEABLE)); /* Page must be locked! */

    Page_IO(paddr, pagefileIndex, Block_Read, "read");
    crc = crc32(0, paddr, PAGE_SIZE);
    if (crc != diskPage->crc)
	Panic("CRC mismatch in pagein: orig=%lx, new=%lx\n", diskPage->crc, crc);
    if (vaddr != diskPage->vaddr)
	Panic("Pagein to wrong virtual address: orig=%lx, new=%lx\n", diskPage->vaddr, vaddr);
    Debug("PageIO: Read paddr=%p, crc=%lx, index=%d\n", paddr, crc, pagefileIndex);
}

