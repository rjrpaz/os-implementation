/******************************************************************************
Header:         wrappers.C

Description:    Wrappers for AAL7 functions to print error messages

Author(s):      Ben Teitelbaum

Class:          UW/CS640

Modifications:

$Log: ftp_server.h,v $

******************************************************************************/

#include "wrappers.h"

void
print_recv_error(int connStat, int connectDesc, bool fromFTPD) {
  void (*showError) (char *format, ...) = fromFTPD ? ftpdShowError : ftpShowError;
  if (connStat < 0) {	      									  
	 showError("ipv6recv() returned an unexpected error code: %d", connStat);
	 assert(FALSE);                                      
  }							   									  
}


void
print_send_error(int connStat, int connectDesc, bool fromFTPD) {
  void (*showError) (char *format, ...) = fromFTPD ? ftpdShowError : ftpShowError;

  if (connStat < 0) {
	 showError("ipv6send() returned %d", connStat);
	 assert(FALSE);
  }
}
