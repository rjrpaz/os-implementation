/******************************************************************************
Header:         ftp_server.h

Description:    FTP Server Data Structures and Prototypes

Author(s):      Ben Teitelbaum

Class:          UW/CS640

Modifications:

$Log: ftp_server.h,v $

******************************************************************************/
#ifndef FTP_SERVER_H
#define FTP_SERVER_H


/******************************************************************************
                             Include header files
******************************************************************************/
#include <sys/param.h>
#include <unistd.h>
#include <stdlib.h>
#include <dirent.h>
#include <limits.h>
#include <stdio.h>
#include <stdarg.h>
#include <assert.h>
#include "globals.h"
#include "ftp_msg.h"
#include "types.h"

/******************************************************************************
                           Preprocessor Macros
******************************************************************************/


#define DO_FTPD_WRITE_CONSOLE(x)       \
{                                      \
   pthread_mutex_lock(&consoleLock);   \
   printf("\n[%s] ", thrName);         \
   ftpdShowMsg((x));                   \
   pthread_mutex_unlock(&consoleLock); \
}

#define DO_FTPD_SEND(x)                                  \
{                                                        \
  connStat = outMsg.sendOverConnection(connectDesc);     \
  if (connStat != 0) {                        \
    pthread_mutex_lock(&consoleLock);                    \
    fprintf(stderr, "\n[%s] ", thrName);            	 \
    print_send_error(connStat, connectDesc, TRUE);  \
    ftpdShowError("%s", (x));                            \
    pthread_mutex_unlock(&consoleLock);                  \
    pthread_mutex_trylock(&chDirLock);                   \
	 pthread_mutex_unlock(&chDirLock);               \
    pthread_exit(0);                                     \
  }                                                      \
}

// There is no point in returning a status on failure since the thread
// is detached from its parent.
#define DO_FTPD_RECV(x)                                  \
{                                                        \
  connStat = inMsg.init(connectDesc);                    \
  if (connStat != 0) {                        \
    pthread_mutex_lock(&consoleLock);                    \
    fprintf(stderr, "\n[%s] ", thrName);            	 \
    print_recv_error(connStat, connectDesc, TRUE);  \
    ftpdShowError("%s", (x));                            \
    pthread_mutex_unlock(&consoleLock);                  \
    pthread_exit(0);                                     \
  }                                                      \
}

/******************************************************************************
                               Define constants
******************************************************************************/

// These should be settable from the command-line ???

const int MAX_FTP_CONNECTIONS = 3;         // Maximum number of FTP's
                                            // the server will handle

/******************************************************************************
                           Function Prototypes
******************************************************************************/

// To start an FTPd (server) application a thread must be created running
// ftpServerMain(); this is like the main() for the server
// application.  Incomming FTP connection requests, cause new threads
// to be created; these run the routine ftpSeverConnectionMain()
//
// The single argument passed in is an identifying name used for
// debugging purposees.
void*
ftpServerMain(void* sName);

// For each FTP client session, there is a thread created that runs
// this routine and terminates itself when done.
//
// The single argument passed is the IPv6 connection descriptor for
// the session.
void*
ftpSeverConnectionMain(void* sessionConnectDescript);

// Print an FTPd error message to standard out -- basically just a printf
// wrapper.
void 
ftpdShowError(char *format, ...);

void 
ftpdShowMsg(char *format, ...);

/* Stupid wrapper around write to support verification */
ssize_t 
v1(int fildes, const void *buf, size_t nbyte);

#endif // FTP_SERVER_H
