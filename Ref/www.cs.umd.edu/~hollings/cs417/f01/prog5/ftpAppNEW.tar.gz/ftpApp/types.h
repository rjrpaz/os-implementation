/******************************************************************************
Header:         types.h

Description:    General type defintions

Author(s):      Ben Teitelbaum

Class:          UW/CS640

Modifications:

$Log: types.h,v $
******************************************************************************/

#if !defined(C_HEADER_TYPES)
#define C_HEADER_TYPES 1

#ifndef _G_HAVE_BOOL

/******************************************************************************
			       Define constants
******************************************************************************/

// Boolean values
#if !defined(TRUE)
#  define TRUE 1
#endif

#if !defined(FALSE)
#  define FALSE 0
#endif


/******************************************************************************
			       Type definitions
******************************************************************************/

// Patch for bool since Sun's CC doesn't recognize it
// typedef int bool;

typedef bool bool_t;

#else

#if !defined(TRUE)
#  define TRUE true
#endif

#if !defined(FALSE)
#  define FALSE false
#endif

#endif  //_G_HAVE_BOOL


#endif  // C_HEADER_TYPES
