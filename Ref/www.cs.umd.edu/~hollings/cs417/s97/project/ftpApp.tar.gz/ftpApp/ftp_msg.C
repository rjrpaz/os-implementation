/******************************************************************************
Source File:    ftp_msg.C

Description:	FTP Message Class Implementation

Author(s):	Ben Teitelbaum

Class:		UW/CS640

Modifications:

$Log: ftp_msg.C,v $

******************************************************************************/

#include "ftp_msg.h"

int
ftp_msg_c::getLength(void) const {
  int lengthBuf;
  memcpy((void*)(&lengthBuf),
			(void*)(msgBuf + FTP_TYPE_FIELD_SIZE),
			sizeof(int));
  return ntohl(lengthBuf);
}

void
ftp_msg_c::setLength(int len) {
  int lengthBuf = htonl(len);
  memcpy((void*)(msgBuf + FTP_TYPE_FIELD_SIZE),
			(void*)(&lengthBuf),
			sizeof(int));
}


// Initializer for out-going signalling messages...
//
// Returns:
// STAT_OK  Always
status_t 
ftp_msg_c::init(msg_type_t msgType, char* fileName) {
  int i, payloadLength;

  for (i=1;i<100;i++) msgBuf[i]='\0';  // !!!

  // Check that msgType is valid
  assert(msgType >= 0 && msgType < FTP_MSG_TYPE_OVERFLOW);
  
  if (fileName) {
    // Check for fileName being too big
    assert(strlen(fileName) < FTP_MAX_PAYLOAD_SIZE);

    payloadLength = strlen(fileName) + 1;
    strcpy(msgBuf + FTP_HEADER_SIZE, fileName);
  } else {
    payloadLength = 0;
  }
  setLength(payloadLength);
  setType(msgType);

  return STAT_OK;
}

// Initializer for out-going data packets; gets next chunk from the
// specified file... 
// 
// Returns:
// STAT_OK   if everything hunky dorey
// STAT_EOF  if the eof has been reached
// STAT_FAIL if there was an I/O error reading from f
status_t 
ftp_msg_c::init(ifstream* f) {
  int i;

  for (i=1;i<100;i++) msgBuf[i]='\0';   // !!!

  f->read(msgBuf + FTP_HEADER_SIZE, FTP_MAX_PAYLOAD_SIZE);
  if (f->fail() && !f->eof()) {
    setType(FTP_DATA);
    setLength(STAT_BAD);
    return STAT_FAIL;
  } if (f->eof()) {
    setType(FTP_DATA);
    setLength(f->gcount());  // Hope this works ???
    return STAT_EOF;
  } else {
    setType(FTP_DATA);
    setLength(f->gcount());
    return STAT_OK;
  }
}

// Initializer for receiving the next FTP message over the specified
// connection... 
// 
// Returns: STAT_OK or aal7 status codes
int
ftp_msg_c::init(int aal7_conn_desc) {

  int i;
  for (i=1;i<100;i++) msgBuf[i]='\0';    // !!!
  
  int packetSize = recvNextMsg(aal7_conn_desc);

  // If aal7_recv returned an error, invalidate the msg object,
  // and return the error received
  if (packetSize < FTP_HEADER_SIZE) {
    setLength(STAT_BAD);
    return packetSize;
  } else {   // otherwise, just set the payloadLength and return STAT_OK

	 // Packet size can never be greater than FTP_MAX_MSG_SIZE
	 assert(packetSize <= FTP_MAX_MSG_SIZE); 
	 
	 // Check that FTP_MSG is valid
	 assert(msgBuf[0] >= 0 && msgBuf[0] < FTP_MSG_TYPE_OVERFLOW);
	 
    setLength(packetSize - FTP_HEADER_SIZE);
    return STAT_OK;
  }
}


//
// Receive next message, returning the number of bytes received or an
// error if one was encountered 
int
ftp_msg_c::recvNextMsg(int aal7_conn_desc) {
  int nleft, nread;
  char* ptr;
 
  // First read header
  ptr = msgBuf;
  nleft = FTP_HEADER_SIZE;
  while (nleft > 0) {
	 nread = aal7_recv(aal7_conn_desc, ptr, nleft);
	 if (nread < 0)
		return(nread);				  // error, return it
	 
	 nleft -= nread;
	 ptr   += nread;
  }

  // Then, read payload
  nleft = getLength();
  while (nleft > 0) {
	 nread = aal7_recv(aal7_conn_desc, ptr, nleft);
	 if (nread < 0)
		return(nread);				  // error, return it
	 
	 nleft -= nread;
	 ptr   += nread;
  }

#if DEBUG
	 cout << endl;
	 cout << "<< [" << (int)msgBuf[0] << ']';
	 cout << '[' << getLength() << ']';
	 cout << '[' << (char*)(msgBuf + FTP_HEADER_SIZE) << ']' << endl;
  fflush(NULL);
#endif

  assert(nleft == 0);
  
  // return num bytes received
  return(FTP_HEADER_SIZE + getLength());	
}


// Send the message over the given AAL7 connection
// 
// Returns:  STAT_OK or aal7 error code
int
ftp_msg_c::sendOverConnection(int aal7_conn_desc) const {
#if DEBUG
	 cout << endl;
	 cout << ">> [" << (int)msgBuf[0] << ']';
	 cout << '[' << getLength() << ']';
	 cout << '[' << (char*)(msgBuf + FTP_HEADER_SIZE) << ']' << endl;
  fflush(NULL);
#endif
  return aal7_send(aal7_conn_desc, msgBuf, FTP_HEADER_SIZE + getLength());
}

// Insertion operator overloaded so that ftp_msg_c's can dump
// themselves out to a stream.
ostream&
operator << (ostream& os, ftp_msg_c& msg) {
  if (msg.getLength() > 0) {
    os.write(msg.msgBuf + FTP_HEADER_SIZE, msg.getLength());
    if (os.fail()) {
      pthread_mutex_lock(&consoleLock);           
      cerr << "[" << msg.thrName << "] ";   
      cerr << "I/O problem writing to stream";
      pthread_mutex_unlock(&consoleLock);
    }
  }
  return os;
}


