/******************************************************************************
Header:         ftp_server.h

Description:    FTP Server Data Structures and Prototypes

Author(s):      Ben Teitelbaum

Class:          UW/CS640

Modifications:

$Log: ftp_server.h,v $

******************************************************************************/
#ifndef FTP_SERVER_H
#define FTP_SERVER_H


/******************************************************************************
                             Include header files
******************************************************************************/
#include <sys/param.h>
#include <unistd.h>
#include <iostream.h>
#include <stdlib.h>
#include <fstream.h>
#include <dirent.h>
#include <limits.h>
#include <stdio.h>
#include <stdarg.h>
#include <assert.h>
#include "globals.h"
#include "aal7_wrappers.h"
#include "ftp_msg.h"
#include "types.h"

/******************************************************************************
                           Preprocessor Macros
******************************************************************************/


#define DO_FTPD_WRITE_CONSOLE(x)       \
{                                      \
   pthread_mutex_lock(&consoleLock);   \
   printf("\n[%s] ", thrName);         \
   ftpdShowMsg((x));                   \
   pthread_mutex_unlock(&consoleLock); \
}

#define DO_FTPD_SEND(x)                                  \
{                                                        \
  aal7Stat = outMsg.sendOverConnection(connectDesc);     \
  if (aal7Stat != AAL7_STAT_OK) {                        \
    pthread_mutex_lock(&consoleLock);                    \
    fprintf(stderr, "\n[%s] ", thrName);            	 \
    print_aal7_send_error(aal7Stat, connectDesc, TRUE);  \
    ftpdShowError("%s", (x));                            \
    pthread_mutex_unlock(&consoleLock);                  \
    pthread_mutex_trylock(&chDirLock);                   \
	 pthread_mutex_unlock(&chDirLock);               \
    pthread_exit(0);                                     \
  }                                                      \
}

// There is no point in returning a status on failure since the thread
// is detached from its parent.
#define DO_FTPD_RECV(x)                                  \
{                                                        \
  aal7Stat = inMsg.init(connectDesc);                    \
  if (aal7Stat != AAL7_STAT_OK) {                        \
    pthread_mutex_lock(&consoleLock);                    \
    fprintf(stderr, "\n[%s] ", thrName);            	 \
    print_aal7_recv_error(aal7Stat, connectDesc, TRUE);  \
    ftpdShowError("%s", (x));                            \
    pthread_mutex_unlock(&consoleLock);                  \
    pthread_exit(0);                                     \
  }                                                      \
}

/******************************************************************************
                               Define constants
******************************************************************************/

// These should be settable from the command-line ???

const int MAX_FTP_CONNECTIONS = 3;         // Maximum number of FTP's
                                            // the server will handle

/******************************************************************************
                           Function Prototypes
******************************************************************************/

// To start an FTPd (server) application a thread must be created running
// ftpServerMain(); this is like the main() for the server
// application.  Incomming FTP connection requests, cause new threads
// to be created; these run the routine ftpSeverConnectionMain()
//
// The single argument passed in is an identifying name used for
// debugging purposees.
void*
ftpServerMain(void* sName);

// For each FTP client session, there is a thread created that runs
// this routine and terminates itself when done.
//
// The single argument passed is the AAL7 connection descriptor for
// the session.
void*
ftpSeverConnectionMain(void* sessionConnectDescript);

// Print an FTPd error message to standard out -- basically just a printf
// wrapper.
void 
ftpdShowError(char *format, ...);

void 
ftpdShowMsg(char *format, ...);

/* Stupid wrapper around write to support verification */
ssize_t 
v1(int fildes, const void *buf, size_t nbyte);

#endif // FTP_SERVER_H
