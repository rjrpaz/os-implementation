/******************************************************************************
Source File:    main.C

Description:	main() for CS640 project - Fall 96

Author(s):	Ben Teitelbaum

Class:		UW/CS640

Modifications:

$Log: main.C,v $

******************************************************************************/


/******************************************************************************
			     Include header files
******************************************************************************/
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>
#include <pthread.h>
#include <stdio.h>
#include <iostream.h>
#include "ftp_client.h"
#include "ftp_server.h"

/******************************************************************************
			       Global Variables
******************************************************************************/
pthread_mutex_t consoleLock;
pthread_mutex_t chDirLock;
host_ID myHostID;

/******************************************************************************
			     A Few Utility Functions
******************************************************************************/

void
exitHandler(void) {
  int exitTime = 5;

  // Clean up a little...
  pthread_mutex_destroy(&consoleLock);
  pthread_mutex_destroy(&chDirLock);
  if (aal7_term() == AAL7_STAT_FAIL) {
	 cout << "aal7_term() returned AAL7_STAT_FAIL -- exiting anyway\a";
	 cout << endl;
  }

  // Print silly terminating message
  cout << endl;
  cout << "...exiting (in " << exitTime << " seconds)." << endl;

  // Sleep breifly so xterm doesn't disappear before user can read any
  // exit messages
  sleep(exitTime);
}



int
main(int argc, char **argv)
{
  // Set the exit routine
  atexit(exitHandler);

  // Do generic initialization of globals and setting of defaults
  pthread_mutex_init(&consoleLock, 0);
  pthread_mutex_init(&chDirLock, 0);

  // Print stupid welcome message
  cout << "----------------------------------------------" << endl;
  cout << "-------  FINAL DEMONSTRATION VERSION  --------" << endl;
  cout << "----------------------------------------------" << endl;
  cout << "-                                            -" << endl;
  cout << "-     cs640 Project Front End (Fall 1996)    -" << endl;
  cout << "-                                            -" << endl;
  cout << "----------------------------------------------" << endl;
  cout << "----------------------------------------------" << endl;
  cout << endl; 

  // FTP Threads
  int numFTPClients = 1;
  pthread_t ftpdThread;
  pthread_t *ftpClient;

  static char* serverName = "FTPd";
  char* clientName;
  
  // Test first argument and remember who we are
  if (argc < 2) {
	 cout << "A host ID must be given as first argument!\a" << endl;
	 exit(-1);
  }
  for(char* d = argv[1]; *d != '\0'; d++) { 
	 if (!isdigit((int)*d)) {
		cout << "Invalid host ID given as first argument!\a" << endl;
		exit(-1);
	 }
  }
  myHostID = atoi(argv[1]);

  // Initialize AAL7
  if (aal7_init(argc, argv) == AAL7_STAT_FAIL) {
    cout << "AAL7 initialization failed!\a" << endl;
    exit(-1);
  } 

  // Create FTPd server thread
  pthread_create(&ftpdThread, 0, ftpServerMain, (void*) serverName);

  
  // Fork off numFTPClients FTP client threads
  ftpClient = new pthread_t[numFTPClients];
  for(int i = 0; i < numFTPClients; i++) {
    clientName = new char[10];
    sprintf(clientName, "FTP %d", i);
    pthread_create(&ftpClient[i], 0, ftpClientMain, (void*) clientName);
  }

  // Main thread suspends itself so that main() doesn't terminate
  pthread_join(ftpdThread, NULL);
  for(int i = 0; i < numFTPClients; i++) {
    pthread_join(ftpClient[i], NULL);
  }
}
