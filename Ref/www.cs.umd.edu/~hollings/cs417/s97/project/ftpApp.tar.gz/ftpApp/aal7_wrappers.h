/******************************************************************************
Header:         aal7_wrappers.h

Description:    Wrappers for AAL7 functions to print error messages

Author(s):      Ben Teitelbaum

Class:          UW/CS640

Modifications:

$Log: ftp_server.h,v $

******************************************************************************/

#ifndef AAL7_WRAPPER_H
#define AAL7_WRAPPER_H

#include "aal7.h"
#include "ftp_client.h"
#include "ftp_server.h"

// Wrapper around aal7_disconnect() to print error messages if an
// error is encountered
void
do_aal7_disconnect(int connectDesc, bool fromFTPD);

void
print_aal7_recv_error(int aal7Stat, int connectDesc, bool fromFTPD);

void
print_aal7_send_error(int aal7Stat, int connectDesc, bool fromFTPD);

#endif // AAL7_WRAPPER_H
