/*
 *	atm-garb-2.h
 *
 *	The public interface for the network garbler module.
 *
 *	Written by: ???
 *	Modified: Kacheong Poon (9-22-1994)
 *	Modified: Kacheong Poon (12-02-1994)
 *                Add garb_stat();
 *  Modified: Srinivasa Narayanan (11/19/1996)
 *				  changed garb_sendto() to two routines
 *				  garb_sendto_normal() and garb_sendto_routing()
 *			 	  to handle routing cells and normal data cells
 *				  differently. 
 *				  changed Garbstat to add new garbler statistics 
 *				  for routing cells.
 *                Defined a new type for the various garbler 
 *                probabilities 
 *                Defined a new interface for setting the garbler
 *                probabilities.
 */

#ifndef ATM_GARB2_H
#define ATM_GARB2_H

#include <sys/types.h>
#include <sys/socket.h>


#ifdef __cplusplus
  extern "C" {
#endif

typedef enum 
{
  NO_SEND_CALL = 0,		/* no of times garb_sendto() is called. */
  NO_TRAIL_DROP,		/* no of AAL7 trailers dropped. */
  NO_DISCARD,			/* no of cells discarded. */
  NO_GARBLED,			/* no of cells garbled. */
  ROUTING_NO_SEND_CALL, /* no. of times garb_sendto_routing() is called */
  ROUTING_NO_TRAIL_DROP,/* no. of trailers that went thro routing */
						/* This should never happen, this is a way to */
						/* detect mischief !*/

  ROUTING_NO_DISCARD, 	/* no. of routing cells discarded */
  ROUTING_NO_GARBLED	/* no. of routing cells garbled */
} GarbStat;

typedef enum
{
  NORMAL_DISCARD_PROBABILITY = 0, 
  NORMAL_CORRUPT_PROBABILITY,
  NORMAL_TRAILER_PROBABILITY,
  ROUTING_DISCARD_PROBABILITY,
  ROUTING_CORRUPT_PROBABILITY
} GarbProbability;




/*
 * int garb_stat(GarbStat which)
 *
 *      it returns the data corresponding to which.  -1 if which is not valid.
 */
extern int garb_stat(GarbStat which);

/* int garb_set_prob(GarbProbability which, float value)
 * sets the probability defined by which to the specified value 
 * returns 0 if ok, -1 if some error 
 */
extern int garb_set_prob(GarbProbability which, float value);

/* void garb_secret_print_stats(int)
 * secret routine to print garbler statistics
 */
extern void garb_secret_print_stats(int);

#ifdef __cplusplus
  }
#endif

#endif /* ATM_GARB2_H */


