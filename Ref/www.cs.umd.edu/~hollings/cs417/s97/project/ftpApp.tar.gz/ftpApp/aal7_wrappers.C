/******************************************************************************
Header:         aal7_wrappers.C

Description:    Wrappers for AAL7 functions to print error messages

Author(s):      Ben Teitelbaum

Class:          UW/CS640

Modifications:

$Log: ftp_server.h,v $

******************************************************************************/

#include "aal7_wrappers.h"

void
do_aal7_disconnect(int connectDesc, bool fromFTPD) {
  
  void (*showError) (char *format, ...) = fromFTPD ? ftpdShowError : ftpShowError;
  
  switch (aal7_disconnect(connectDesc)) {
	case AAL7_STAT_OK:
	 break;
	 
	case AAL7_STAT_BAD:
	 showError("aal7_disconnect() returned AAL7_STAT_BAD -- invalid connection descriptor %d", connectDesc);
	 break;
	 
	case AAL7_STAT_CLOSED:	
	 showError("aal7_disconnect() returned AAL7_STAT_CLOSED -- connection %d already closed", connectDesc);
	 break;
	 
	default:
	 // Unexpected reply type from atm_disconnect()
	 assert(FALSE);
  }
}

void
print_aal7_recv_error(int aal7Stat, int connectDesc, bool fromFTPD) {
  void (*showError) (char *format, ...) = fromFTPD ? ftpdShowError : ftpShowError;
  switch(aal7Stat) {	      									  
	case AAL7_STAT_UNREACHABLE:								  
	 showError("aal7_recv() returned AAL7_STAT_UNREACHABLE for connection %d",
				  connectDesc); 
	 break;                                              
	case AAL7_STAT_BAD:	   									  
	 showError("aal7_recv() returned AAL7_STAT_BAD for connection %d", 
				  connectDesc); 
	 break;                                              
	case AAL7_STAT_CLOSED:  									  
	 showError("aal7_recv() returned AAL7_STAT_CLOSED for connection %d", 
				  connectDesc); 
	 break; 	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  
	default:					   									  
	 showError("aal7_recv() returned an unexpected error code: %d", 
				  aal7Stat);
	 assert(FALSE);                                      
  }							   									  
}


void
print_aal7_send_error(int aal7Stat, int connectDesc, bool fromFTPD) {
  void (*showError) (char *format, ...) = fromFTPD ? ftpdShowError : ftpShowError;

  switch (aal7Stat) {
	case AAL7_STAT_BAD:
	 showError("aal7_send() returned AAL7_STAT_BAD for connection %d", connectDesc);
	 break;

	case AAL7_STAT_UNREACHABLE:
	 showError("aal7_send() returned AAL7_STAT_UNREACHABLE for connection %d", connectDesc);
	 break;

	case AAL7_STAT_CLOSED:	
	 showError("aal7_send() returned AAL7_STAT_CLOSED -- connection %d is closed", connectDesc);
	 break;

	default:
	 showError("aal7_send() returned an unexpected error code: %d", 
				  aal7Stat);
	 assert(FALSE);
  }
}
