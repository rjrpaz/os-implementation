/******************************************************************************
Header:         ftp_client.h

Description:    FTP Client Data Structures and Prototypes

Author(s):      Ben Teitelbaum

Class:          UW/CS640

Modifications:

$Log: ftp_client.h,v $

******************************************************************************/
#ifndef FTP_CLIENT_H
#define FTP_CLIENT_H


/******************************************************************************
                             Include header files
******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <sys/param.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <assert.h>
#include <string.h>
#include "ftp_msg.h"
#include "types.h"
#include "aal7_wrappers.h"
#include "globals.h"

/******************************************************************************
                               Define constants
******************************************************************************/

typedef enum {FTP_CMD_OPEN, FTP_CMD_CLOSE, FTP_CMD_SEND, FTP_CMD_GET,
              FTP_CMD_CD, FTP_CMD_LCD, FTP_CMD_LS, 
              FTP_CMD_HELP, FTP_CMD_QUIT, FTP_CMD_DISP_VCT,
				  FTP_CMD_SET_WINDOW, FTP_CMD_EXIT, FTP_CMD_SET_GARB,
				  FTP_CMD_GARB_STATS , FTP_CMD_VERIFY, FTP_BAD_CMD} ftp_cmd_t;

const int FTP_DISCONNECTED = -1;

/******************************************************************************
                           Preprocessor Macros
******************************************************************************/


#define DO_FTP_SHOW_ERROR(x)            \
{                                       \
   pthread_mutex_lock(&consoleLock);    \
   fprintf(stderr, "[%s] ", thrName);   \
   ftpShowError((x));                   \
   pthread_mutex_unlock(&consoleLock);  \
}

#define DO_FTP_SHOW_ERROR2(x, y)        \
{                                       \
   pthread_mutex_lock(&consoleLock);    \
   fprintf(stderr, "[%s] ", thrName);   \
   ftpShowError((x), (y));              \
   pthread_mutex_unlock(&consoleLock);  \
}


#define DO_FTP_WRITE_CONSOLE(x)        \
{                                      \
   pthread_mutex_lock(&consoleLock);   \
   printf("[%s] ", thrName);           \
   ftpShowMsg((x));                    \
   pthread_mutex_unlock(&consoleLock); \
}

#define DO_FTP_WRITE_CONSOLE2(x, y)    \
{                                      \
   pthread_mutex_lock(&consoleLock);   \
   printf("[%s] ", thrName);           \
   ftpShowMsg((x), (y));               \
   pthread_mutex_unlock(&consoleLock); \
}

#define DO_FTP_WRITE_CONSOLE3(x, y, z) \
{                                      \
   pthread_mutex_lock(&consoleLock);   \
   printf("[%s] ", thrName);           \
   ftpShowMsg((x), (y), (z));          \
   pthread_mutex_unlock(&consoleLock); \
}


#define DO_FTP_CONNECTED_P(x)                           \
{                                                       \
  if (connectDesc == FTP_DISCONNECTED) {                \
    DO_FTP_WRITE_CONSOLE2("Not currently connected; %s\n", (x)); \
    break;                                              \
  }                                                     \
}

#define DO_FTP_SEND(x)                                   \
{                                                        \
  aal7Stat = outMsg.sendOverConnection(connectDesc);     \
  if (aal7Stat != AAL7_STAT_OK) {                        \
    pthread_mutex_trylock(&consoleLock);                 \
    fprintf(stderr, "[%s] ", thrName);                   \
    print_aal7_send_error(aal7Stat, connectDesc, FALSE); \
    ftpShowError("%s", (x));                             \
    pthread_mutex_unlock(&consoleLock);                  \
    connectDesc = FTP_DISCONNECTED;                      \
    break;                                               \
  }                                                      \
}

#define DO_FTP_RECV(x)                                   \
{                                                        \
  aal7Stat = inMsg.init(connectDesc);                    \
  if (aal7Stat != AAL7_STAT_OK) {                        \
    pthread_mutex_trylock(&consoleLock);                 \
    fprintf(stderr, "[%s] ", thrName);                   \
    print_aal7_recv_error(aal7Stat, connectDesc, FALSE); \
    ftpShowError("%s", (x));                             \
    pthread_mutex_unlock(&consoleLock);                  \
    connectDesc = FTP_DISCONNECTED;                      \
    break;                                               \
  }                                                      \
}

/******************************************************************************
                           Function prototypes
******************************************************************************/

// To start an FTP client application a thread must be created running
// ftpClient(); this is like the main() for the client application.
//
// The single argument passed in is an identifying name used for
// debugging purposees.
void*
ftpClientMain(void* cName);

// Get the next user command and optional argument from the console
// This is pretty hideous -- I could redo it with libg++ regex's and
// Strings if we have extra time :^)
ftp_cmd_t
getFTPUserCommand(char** arg1, char** arg2);

// Print a usage message to standard out
void
showFTPUsage();

// Print an FTP message to the console --  basically just a printf wrapper.
void
ftpShowMsg(char *format, ...);

// Print an FTP error message to the console and sound the bell --
// basically just a printf wrapper.
void
ftpShowError(char *format, ...);


#endif // FTP_CLIENT_H
