/******************************************************************************
  Source File:    ftp_server.C
  
  Description:	FTP Server Application
  
  Author(s):	Ben Teitelbaum
  
  Class:		UW/CS640
  
  Modifications:
  
  $Log: ftp_server.C,v $
  
  ******************************************************************************/

#include "wrappers.h"
#include "ftp_server.h"

extern char *myHostName;
extern pthread_mutex_t consoleLock;

static char initDir[_POSIX_PATH_MAX + 1];

// To start an FTPd (server) application a thread must be created running
// ftpServerMain(); this is like the main() for the server
// application.  Incomming FTP connection requests, cause new threads
// to be created; these run the routine ftpSeverConnectionMain()
//
// The single argument passed in is an identifying name used for
// debugging purposees.
void*
ftpServerMain(void* sName) {
  
  // Server name helps disambiguate multiple server threads
  assert(strlen((char*) sName) <= MAX_THREAD_NAME_LEN); 
  
  char thrName[MAX_THREAD_NAME_LEN + 1];
  strcpy(thrName, (char*)sName);

  pthread_mutex_lock(&chDirLock);
  getcwd(initDir, (size_t)(_POSIX_PATH_MAX + 1));
  pthread_mutex_unlock(&chDirLock);

										  // server, on which the server does a
										  // listen()
  
  int fd;	// This is the socket descriptor, on which the FTP server 
		// does an accept()
  
  int newConnectionDescriptor;  // This variable for holding the
  int stat;			// Place to hold returned error codes
  
  DO_FTPD_WRITE_CONSOLE("FTPd server started.\n");

  // Register the FTP server
  fd  = IPv6socket(IPV6_PROTO_TCP);
  if (fd < 0) {
    ftpdShowError("Failure to create socket for FTP server");
    ftpdShowError("This is a fatal condition...aborting!");
    assert(FALSE);
  }

  if (IPv6listen(fd, 50000) < 0) {
    ftpdShowError("Failure to register FTP server");
    ftpdShowError("This is a fatal condition...aborting!");
    assert(FALSE);
  }
  
  // Loop forever firing up new FTP sessions
  while(TRUE) {
	 
    // Accept an FTP client connection request...
    if ((newConnectionDescriptor = IPv6accept(fd)) < 0) {
        ftpdShowError("IPv6accept() returned %d", newConnectionDescriptor);
    }
	 
#ifdef DEBUG 
    printf("FTPd server about to create a client session on cd: %d", 
			  newConnectionDescriptor);
#endif
    
    // Create a new thread for the FTP session running on
    // ftpSeverConnectionMain() ...  
    pthread_t id;
    pthread_attr_t  attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    stat = pthread_create(&id, &attr, ftpSeverConnectionMain, 
	 (void*) newConnectionDescriptor);
    pthread_attr_destroy(&attr);

    if (stat != 0) {
      ftpdShowError("Creation of an FTP session thread failed with error: %d",
						  stat);
    }
  }
  return 0;  // Must satisfy this signature to be a thread start function
}

// For each FTP client session, there is a thread created that runs
// this routine and terminates itself when done.
//
// The single argument passed is the connection descriptor for
// the session.
void*
ftpSeverConnectionMain(void* sessionConnectDescript) {
  char curDir[_POSIX_PATH_MAX + 1];

  // Copy initial WD
  strcpy(curDir, initDir);

  // Construct a name for this connection
  char thrName[MAX_THREAD_NAME_LEN + 1];
  sprintf(thrName, 
			 "FTPd-session %d", 
			 (int)sessionConnectDescript);

  DO_FTPD_WRITE_CONSOLE("FTPd server session started.\n");
  
  ftp_msg_c inMsg(thrName);  // the incoming FTP message
  ftp_msg_c outMsg(thrName); // the outcoming FTP message
  
  ifstream* sendFile = NULL;		// File stream for outgoing file
  ofstream* recvFile = NULL;		// File stream for incoming file
  
  int connStat;
  
  char fileName[FTP_MAX_PAYLOAD_SIZE]; // Char buffer to hold file
  // name field from messages
  
  //  strstream fnameSS;		// Output string stream
  
  msg_type_t msgType;
  
  // Need a dirent pointer with more than sizeof(struct dirent)
  // allocated to it. Wow!
  char direntBuf[sizeof(struct  dirent) + _POSIX_PATH_MAX + 1];
  struct dirent* dirEntry = (struct dirent*)direntBuf;
  
  // Returned by opendir() in handling FTP_LSR
  DIR *dirp;
  
  int connectDesc = (int) sessionConnectDescript;
  
  status_t stat;		// Place to store returned statuses
  
  // Buffer into which getcwd() can dump the current dir name
  char dirNameBuf[_POSIX_PATH_MAX + 1];
  
  while(TRUE) {
    // Get the next FTP message from the client...
    DO_FTPD_RECV("while waiting for next client message");
	 
    // Extract FNAME field
    inMsg.GetPayload(fileName);
	 
    // Examine possible FTP messages and handle appropriately...
    msgType = inMsg.getType();
    switch(msgType) {
		
      // Handle FTP_GR message...
	  case FTP_GR: 
		
		//      printf("safe = %d\n",sendFile.test_safe_flag());
		
		// Make sure that the file exists and open it
		//	sendFile.open(fileName);
		if (sendFile) delete sendFile;
		pthread_mutex_lock(&chDirLock);  
		chdir(curDir);
      sendFile = new ifstream(fileName);
		pthread_mutex_unlock(&chDirLock);  
		if (sendFile->fail()) {
		  outMsg.init(FTP_ERRFNAME);
		  ftpdShowError("Cannot open file: %s -- get request failed.",
							 fileName);
		  DO_FTPD_SEND("get request failed");
		  break;
		} else {
		  outMsg.init(FTP_FILESTART);
		  DO_FTPD_SEND("get request failed");
		}	  
		
		// Send back data packets until EOF
		while(TRUE) {
		  // Construct the next data packet
		  stat = outMsg.init(sendFile);  
		  
		  if (stat == STAT_FAIL) {
			 // File I/O failed, so bring the connection down...
			 ftpdShowError("File I/O problem reading file: %s \n%s",
								fileName,
								"get request failed");
			 outMsg.init(FTP_ERR);
			 DO_FTPD_SEND("get request failed trying to send FTP_ERR");

			 IPv6close(connectDesc);
			 pthread_exit(0);

		  } else if (stat == STAT_EOF) {
			 // Send the last data packet
			 DO_FTPD_SEND("get request failed after reading eof");
			 
			 // Send EOF packet
			 outMsg.init(FTP_EOF);
			 DO_FTPD_SEND("get request failed trying to send FTP_EOF signal");
			 break;
		  } else if (stat == STAT_OK) {
			 // Send the data packet
			 DO_FTPD_SEND("get request failed");
			 cout << ".";
		  } else {
			 // Unexpected stat returned by init
			 ftpdShowError("Got unexpected message stat %d", stat);
			 assert(FALSE);
		  }
		}
		break;  // FTP_GR
		
      // Handle FTP_SR message...
	  case FTP_SR: 
		// Open the recvFile to receive the transfer
		//	recvFile.open(fileName); 
		if (recvFile) delete recvFile;
		pthread_mutex_lock(&chDirLock);  
		chdir(curDir);
		recvFile = new ofstream(fileName);
		pthread_mutex_unlock(&chDirLock);  
		if (recvFile->fail()) {
		  ftpdShowError("Cannot open file: %s \nSR failed", fileName);
		  outMsg.init(FTP_ERR);
		  DO_FTPD_SEND("send request failed");
		  break;
		} else {
		  outMsg.init(FTP_SROK);
		  DO_FTPD_SEND("send request failed");
		}
		
		// Receive data packets until EOF
		while(TRUE) {
		  DO_FTPD_RECV("send request failed");
		  msgType = inMsg.getType();
		  if (msgType == FTP_EOF) {
			 // Append the data packet payload to the receive file and break;
			 *recvFile << inMsg;
			 
			 // If file I/O failed, bring the connection down...
			 if (recvFile->fail()) {
				ftpdShowError("File I/O failure for %s on connection %s\n%s",
								  fileName, connectDesc,
								  "...terminating connection: %s");
				IPv6close(connectDesc);
				pthread_exit(0);
			 }
			 
			 // Close the file
			 recvFile->close();
			 
			 // Acknowledge the EOF
			 outMsg.init(FTP_EOFOK);
			 DO_FTPD_SEND("send request failed after EOF");
			 break;
		  } else if (msgType == FTP_DATA) {
			 // Append the data packet payload to the receive file
			 *recvFile << inMsg;
			 // If file I/O failed, bring the connection down...
			 if (recvFile->fail()) {
				ftpdShowError("File I/O failure for %s on connection %s\n%s",
								  fileName, connectDesc,
								  "...terminating connection: %s");
				IPv6close(connectDesc);
				pthread_exit(0);
			 }
		  } else if (msgType == FTP_CLIABORT) {
			 ftpdShowError("Client aborted send.");
			 break;
		  } else { 
			 // Unexpected message type
			 ftpdShowError("Got unexpected message type %d", msgType);
			 assert(FALSE);
		  }
		}
		break;  // FTP_SR
		
      // Handle FTP_LSR message...
	  case FTP_LSR: 
		pthread_mutex_lock(&chDirLock);  
		chdir(curDir);
		if ((dirp = opendir(".")) == NULL) {
		  // Cannot ls, so send FTP_ERR
		  perror("FTPD couldn't open current dir");
		  break;
		} else {
		  // Ready to send ls info, so send FTP_FILESTART		
		  outMsg.init(FTP_FILESTART);
		  DO_FTPD_SEND("ls request failed");
		}
		
		// While there are still directory entries, send them.
		// Could handle readdir_r failure here, returning FTP_ERR in
		// mid-transmission if something goes wrong ???
#ifdef solaris
		while ((int*)readdir_r(dirp, dirEntry) != NULL ) {
#else
		// should be thread safe on XPG4-UNIX
		while ((dirEntry = readdir(dirp)) != NULL ) {
#endif
		  outMsg.init(FTP_DATA, dirEntry->d_name);
		  DO_FTPD_SEND("ls request failed");
		}

		pthread_mutex_unlock(&chDirLock);  
		outMsg.init(FTP_EOF);
		DO_FTPD_SEND("ls request failed");
		(void)closedir(dirp);
		
		break;  // FTP_LSR
		
      // Handle FTP_CDR message...
	  case FTP_CDR: 
		pthread_mutex_lock(&chDirLock);  
		chdir(curDir);
		if(chdir(fileName) != 0) {
		  pthread_mutex_unlock(&chDirLock);  
		  // Some problem changing directory, so send FTP_ERRFNAME
		  ftpdShowError("Cannot change to directory %s", 
							 fileName);
		  outMsg.init(FTP_ERRFNAME);
		  DO_FTPD_SEND("cd request failed");
		} else {
		  // Cd worked, so send FTP_CDOK back (unless can't get cwd
		  // name for some reason)
		  getcwd(curDir, (size_t)(_POSIX_PATH_MAX + 1));
		  if (! getcwd(dirNameBuf, (size_t)(_POSIX_PATH_MAX + 1))) {
			 pthread_mutex_unlock(&chDirLock);  
			 perror("FTPD couldn't get current dir name");
			 outMsg.init(FTP_ERRFNAME);
			 DO_FTPD_SEND("cd request failed");
		  }
		  pthread_mutex_unlock(&chDirLock);  
		  outMsg.init(FTP_CDOK, dirNameBuf);
		  DO_FTPD_SEND("cd request failed");
		}
		
		break;  // FTP_CDR
		
      // Handle FTP_CLIABORT
	  case FTP_CLIABORT:
		// People don't seem to like having IPv6close() called by
		// both client and server on a close.  Now client just sends
		// disconnect request to server and server closes the connection

		// Send ack back
		// outMsg.init(FTP_CLIABORTOK);
		// DO_FTPD_SEND("client abort request failed");
		
		// ...and tear the connection down
		IPv6close(connectDesc);
		
		DO_FTPD_WRITE_CONSOLE("FTPd server session terminated.\n");
		pthread_exit(0);
		
		break; //FTP_CLIABORT
		
      // an unexpected message was received
	  default:
		// Unexpected message type
		ftpdShowError("Got unexpected message type %d", msgType);
		assert(FALSE);
    }
  }
  return 0;  // Must satisfy this signature to be a thread start function
}

// Print an FTP message to the console --  basically just a printf wrapper.
void
ftpdShowMsg(char *format, ...) {
  va_list ap;
  // You will get an unused variable message here -- ignore it.
  va_start(ap, format);
  vfprintf(stdout, format, ap);
  va_end(ap);
  printf("\n");
  fflush(stdout);
}

// Print an FTPd error message to standard out -- basically just a printf
// wrapper.
void 
ftpdShowError(char *format, ...)
{
  printf("FTPd ERROR - ");
  va_list ap;
  // You will get an unused variable message here -- ignore it.
  va_start(ap, format);
  vfprintf(stderr, format, ap);
  va_end(ap);
  
  fprintf(stderr, "\n\a\a");
  fflush(stderr);
}

/* Stupid wrapper around write to support verification */
ssize_t 
v1(int fildes, const void *buf, size_t nbyte) {
  return write(fildes, buf, nbyte);
}
