/******************************************************************************
Header:		globals.h

Description:	Include this file to get all external declarations of globals

Author(s):	Ben Teitelbaum

Class:		UW/CS640

Modifications:

$Log: globals.h,v $

******************************************************************************/
#ifndef GLOBALS_H
#define GLOBALS_H


/******************************************************************************
			     Include header files
******************************************************************************/
#include <pthread.h>
// #include <synch.h>
#include "types.h"

/******************************************************************************
			     Some Global Constants
******************************************************************************/
#define FTPD_SERVICE_ID 66	// The "well-known" service ID of an FTP server
#define MAX_THREAD_NAME_LEN 50  // Maximum thread name length


/******************************************************************************
	     	       External Declarations of Globals
******************************************************************************/
extern pthread_mutex_t consoleLock;
extern pthread_mutex_t chDirLock;

extern int AAL7_TIMEOUT_CSEC;
extern int AAL7_MAX_TIMEOUTS;

extern bool SHOW_NET;

extern int ATM_SIGNAL_TIMEOUT;

extern char* ROUTING_TABLE;

#endif // GLOBALS_H
