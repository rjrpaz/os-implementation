/******************************************************************************
Source File:   status.h

Description:   Status/return codes

Author(s):  Ben Teitelbaum

Class:      UW/CS-640

Date Created:  12 Nov 1995

Modifications: 

$Log: status.h,v $

******************************************************************************/

#if !defined(HEADER_STATUS_H)
#define HEADER_STATUS_H 1

/******************************************************************************
           Define status/return codes
******************************************************************************/

/*** general status codes ***/
#define STAT_OK       0         // the operation was successful

#define STAT_FAIL    -1         // the operation failed (exact reason
                                // unknown or unspecifiable)

#define STAT_BAD     -2         // the specified object/resource is
                                //   not valid or is not currently
                                //   active/available

#define STAT_INUSE   -3         // the object/resource is already in
                                // use

#define STAT_FULL    -4         // the object/resource is full

#define STAT_EMPTY   -5			  // the object/resource is empty

#define STAT_RANGE   -6			  // the value is not in the desired
                                // range

#define STAT_TIMEOUT -7			  // timed out trying to acquire the 
                                // object/resource

#define STAT_NOSPACE -8			  // no space exists to perform the 
                                // operation

#define STAT_EOF     -9			  // at end of file

/*** system resource error codes ***/
#define  STAT_MEM    -100 // insufficient memory existed to
                          // complete the operation

#define STAT_IO      -110    // an I/O error occurred at the system
                                // level

#define STAT_ADDR    -111  // a problem occurred translating
                           // or obtaining a system level
                           // network address

/*** connection status codes ***/
#define STAT_NOLINK     -200  // the link is not active


/******************************************************************************
                Type definitions
******************************************************************************/

typedef int status_t;


#endif //HEADER_STATUS_H


