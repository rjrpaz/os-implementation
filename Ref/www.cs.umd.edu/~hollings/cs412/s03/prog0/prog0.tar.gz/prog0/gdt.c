// Initialize kernel GDT.
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.5 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#include "segment.h"
#include "tss.h"
#include "gdt.h"

// This is defined in lowlevel.asm.
extern void Load_GDTR( unsigned short* limitAndBase );

// ----------------------------------------------------------------------
// Data
// ----------------------------------------------------------------------

// Number of entries in the kernel GDT.
#define NUM_GDT_ENTRIES 16

// This is the kernel's global descriptor table.
static struct Segment_Descriptor s_GDT[ NUM_GDT_ENTRIES ];

// Number of allocated GDT entries.
static int s_numAllocated = 0;

// ----------------------------------------------------------------------
// Functions
// ----------------------------------------------------------------------

// Allocate an descriptor from the GDT.
// Returns null if there are none left.
struct Segment_Descriptor* Allocate_Segment_Descriptor( void )
{
    struct Segment_Descriptor* desc = 0;
    int i;

    // FIXME: race condition

    // Note; entry 0 is unused (thus never allocated)
    for ( i = 1; i < NUM_GDT_ENTRIES; ++i ) {
	desc = &s_GDT[ i ];
	if ( desc->avail ) {
	    ++s_numAllocated;
	    desc->avail = 0;
	    break;
	}
    }

    return desc;
}

// Free a segment descriptor.
void Free_Segment_Descriptor( struct Segment_Descriptor* desc )
{
    // FIXME: race condition

    Init_Null_Segment_Descriptor( desc );
    desc->avail = 1;
    --s_numAllocated;
}

// Get the index (int the GDT) of given segment descriptor.
int Get_Descriptor_Index( struct Segment_Descriptor* desc )
{
    return (int) (desc - s_GDT);
}

// Initialize the kernel's GDT.
void Init_GDT( void )
{
    unsigned short limitAndBase[3];
    unsigned long gdtBaseAddr = (unsigned long) s_GDT;
    struct Segment_Descriptor* desc;
    int i;

    // Clear out entries.
    for ( i = 0; i < NUM_GDT_ENTRIES; ++i ) {
	desc = &s_GDT[ i ];
	Init_Null_Segment_Descriptor( desc );
	desc->avail = 1;
    }

    // Kernel code segment.
    desc = Allocate_Segment_Descriptor();
    Init_Code_Segment_Descriptor(
	desc,
	0,		// base address
	0x100000,	// num pages (== 2^20)
	0		// privilege level (0 == kernel)
    );

    // Kernel data segment.
    desc = Allocate_Segment_Descriptor();
    Init_Data_Segment_Descriptor(
	desc,
	0,		// base address
	0x100000,	// num pages (== 2^20)
	0		// privilege level (0 == kernel)
    );

    // Shared TSS, used by kernel and user procs.
    desc = Allocate_Segment_Descriptor();
    Init_TSS_Descriptor( desc, &g_theTSS );

    // Activate the kernel GDT.
    limitAndBase[0] = sizeof( struct Segment_Descriptor ) * NUM_GDT_ENTRIES;
    limitAndBase[1] = gdtBaseAddr & 0xffff;
    limitAndBase[2] = gdtBaseAddr >> 16;
    Load_GDTR( limitAndBase );
}
