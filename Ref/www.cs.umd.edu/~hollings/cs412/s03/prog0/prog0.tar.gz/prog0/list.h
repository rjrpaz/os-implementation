// Generic list macros
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.4 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#ifndef LIST_H
#define LIST_H

// Define a list type.
#define DEFINE_LIST( listTypeName, nodeTypeName )	\
struct listTypeName {					\
    struct nodeTypeName *head, *tail;			\
}

// Define members of a struct to be used as link fields for
// membership in given list type.
#define DEFINE_LINK( listTypeName, nodeTypeName ) \
    struct nodeTypeName * prev##listTypeName, * next##listTypeName

// Link accessors.
#define NODE_NEXT( listTypeName, nodePtr ) ((nodePtr)->next##listTypeName)
#define NODE_PREV( listTypeName, nodePtr ) ((nodePtr)->prev##listTypeName)

// Add a node to beginning of given list.
#define ADD_NODE_BACK( listTypeName, listPtr, nodePtr )		\
do {								\
    (nodePtr)->next##listTypeName = 0;				\
    if ( (listPtr)->tail == 0 ) {				\
	(listPtr)->head = (listPtr)->tail = (nodePtr);		\
	(nodePtr)->prev##listTypeName = 0;			\
    }								\
    else {							\
	(listPtr)->tail->next##listTypeName = (nodePtr);	\
	(nodePtr)->prev##listTypeName = (listPtr)->tail;	\
	(listPtr)->tail = (nodePtr);				\
    }								\
} while ( 0 )

// Get the front (head) element of given list.
#define GET_NODE_FRONT( listPtr ) ((listPtr)->head)

// Remove the front (head) element of given list.
#define REMOVE_NODE_FRONT( listTypeName, listPtr )		\
do {								\
    if ( (listPtr)->head != 0 ) {				\
	(listPtr)->head = (listPtr)->head->next##listTypeName;	\
	if ( (listPtr)->head == 0 )				\
	    (listPtr)->tail = 0;				\
	else							\
	    (listPtr)->head->prev##listTypeName = 0;		\
    }								\
} while ( 0 )

// Remove a particular node from given list.
#define REMOVE_NODE( listTypeName, listPtr, nodePtr )		\
do {								\
    if ( (nodePtr)->prev##listTypeName != 0 )			\
	(nodePtr)->prev##listTypeName->next##listTypeName =	\
	    (nodePtr)->next##listTypeName;			\
    else							\
	(listPtr)->head = (nodePtr)->next##listTypeName;	\
    if ( (nodePtr)->next##listTypeName != 0 )			\
	(nodePtr)->next##listTypeName->prev##listTypeName =	\
	    (nodePtr)->prev##listTypeName;			\
    else							\
	(listPtr)->tail = (nodePtr)->prev##listTypeName;	\
} while ( 0 )

// Initialize a new (empty) list.
#define INIT_LIST(listPtr)			\
do {						\
    (listPtr)->head = (listPtr)->tail = 0;	\
} while ( 0 )


#endif // LIST_H
