// Thread queue data structure and functions
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.1 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#include "kthread.h"

// Add a thread to a thread queue.
void Enqueue_Thread( struct Thread_Queue* queue, struct Kernel_Thread* kthread )
{
    ADD_NODE_BACK( Thread_Queue, queue, kthread );
}

// Remove a thread from the head of a thread queue.
struct Kernel_Thread* Dequeue_Thread( struct Thread_Queue* queue )
{
    struct Kernel_Thread* kthread = GET_NODE_FRONT(queue);
    if ( kthread != 0 ) {
	REMOVE_NODE_FRONT( Thread_Queue, queue );
    }

    return kthread;
}

// Remove given thread from an arbitrary position in a thread queue.
void Remove_Thread( struct Thread_Queue* queue, struct Kernel_Thread* kthread )
{
    REMOVE_NODE( Thread_Queue, queue, kthread );
}

// Test whether given thread queue is empty.
Boolean Is_Thread_Queue_Empty( struct Thread_Queue* queue )
{
    return queue->head == 0;
}

// Put given thread queue in an empty state.
void Clear_Thread_Queue( struct Thread_Queue* queue )
{
    queue->head = queue->tail = 0;
}
