// Thread queue data structure and functions
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.2 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#ifndef THRQUEUE_H
#define THRQUEUE_H

#include "ktypes.h"
#include "list.h"

struct Kernel_Thread;

// Queue of threads.  We use this data structure and its
// operations for several purposes:
//  - the run queue
//  - wait queues (where threads wait for a condition or event)
//  - the reaper queue (where completed threads are sent)
DEFINE_LIST( Thread_Queue, Kernel_Thread );
#define THREAD_QUEUE_INITIALIZER { 0, 0 }

// General thread queue functions.
void Enqueue_Thread( struct Thread_Queue* queue, struct Kernel_Thread* kthread );
struct Kernel_Thread* Dequeue_Thread( struct Thread_Queue* queue );
void Remove_Thread( struct Thread_Queue* queue, struct Kernel_Thread* kthread );
Boolean Is_Thread_Queue_Empty( struct Thread_Queue* queue );
void Clear_Thread_Queue( struct Thread_Queue* queue );

#endif // THRQUEUE_H
