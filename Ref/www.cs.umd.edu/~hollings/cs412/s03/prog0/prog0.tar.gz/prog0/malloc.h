// GeekOS memory allocation API
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.1 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#ifndef MALLOC_H
#define MALLOC_H

void Init_Heap( unsigned long start, unsigned long size );
void* Malloc( unsigned long size );
void* Malloc_Atomic( unsigned long size );
void Free( void* buf );
void Free_Atomic( void* buf );

#endif // MALLOC_H
