// A test program for GeekOS user mode

#include "libuser.h"

void Main( void )
{
    int i, counter = 0;

    Print_String( "I am the c program\n" );
}
