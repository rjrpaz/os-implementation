// A test program for GeekOS user mode

#include "libuser.h"

void Main( void )
{
    int pid;
    char buf[79];

    while ( TRUE ) {
	Print_String (" % ");
	Read_Line( buf, sizeof(buf) );
	if ( strcmp( buf, "exit\n" ) == 0 )
	    break;
	if ( strcmp( buf, "\n" ) == 0 )
	    continue;

	buf[strlen(buf)-1] = '\0';
	pid = Spawn_Program ( buf );
	if (pid > 0) {
	    Wait(pid);
	}
    }

    Print_String( "DONE!\n" );
}
