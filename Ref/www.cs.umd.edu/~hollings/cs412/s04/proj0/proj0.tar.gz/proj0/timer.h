// GeekOS timer interrupt support
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.1 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#ifndef TIMER_H
#define TIMER_H

#define TIMER_IRQ 0

extern volatile unsigned long g_numTicks;

void Init_Timer( void );

#endif // TIMER_H
