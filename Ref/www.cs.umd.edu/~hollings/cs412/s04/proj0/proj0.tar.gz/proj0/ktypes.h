// Kernel data types
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.2 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#ifndef KTYPES_H
#define KTYPES_H

typedef enum { FALSE=0, TRUE=1 } Boolean;

#endif // KTYPES_H
