// x86 port IO routines
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.3 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#ifndef IO_H
#define IO_H

void Out_Byte( unsigned short port, unsigned char value );
unsigned char In_Byte( unsigned short port );

void Out_Word( unsigned short port, unsigned short value );
unsigned short In_Word( unsigned short port );

void IO_Delay( void );

#endif // IO_H
