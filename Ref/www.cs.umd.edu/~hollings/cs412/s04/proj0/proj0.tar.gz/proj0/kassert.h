// Definition of KASSERT() macro, and other useful debug macros
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.6 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#ifndef KASSERT_H
#define KASSERT_H

#include "screen.h"

#ifndef NDEBUG

struct Kernel_Thread;
extern struct Kernel_Thread* g_currentThread;

#define KASSERT( cond ) 				\
do {							\
    if ( !(cond) ) {					\
	Set_Current_Attr( ATTRIB(RED, GRAY|BRIGHT) );	\
	Print( "Failed assertion: %s at %s, line %d (thread=%x)",\
		#cond, __FILE__, __LINE__, g_currentThread );	\
	while (1)					\
	   ; 						\
    }							\
} while (0)

// Spin for some number of iterations.
// This is useful for slowing down things that go by too
// quickly.
#define PAUSE( count )			\
do {					\
    unsigned long i;			\
    for ( i = 0; i < (count); ++i )	\
	;				\
} while (0)

#else

// The debug macros are no-ops when NDEBUG is defined.
#define KASSERT( cond )
#define PAUSE( count )

#endif

// Stop dead.
// Its behavior does not depend on whether or not this
// is a debug build.
#define STOP() while (1)

#endif // KASSERT_H
