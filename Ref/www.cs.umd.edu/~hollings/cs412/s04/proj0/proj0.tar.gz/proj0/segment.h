// General data structures and routines for segmentation
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.4 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

// Source: _Protected Mode Software Architecture_ by Tom Shanley,
// ISBN 020155447X.

#ifndef SEGMENT_H
#define SEGMENT_H

#include "ktypes.h"

struct TSS;

// The general format of a segment descriptor.
struct Segment_Descriptor {
    unsigned short sizeLow        __attribute__((packed)) ;
    unsigned int baseLow     : 24 __attribute__((packed)) ;
    unsigned int type        : 4  __attribute__((packed)) ;
    unsigned int system      : 1  __attribute__((packed)) ;
    unsigned int dpl         : 2  __attribute__((packed)) ;
    unsigned int present     : 1  __attribute__((packed)) ;
    unsigned int sizeHigh    : 4  __attribute__((packed)) ;
    unsigned int avail       : 1  __attribute__((packed)) ;
    unsigned int reserved    : 1  __attribute__((packed)) ; // set to zero
    unsigned int dbBit       : 1  __attribute__((packed)) ;
    unsigned int granularity : 1  __attribute__((packed)) ;
    unsigned char baseHigh        __attribute__((packed)) ;
};

// Construct a segment selector.
static __inline__ unsigned short Selector( int rpl, Boolean isGDT, int index )
{
    unsigned short selector = 0;
    selector = (rpl & 0x3) | ((isGDT ? 0 : 1) << 2) | ((index & 0x1FFF) << 3);
    return selector;
}

// Routines to initialize segment descriptors.
// Code and data segments must start on a page-aligned address
// and are sized in pages.

void Init_Null_Segment_Descriptor( struct Segment_Descriptor* desc );

void Init_Code_Segment_Descriptor(
    struct Segment_Descriptor* desc,
    unsigned long baseAddr,
    unsigned long numPages,
    int privilegeLevel
);
void Init_Data_Segment_Descriptor(
    struct Segment_Descriptor* desc,
    unsigned long baseAddr,
    unsigned long numPages,
    int privilegeLevel
);
void Init_TSS_Descriptor( struct Segment_Descriptor* desc, struct TSS* theTSS );

void Init_LDT_Descriptor(
    struct Segment_Descriptor* desc,
    struct Segment_Descriptor theLDT[],
    int numEntries
);

#endif // SEGMENT_H
