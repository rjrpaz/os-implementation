// Memory handling and allocation
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.14 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#include "defs.h"
#include "kassert.h"
#include "bootinfo.h"
#include "gdt.h"
#include "screen.h"
#include "int.h"
#include "malloc.h"
#include "mem.h"

// ----------------------------------------------------------------------
// Private data and functions
// ----------------------------------------------------------------------

// We use this constant to indicate an "invalid" page;
// for example, it terminates the freelist.
#define INVALID_PAGE (~0UL)

// We'll leave the page at address zero alone, and start allocation
// at the next page.  This will allow this us to treat a null pointer
// as "invalid".  Eventually we will have paged virtual memory,
// in which case we can *use* physical page 0.  (Of course, we won't
// *map* anything at address 0.)
#define FIRST_PAGE (1 * PAGE_SIZE)

// Get the Page struct associated with given address.
#define Get_Page(addr) (&s_pageList[Page_Index(addr)])

// Pointer to the table of Page structs.
static struct Page* s_pageList;

// Address of first free page.
static unsigned long s_firstFreePage;

// Initialize given page as being "already allocated",
// meaning it can be returned to the freelist with
// the Free_Page() function.
static void Add_Allocated_Page( unsigned long addr )
{
    struct Page* page = Get_Page( addr );
    page->flags = PAGE_ALLOCATED;
    page->nextFree = INVALID_PAGE;
}

// Initialize given page as one that should be incorporated into
// the kernel free page list.  Returns TRUE if the page was successfully
// added, or FALSE otherwise (if it couldn't be used).
static Boolean Add_Avail_Page( unsigned long addr, unsigned long prev )
{
    struct Page* page = Get_Page( addr );

    KASSERT( addr != KERN_THREAD_OBJ && addr != KERN_STACK );

    page->flags = 0;
    page->nextFree = INVALID_PAGE; // ensures that list will be terminated

    // Link the previous available page initialized to this one
    if ( prev != INVALID_PAGE ) {
	struct Page* prevPage = Get_Page( prev );
	prevPage->nextFree = addr;
    }

    return TRUE;
}

// Initialize given page as reserved for kernel.
static void Add_Kernel_Page( unsigned long addr )
{
    struct Page* page = Get_Page( addr );
    page->flags = PAGE_KERN;
    page->nextFree = INVALID_PAGE;
}

// Initialize given page as reserved for hardware (or BIOS, etc.)
static void Add_HW_Page( unsigned long addr )
{
    struct Page* page = Get_Page( addr );
    page->flags = PAGE_HW;
    page->nextFree = INVALID_PAGE;
}

// Initialize a given page as belonging to the kernel heap.
static void Add_Heap_Page( unsigned long addr )
{
    struct Page* page = Get_Page( addr );
    page->flags = PAGE_HEAP;
    page->nextFree = INVALID_PAGE;
}

// ----------------------------------------------------------------------
// Public functions
// ----------------------------------------------------------------------
//

// The linker defines this symbol to indicate the end of
// the executable image.
extern char end;

// The Main() function happens to be at the very beginning
// of the kernel image.
void Main( struct Boot_Info* );

// Initialize memory management data structures.
// Enables the use of Alloc_Page() and Free_Page() functions.
void Init_Mem( struct Boot_Info* bootInfo )
{
    // Memory looks like this:
    // 0 - start: available (might want to preserve BIOS data area)
    // start - end: kernel
    // end - ISA_HOLE_START: available
    // ISA_HOLE_START - ISA_HOLE_END: used by hardware (and ROM BIOS?)
    // ISA_HOLE_END - HIGHMEM_START: used by initial kernel thread
    // HIGHMEM_START - end of memory: available

    // We'll put the list of Page objects right after the end
    // of the kernel, and mark it as "kernel".  This will bootstrap
    // us sufficiently that we can start allocating pages and
    // keeping track of them.

    unsigned numPages = bootInfo->memSizeKB >> 2;
    unsigned endOfMem = numPages * PAGE_SIZE;
    unsigned numPageListBytes = sizeof(struct Page) * numPages;
    unsigned long kernStart, kernEnd;
    unsigned long addr, prev;
    unsigned pageCount = 0;

#define ADD_AVAIL_PAGE(addr,prev)		\
do {						\
    if ( Add_Avail_Page( addr, prev ) ) {	\
	prev = addr;				\
	++pageCount;				\
    }						\
} while (0)

    // Before we do anything, switch from setup.asm's temporary GDT
    // to the kernel's permanent GDT.
    Init_GDT();

    kernStart = KERNEL_START_ADDR;
    KASSERT( (kernStart & PAGE_MASK) == 0 );

    s_pageList = (struct Page*) Round_Up_To_Page( (unsigned long) &end );
    kernEnd = Round_Up_To_Page( ((unsigned long) s_pageList) + numPageListBytes );

    // Page 0 is not used.
    s_pageList[0].flags = PAGE_UNUSED;
    s_pageList[0].nextFree = INVALID_PAGE;

    // The initial kernel thread context and stack pages are
    // "pre-allocated".
    Add_Allocated_Page( KERN_THREAD_OBJ );
    Add_Allocated_Page( KERN_STACK );

    // Add pages FIRST_PAGE - start of kernel
    prev = INVALID_PAGE;
    for ( addr = FIRST_PAGE; addr < kernStart; addr += PAGE_SIZE )
	ADD_AVAIL_PAGE( addr, prev );

    // Add pages start of kernel - end of kernel
    for ( addr = kernStart; addr < kernEnd; addr += PAGE_SIZE )
	Add_Kernel_Page( addr );

    // Add pages end of kernel - start of ISA hole
    for ( addr = kernEnd; addr < ISA_HOLE_START; addr += PAGE_SIZE )
	ADD_AVAIL_PAGE( addr, prev );

    // Add start of ISA hole - end of ISA hole
    for ( addr = ISA_HOLE_START; addr < ISA_HOLE_END; addr += PAGE_SIZE )
	Add_HW_Page( addr );

    // Create the kernel heap from the beginning of available high
    // memory to the end of the memory.
    for ( addr = HIGHMEM_START; addr < endOfMem; addr += PAGE_SIZE )
	Add_Heap_Page( addr );
    Init_Heap( HIGHMEM_START, endOfMem - HIGHMEM_START );

    // Initialize freelist
    s_firstFreePage = FIRST_PAGE;

    Print( "%d pages of memory available...\n", pageCount );

#undef ADD_AVAIL_PAGE
}

// Allocate a page of physical memory.
// Must be called with interrupts disabled!
void* Alloc_Page( void )
{
    unsigned long addr = s_firstFreePage;
    struct Page* page;

    KASSERT( !Interrupts_Enabled() );

    if ( addr == INVALID_PAGE )
	return 0;

    page = Get_Page( addr );
    page->flags |= PAGE_ALLOCATED;
    s_firstFreePage = page->nextFree;

    return (void*) addr;
}

// Allocate a page of physical memory; assumes that
// interrupts are currently enabled.
void* Alloc_Page_Atomic( void )
{
    void* addr;

    Disable_Interrupts();
    addr = Alloc_Page();
    Enable_Interrupts();

    return addr;
}

// Free a page of physical memory.
// Must be called with interrupts disabled!
void Free_Page( void* pageAddr )
{
    unsigned long addr = (unsigned long) pageAddr;
    struct Page* page;

    KASSERT( !Interrupts_Enabled() );

    KASSERT( Is_Page_Multiple( addr ) );

    page = Get_Page( addr );
    KASSERT( (page->flags & PAGE_ALLOCATED) != 0 );

    page->flags &= ~(PAGE_ALLOCATED);
    page->nextFree = s_firstFreePage;
    s_firstFreePage = addr;
}

// Atomically free a page.
// Assumes that interrupts are enabled.
void Free_Page_Atomic( void* pageAddr )
{
    Disable_Interrupts();
    Free_Page( pageAddr );
    Enable_Interrupts();
}
