// x86 TSS data structure and routines
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.2 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

// Source: _Protected Mode Software Architecture_ by Tom Shanley,
// ISBN 020155447X.

#include "kassert.h"
#include "defs.h"
#include "gdt.h"
#include "segment.h"
#include "string.h"
#include "tss.h"

struct TSS g_theTSS;

// Initialize the kernel TSS.  This must be done after the memory and
// GDT initialization, but before the scheduler is started.
void Init_TSS( void )
{
    struct Segment_Descriptor* desc;
    unsigned short selector;

    desc = Allocate_Segment_Descriptor();
    KASSERT( desc != 0 );

    memset( &g_theTSS, '\0', sizeof( struct TSS ) );
    Init_TSS_Descriptor( desc, &g_theTSS );

    selector = Selector( 0, TRUE, Get_Descriptor_Index( desc ) );

    __asm__ __volatile__ (
	"ltr %0"
	:
	: "a" (selector)
    );
}
