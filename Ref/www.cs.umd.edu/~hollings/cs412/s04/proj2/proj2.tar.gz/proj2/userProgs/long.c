// A test program for GeekOS user mode
// tests if the spawning program is waiting for
// the spawned program to finish.
#include "libuser.h"

int Main( int argc, char ** argv )
{
  int i;
  int x = 0;
  Print_String( "Start Long\n" );
  for (i=0;i<100000;i++) {
    x++;
  }

  Print_String( "End Long\n" );
  return 0;
}
