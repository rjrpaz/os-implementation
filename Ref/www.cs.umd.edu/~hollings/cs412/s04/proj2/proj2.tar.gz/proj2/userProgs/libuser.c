#include "libuser.h"

#define SYSCALL "int $0x90"

void Entry(void) 
{
   // you need to call the executable's main function here and ensure that it is properly cleaned up

   // these are the parameters to be used for main
   int argc = 0;
   char ** argv = NULL;
}

int Null( void )
{
   int num = SYS_NULL, rc;

   __asm__ __volatile__ (
      SYSCALL
      : "=a" (rc)// system call returns value in eax
      : "a" (num)// system call number specified in eax
   );

   return rc;
}

void Exit(void ) {
}

int Print_String( const char* message ) {
   return -1;
}

Keycode Get_Key( void ) {
   return -1;
}

int Spawn_Program(char* program) {
   return -1;
}

int Wait( unsigned int pid ) {
   return -1;
}

