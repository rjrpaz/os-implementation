#include "pfat.h"
#include "screen.h"
#include "malloc.h"
#include "string.h"
#include "kthread.h"
#include "elf.h"
#include "lprog.h"

#include "mem.h"

int elfDebug = 0;

struct Loadable_Program *Read_Elf_Executable(char *programName)
{
    char *program;
    int length;
    int ret;
    struct Loadable_Program *lp;

    int i;
    int size;
    int maxSize;
    int zeroSize;
    elfHeader *hdr;
    programHeader *phdr;

    if (elfDebug) 
      Print("reading %s...\n", programName);

    /* ReadFileAndAllocate will return a memory copy of the program on disk*/
    ret = ReadFileAndAllocate(programName, &program, &length);
    if (ret) 
      return NULL;

    if (elfDebug) 
      Print("reading %s done\n", programName);

    lp = (struct Loadable_Program *) Malloc_Atomic(sizeof(struct  Loadable_Program));

    /* here you should put your code from project 1
    ........
    ........
     */

    return NULL;
}
