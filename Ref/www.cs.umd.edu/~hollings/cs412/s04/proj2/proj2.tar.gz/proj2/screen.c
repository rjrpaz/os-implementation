// GeekOS text screen output
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.6 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#include <stdarg.h>
#include "ktypes.h"
#include "io.h"
#include "screen.h"

// ----------------------------------------------------------------------
// Private functions and data
// ----------------------------------------------------------------------

static int s_row, s_col;
static unsigned char s_currentAttr;

#define NUM_SCREEN_DWORDS ((NUMROWS * NUMCOLS * 2) / 4)
#define NUM_SCROLL_DWORDS (((NUMROWS-1) * NUMCOLS * 2) / 4)
#define NUM_DWORDS_PER_LINE ((NUMCOLS*2)/4)
#define FILL_DWORD (0x00200020 | (s_currentAttr<<24) | (s_currentAttr<<8))

// Scroll the display one line.
// We speed things up by copying 4 bytes at a time.
static void Scroll( void )
{
    unsigned int* v;
    int i, n = NUM_SCROLL_DWORDS;
    unsigned int fill = FILL_DWORD;

    // Move lines 1..NUMROWS-1 up one position.
    for ( v = (unsigned int*)VIDMEM, i = 0; i < n; ++i ) {
	*v = *(v + NUM_DWORDS_PER_LINE);
	++v;
    }

    // Clear out last line.
    for ( v = (unsigned int*)VIDMEM + n, i = 0; i < NUM_DWORDS_PER_LINE; ++i ) {
	*v++ = fill;
    }
}

// Clear current cursor position to end of line using
// current attribute.
static void Clear_To_EOL( void )
{
    int n = (NUMCOLS - s_col);
    unsigned char* v = VIDMEM + s_row*(NUMCOLS*2) + s_col*2;
    while ( n-- > 0 ) {
	*v++ = ' ';
	*v++ = s_currentAttr;
    }
}

// Move to the beginning of the next line, scrolling
// if necessary.
static void Newline( void )
{
    ++s_row;
    s_col = 0;
    if ( s_row == NUMROWS ) {
	Scroll();
	s_row = NUMROWS - 1;
    }
}

// Write the graphic representation of given character to the screen
// at current position, with current attribute, scrolling if
// necessary.
static void Put_Graphic_Char( int c )
{
    unsigned char* v = VIDMEM + s_row*(NUMCOLS*2) + s_col*2;

    // Put character at current position
    *v++ = (unsigned char) c;
    *v = s_currentAttr;

    if ( s_col < NUMCOLS - 1 )
	++s_col;
    else {
	Newline();
    }
}

// Put one character to the screen using the current cursor position
// and attribute, scrolling if needed.  The caller should update
// the cursor position, once all characters have been written.
void Put_Char_Imp( int c )
{
    int numSpaces;

    switch ( c ) {
    case '\n':
	Clear_To_EOL();
	Newline();
	break;

    case '\t':
	numSpaces = TABWIDTH - (s_col % TABWIDTH);
	while ( numSpaces-- > 0 ) {
	    Put_Graphic_Char( ' ' );
	}
	break;

    default:
	Put_Graphic_Char( c );
	break;
    }
}

// Update the location of the hardware cursor.
static void Update_Cursor( void )
{
    // The cursor location is a character offset from the beginning
    // of page memory (I think).
    unsigned characterPos = (s_row * NUMCOLS) + s_col;
    unsigned char origAddr;

    // Save original contents of CRT address register.
    // It is considered good programming practice to restore
    // it to its original value after modifying it.
    origAddr = In_Byte( CRT_ADDR_REG );
    IO_Delay();

    // Set the high cursor location byte
    Out_Byte( CRT_ADDR_REG, CRT_CURSOR_LOC_HIGH_REG );
    IO_Delay();
    Out_Byte( CRT_DATA_REG, (characterPos>>8) & 0xff );
    IO_Delay();

    // Set the low cursor location byte
    Out_Byte( CRT_ADDR_REG, CRT_CURSOR_LOC_LOW_REG );
    IO_Delay();
    Out_Byte( CRT_DATA_REG, characterPos & 0xff );
    IO_Delay();

    // Restore contents of the CRT address register
    Out_Byte( CRT_ADDR_REG, origAddr );
}

// Helper for %d format in Print() function.
static void Format_D( char* buf, int val )
{
    char stack[16];
    int top = 0;
    Boolean negative;
    unsigned uval;

    // Convert to sign and unsigned magnitude.
    if ( val < 0 ) {
	negative = TRUE;
	uval = -val;
    }
    else {
	negative = FALSE;
	uval = val;
    }

    // Convert magnitude to decimal.  We do this in order of least
    // significant to most significant digit.
    do {
	int digit = uval % 10;
	stack[top++] = digit + '0';
	uval /= 10;
    }
    while ( uval > 0 );

    // Add leading minus sign if negative.
    if ( negative ) {
	*buf++ = '-';
    }

    // Put formatted characters in the output buffer.
    do {
	*buf++ = stack[--top];
    }
    while ( top > 0 );

    // Terminate the output buffer.
    *buf = '\0';
}

// Helper function for %x format in Print() function.
static void Format_X( char* buf, int val )
{
    int i;

    for ( i = 28; i >= 0; i -= 4 ) {
	int x = (val >> i) & 0xf;
	*buf++ = "0123456789abcdef"[x];
    }
    *buf = '\0';
}

// ----------------------------------------------------------------------
// Public functions
// ----------------------------------------------------------------------

// Initialize the screen module.
void Init_Screen( void )
{
    s_row = s_col = 0;
    s_currentAttr = ATTRIB( BLACK, GRAY );
    Clear_Screen();
}

// Clear the screen using the current attribute.
void Clear_Screen( void )
{
    unsigned int* v = (unsigned int*)VIDMEM;
    int i;
    unsigned int fill = FILL_DWORD;

    for ( i = 0; i < NUM_SCREEN_DWORDS; ++i ) {
	*v++ = fill;
    }
}

// Get current cursor position.
void Get_Cursor( int* row, int* col )
{
    *row = s_row;
    *col = s_col;
}

// Set the current cursor position.
void Put_Cursor( int row, int col )
{
    s_row = row;
    s_col = col;
    Update_Cursor();
}

// Get the current character attribute.
unsigned char Get_Current_Attr( void )
{
    return s_currentAttr;
}

// Set the current character attribute.
void Set_Current_Attr( unsigned char attrib )
{
    s_currentAttr = attrib;
}

// Write a single character to the screen at current position
// using current attribute, handling scrolling, special characters, etc.
void Put_Char( int c )
{
    Put_Char_Imp( c );
    Update_Cursor();
}

// Write a string of characters to the screen at current cursor
// position using current attribute.
void Put_String( const char* s )
{
    while ( *s != '\0' ) {
	Put_Char_Imp( *s++ );
    }
    Update_Cursor();
}

// Write a buffer of characters at current cursor position
// using current attribute.
void Put_Buf( const char* buf, unsigned long length )
{
    while ( length > 0 ) {
	Put_Char_Imp( *buf++ );
	--length;
    }
    Update_Cursor();
}

// Formatted output to the screen.
// Supports a limited set of printf()-style format options.
void Print( const char* fmt, ... )
{
    char buf[64];
    va_list args;
    int ival;
    const char* sval;

    va_start( args, fmt );

    while ( *fmt != '\0' ) {
	switch ( *fmt ) {
	case '%':
	    ++fmt;
	    switch ( *fmt ) {
	    case 'd':
		ival = va_arg( args, int );
		Format_D( buf, ival );
		Put_String( buf );
		break;

	    case 'x':
		ival = va_arg( args, int );
		Format_X( buf, ival );
		Put_String( buf );
		break;

	    case 's':
		sval = va_arg( args, const char* );
		Put_String( sval );
		break;

	    case 'c':
		ival = va_arg( args, int );
		Put_Char_Imp( ival & 0xff );
		break;

	    default:
		Put_Char_Imp( *fmt );
		break;
	    }
	    break;

	default:
	    Put_Char_Imp( *fmt );
	    break;
	}

	++fmt;
    }
    Update_Cursor();

    va_end( args );
}
