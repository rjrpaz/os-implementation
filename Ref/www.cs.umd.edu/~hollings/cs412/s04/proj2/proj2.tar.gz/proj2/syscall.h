#ifndef SYSCALL_H
#define SYSCALL_H

#include "syscallnos.h"

struct Interrupt_State;

typedef int (*Syscall)( struct Interrupt_State* state );

// Initalize the system call architecture
void Init_Syscall();

// this function adds a system call handler
// the function handler will be called when system call interrupt number index is encountered
void Register_Syscall(Syscall handler, int index);

#endif // SYSCALL_H

