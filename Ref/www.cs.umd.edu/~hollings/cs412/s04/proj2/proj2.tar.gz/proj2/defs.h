// Misc. kernel definitions
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.6 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#ifndef DEFS_H
#define DEFS_H

// Kernel code and data segment selectors.
// Keep these up to date with defs.asm.
#define KERNEL_CS  (1<<3)
#define KERNEL_DS  (2<<3)

// Pages for initial kernel thread context object and stack.
// Keep these up to date with defs.asm.
#define KERN_THREAD_OBJ (1024 * 1024)
#define KERN_STACK (KERN_THREAD_OBJ + 4096)

// Address where kernel is loaded
#define KERNEL_START_ADDR 0x10000

// Kernel and user privilege levels
#define KERNEL_PRIVILEGE 0
#define USER_PRIVILEGE 3

// Software interrupt for syscalls
#define SYSCALL_INT 0x90

#endif // DEFS_H
