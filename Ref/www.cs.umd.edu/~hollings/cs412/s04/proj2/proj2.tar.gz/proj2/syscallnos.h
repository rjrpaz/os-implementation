#ifndef SYSCALLNOS_H
#define SYSCALLNOS_H

/* Proj 2 */
#define SYS_NULL		0
#define SYS_EXIT		1
#define SYS_GETKEY		2
#define SYS_SPAWN		3
#define SYS_WAIT		4
#define SYS_PRINT       	5


/* Proj 3 */
#define SYS_SETSCHED            6
#define SYS_GETTIME	        7

#define SYS_INITSEM	        8
#define SYS_P               	9 
#define SYS_V                  	10
#define SYS_FINISHSEM    	11

/* Proj 5 */

#define SYS_MOUNT                       12
#define SYS_OPEN                        13
#define SYS_CLOSE                       14
#define SYS_DELETE                      15
#define SYS_READ                        16
#define SYS_WRITE                       17
#define SYS_STAT                        18
#define SYS_SEEK                        19
#define SYS_CREATEDIR                   20
#define SYS_FORMAT                      21

/* Proj 3 */
#define SCHEDPOLICY_RR          1
#define SCHEDPOLICY_MF          2

#endif
