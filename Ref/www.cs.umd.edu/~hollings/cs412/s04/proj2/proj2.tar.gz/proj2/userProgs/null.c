// Test for your first user program

#include "libuser.h"

int Main( int argc, char ** argv )
{
  Null();
  for(;;);

  // not really reached
  return 0;
}
