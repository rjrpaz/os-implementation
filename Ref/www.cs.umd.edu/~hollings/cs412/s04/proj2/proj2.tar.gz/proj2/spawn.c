#include "pfat.h"
#include "screen.h"
#include "malloc.h"
#include "string.h"
#include "kthread.h"
#include "segment.h"
#include "gdt.h"
#include "mem.h"
#include "int.h"
#include "idt.h"
#include "lprog.h"
#include "user.h"
#include "defs.h"

/* 
 * Spawn_Program() sets up the memory space, and kickstarts the program
 *
 */

int Spawn_User_Program( char * programName)
{
  struct Loadable_Program *lp = Read_Elf_Executable(programName);
  
  // here you will be filling in the user context that you declared in user.h

  // set up the descriptors and the selectors and put them into the user context struct
  // call kthread function to set up the user thread which is defined in kthread.h and you implement in kthread.c

  // return the pid of the kthread that was created or -1 if something failed
  return -1;
}

// copy memory from user space to kernel space
Boolean Copy_From_User( void* destInKernel, const void* srcInUser, unsigned long bufSize ) {
   // here you need to copy memory from the user space into the kernel

   // you need to ensure that the memory given to you is valid for a user program given its bounds
   // then, copy into destInKernel

   return FALSE;
}

// copy memory from kernel space to user space
Boolean Copy_To_User( void* destInUser, const void* srcInKernel, unsigned long bufSize ) {
   // here you need to copy memory from the kernel into the user space

   // you need to ensure that the memory given to you is valid for a user program given its bounds
   // then, copy into destInUser

   return FALSE;
}



