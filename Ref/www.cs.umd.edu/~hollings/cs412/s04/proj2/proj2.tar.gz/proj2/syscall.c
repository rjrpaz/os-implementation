#include "syscall.h"
#include "screen.h"
#include "kthread.h"
#include "string.h"
#include "lprog.h"
#include "int.h"
#include "malloc.h"

// forward declaration of invalid syscall
int Invalid_Syscall( struct Interrupt_State *state );

// table of system call handlers
static Syscall * g_syscallTable;
static unsigned int g_numSyscalls;

// Initalize the system call architecture
void Init_Syscall()
{
   KASSERT(Interrupts_Enabled());

   g_syscallTable = Malloc_Atomic(sizeof(Syscall));
   g_numSyscalls = 1;
   g_syscallTable[0] = Invalid_Syscall;
}

// this function adds a system call handler
void Register_Syscall(Syscall handler, int index)
{
   KASSERT(Interrupts_Enabled());

   Disable_Interrupts();

   if (g_numSyscalls <= index)
   {
      //resize array
      Syscall * newTable = Malloc((index + 1) * sizeof(Syscall));

      // copy current list of syscalls
      int i = 0;
      for (i = 0; i < g_numSyscalls; i++)
      {
         newTable[i] = g_syscallTable[i];
      }

      // reset size
      g_numSyscalls = index + 1;

      // free old syscall table and make current point to new
      Free(g_syscallTable);
      g_syscallTable = newTable;
   }

   // install system call in index
   g_syscallTable[index] = handler;

   Enable_Interrupts();
}

// System call handler.
void Syscall_Handler( struct Interrupt_State* state )
{
    // The system call number is specified in the eax register.
    unsigned int syscallNum = state->eax;
    int result = -1;

    // only user threads should use this function
    if (g_currentThread->userContext == 0)
    {
       return;
    }

    // Index into the table and call appropriate function
    if (syscallNum < g_numSyscalls)
    {
       // in general interrupts enabled during syscall
       Enable_Interrupts();

       result = g_syscallTable[syscallNum](state);
    }
    else
    {
       Print( "Illegal system call %d by thread %x\n", syscallNum, g_currentThread );
       Reap_Thread( g_currentThread );
       g_killCurrentThread = TRUE;
       g_needReschedule = TRUE;
    }

    // store result
    state->eax = result;

    // make sure interrupts disabled before we begin switching
    if (Interrupts_Enabled()) {
       Disable_Interrupts();
    }

    return;
}

// Invalid system call
int Invalid_Syscall( struct Interrupt_State* state)
{
   Print("No handler for interrupt %d is installed, invalid syscall\n", state->eax);

   return 0;
}

// NULL system call (does nothign)
int Sys_Null( struct Interrupt_State* state ) {
   return 0;
}
