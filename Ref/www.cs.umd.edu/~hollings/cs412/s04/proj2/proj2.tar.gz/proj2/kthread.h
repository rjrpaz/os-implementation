// Kernel threads
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.27 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#ifndef KTHREAD_H
#define KTHREAD_H

#include "ktypes.h"
#include "thrqueue.h"
#include "user.h"

struct Interrupt_State;

// Kernel thread context data structure.
// NOTE: there is assembly code in lowlevel.asm that depends
// on the offsets of the fields in this struct, so if you change
// the layout, make sure everything gets updated.
struct Kernel_Thread {
    unsigned long esp;			// offset 0
    volatile unsigned long numTicks;	// offset 4
    int priority;
    DEFINE_LINK( Thread_Queue, Kernel_Thread );
    void* stackPage;
    struct User_Context* userContext;
    struct Kernel_Thread* owner;
    int refCount;

    // These fields are used to implement the Join() function
    Boolean alive;

    // helpful fields
    int pid;
};

struct threadItem {
    struct Kernel_Thread *thread;
    struct threadItem *next;
};

extern struct threadItem *allThreads;

// Thread start functions should have this signature.
typedef void (*Thread_Start_Func)( unsigned long arg );

// Thread priorities
#define PRIORITY_IDLE    0
#define PRIORITY_USER    1
#define PRIORITY_LOW     2
#define PRIORITY_NORMAL  5
#define PRIORITY_HIGH   10

// Scheduler operations.
void Init_Scheduler( void );
struct Kernel_Thread* Start_Kernel_Thread(
    Thread_Start_Func startFunc,
    unsigned long arg,
    int priority,
    Boolean detached
);
struct Kernel_Thread* Start_User_Thread(
    struct User_Context* userContext,
    unsigned long entryAddr,
    Boolean detached
);
void Make_Runnable( struct Kernel_Thread* kthread );
void Make_Runnable_Atomic( struct Kernel_Thread* kthread );
struct Kernel_Thread* Get_Current( void );
struct Kernel_Thread* Get_Next_Runnable( void );
void Schedule( void );
void Yield( void );
void Exit( void );
void Reap_Thread( struct Kernel_Thread* kthread );
void Join( struct Kernel_Thread* kthread );

// Thread context switch functions, defined in lowlevel.asm
void Switch_To_Thread( struct Kernel_Thread* );
void Restore_Thread( void );

void Detach_Thread( struct Kernel_Thread* kthread );
struct Kernel_Thread* Find_Thread(int pid);

// Wait queue functions.
void Wait( struct Thread_Queue* waitQueue );
void Wake_Up( struct Thread_Queue* waitQueue );
void Wake_Up_One( struct Thread_Queue* waitQueue );

// Pointer to currently executing thread.
extern struct Kernel_Thread* g_currentThread;

// Boolean flag indicating that we need to choose a new runnable thread.
extern Boolean g_needReschedule;

// Boolean flag indicating that the current thread is being
// killed (and should not be put back on the run queue).
extern Boolean g_killCurrentThread;

#endif // KTHREAD_H
