// Symbol mangling macros
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.3 $

// The _S macro mangles a symbol name into whatever format is
// needed for external linkage.  E.g., prepend an underscore
// for PECOFF.

#ifndef SYMBOL_H
#define SYMBOL_H

#ifdef NEED_UNDERSCORE
#  define _S(sym) "_" #sym
#else
#  define _S(sym) #sym
#endif

#endif // SYMBOL_H
