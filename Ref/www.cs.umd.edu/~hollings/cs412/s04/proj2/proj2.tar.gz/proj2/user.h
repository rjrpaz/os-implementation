#ifndef USER_H
#define USER_H

#include "keyboard.h"
#include "ktypes.h"
#include "gdt.h"
#include "segment.h"

#define LDT_SIZE 2
#define MAX_USER_STRING 128

struct User_Context {
   struct Segment_Descriptor ldtMembers[LDT_SIZE];
   struct Segment_Descriptor *ldt;

   unsigned short ldtSel;
   unsigned short codeSel;
   unsigned short dataSel;

   unsigned int stackAddr;
   unsigned int programSize;
   unsigned char * program;
};

Boolean Copy_From_User( void* destInKernel, const void* srcInUser,
	unsigned long bufSize );
Boolean Copy_To_User( void* destInUser, const void* srcInKernel,
	unsigned long bufSize );

Boolean Validate_String(char *kernStr, const char *userStr, unsigned long sizeIn);

#endif
