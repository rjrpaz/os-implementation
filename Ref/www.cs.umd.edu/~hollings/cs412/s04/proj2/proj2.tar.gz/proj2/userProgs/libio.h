#ifndef LIB_IO_H
#define LIB_IO_H

void Printf( const char* fmt, ... );
void Read_Line ( char* buf, int bufSize);
void* Malloc_Atomic( unsigned long size );

#endif

