#ifndef ATOI_H
#define ATOI_H

int atoi(char *buf);
int itoa(char *buf, int num);

#endif
