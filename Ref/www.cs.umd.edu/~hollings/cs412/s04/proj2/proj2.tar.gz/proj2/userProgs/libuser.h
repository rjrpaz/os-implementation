#include "../keyboard.h"
#include "../string.h"
#include "../syscallnos.h"

#ifndef LIB_USER_H
#define LIB_USER_H

extern int Main( int argc, char ** argv );

//entry function
void Entry( void );

int Null( void );
void Exit( void );
int Print_String( const char* message );
Keycode Get_Key( void );
int Spawn_Program(char* program);
int Wait( unsigned int pid );

#endif
