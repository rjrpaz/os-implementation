#ifndef LPROG_H
#define LPROG_H

#define STACK_SIZE (PAGE_SIZE * 10)

struct Loadable_Program 
{
  unsigned int    imageSize;  /* total size of the image, including text and data */
  unsigned long   entryPoint; /* initial program counter; execution starts here    */ 
  unsigned char * image;      /* pointer to the whole image */
};

/* Read_Elf_Executable will create, fill in and return a 
 * struct Loadable_Program   
 */
struct Loadable_Program * Read_Elf_Executable(char *programName);

/* 
 * Spawn_User_Program() sets up the memory space and kickstarts the program
 */

int Spawn_User_Program( char * programName);

#endif // LPROG_H
