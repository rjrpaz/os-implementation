// GeekOS C code entry point
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.36 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#include "bootinfo.h"
#include "string.h"
#include "screen.h"
#include "mem.h"
#include "tss.h"
#include "int.h"
#include "kthread.h"
#include "trap.h"
#include "timer.h"
#include "keyboard.h"
#include "ide.h"
#include "pfat.h"
#include "lprog.h"
#include "syscall.h"

static void Init_BSS( void );

void Main( struct Boot_Info* bootInfo )
{
    Init_BSS();
    Init_Screen();
    Init_Mem( bootInfo );
    Init_TSS();
    Init_Interrupts();
    Init_Scheduler();
    Init_Traps();
    Init_Timer();
    Init_Keyboard();
    Init_IDE();
    Init_PFAT();
    Init_Syscall();

    Set_Current_Attr( ATTRIB(BLACK, CYAN|BRIGHT) );
    Print( "Welcome to GeekOS!\n" );

    /* this thread will load&run  ELF files, see the rest in spawn.c */
    if (Spawn_User_Program("/c/shell.exe") < 0)
    {
       Print("Unable to load OS shell: /c/shell.exe, please fill in code\n");
    }

    // Now this thread is done.
    Exit();
}

// Initialize the .bss section of the executable image.
static void Init_BSS( void )
{
    char *bssStart, *bssEnd;

    // The windows versions of gcc use slightly different
    // names for the bss begin and end symbols than the Linux version.

#if defined(GNU_WIN32)
    extern char _bss_start__;
    extern char _bss_end__;
    bssStart = &_bss_start__;
    bssEnd = &_bss_end__;
#else
    extern char __bss_start;
    extern char end;
    bssStart = &__bss_start;
    bssEnd = &end;
#endif

    // Fill .bss with zeroes
    memset( bssStart, '\0', bssEnd - bssStart );
}
