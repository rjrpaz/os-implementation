// A shell for running GeekOS user mode programs

#include "libuser.h"
#include "libio.h"
#include "../string.h"

int Main( int argc, char ** argv )
{
    int pid;
    char buf[79];

    while ( TRUE ) {
	Print_String (" % ");
	Read_Line( buf, sizeof(buf) );

	if ( strcmp( (const char *) buf, "exit\n" ) == 0 )
	    break;
	if ( strcmp( (const char *) buf, "\n" ) == 0 )
	    continue;

	buf[strlen( (const char *) buf)-1] = '\0';
	pid = Spawn_Program ( buf);
	if (pid > 0) {
	    Wait(pid);
	}
    }

    Print_String( "DONE!\n" );

    return 0;
}
