#include <stdarg.h>

#include "libuser.h"

/*
 * atoi - only works for unsigned values
 *
 */

int atoi(char *buf)
{
    int ret = 0;

    while (*buf >= '0' && *buf <= '9') {
       ret *= 10;
       ret += *buf - '0';
       buf++;
    }

    return ret;
}

int itoa(char *buf, int num)
{
  int ret = 0;
  int reversed = 0, tmp;

  if (num < 0)
    {
      *buf++ = '-';
      num = - num;
    }
    
  tmp = num;
  do
    {
      reversed *= 10;
      reversed += tmp % 10;
      tmp /= 10;
    }
  while (tmp > 0); 

  do 
    {
      *buf++ = '0'+(reversed % 10);
      reversed /= 10;
    }
  while (reversed > 0); 

  *buf++ = '\0';

  return ret;

}
