// GeekOS timer interrupt support
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.5 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#include "io.h"
#include "int.h"
#include "irq.h"
#include "kthread.h"
#include "timer.h"

// global tick counter
volatile unsigned long g_numTicks;

// Maximum number of ticks a thread can use before
// we suspend it and choose another.
#define MAX_TICKS 4

// ----------------------------------------------------------------------
// Private functions
// ----------------------------------------------------------------------

static void Timer_Interrupt_Handler( struct Interrupt_State* state )
{
    struct Kernel_Thread* current = g_currentThread;

    Begin_IRQ( state );

    // Update global and per-thread number of ticks
    ++g_numTicks;
    ++current->numTicks;

    // If thread has been running for MAX_TICKS,
    // inform the interrupt return code that we want
    // to choose a new thread.
    if ( current->numTicks >= MAX_TICKS ) {
	g_needReschedule = TRUE;
    }

    End_IRQ( state );
}

// ----------------------------------------------------------------------
// Public functions
// ----------------------------------------------------------------------

void Init_Timer( void )
{
    // TODO: reprogram the timer to set the frequency.
    // In bochs, it defaults to 18Hz, which is actually pretty
    // reasonable.

    unsigned short irqMask;

    Print( "Initializing timer...\n" );

    // Install an interrupt handler for the timer IRQ
    Install_IRQ( TIMER_IRQ, &Timer_Interrupt_Handler );

    // Enable the IRQ in the IRQ mask
    irqMask = Get_IRQ_Mask();
    irqMask &= ~(1 << TIMER_IRQ);
    Set_IRQ_Mask( irqMask );
}
