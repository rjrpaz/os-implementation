// Kernel threads
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.42 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#include "kassert.h"
#include "defs.h"
#include "screen.h"
#include "int.h"
#include "mem.h"
#include "symbol.h"
#include "string.h"
#include "kthread.h"
#include "malloc.h"
#include "tss.h"

// defined in lowlevel.asm
unsigned long Get_Current_EFLAGS( void );

struct threadItem *allThreads;

// ----------------------------------------------------------------------
// Private data
// ----------------------------------------------------------------------

// Queue of runnable threads.
static struct Thread_Queue s_runQueue = THREAD_QUEUE_INITIALIZER;

// Current thread.
struct Kernel_Thread* g_currentThread;

// Boolean flag indicating that we need to choose a new runnable thread.
// It is checked by the interrupt return code (Handle_Interrupt,
// in lowlevel.asm) before returning from an interrupt.
Boolean g_needReschedule;

// Boolean flag indicating that the current thread is being
// killed (and should not be put back on the run queue).
Boolean g_killCurrentThread;

// Queue of finished threads needing disposal,
// and a wait queue used for communication between exited threads
// and the reaper thread.
static struct Thread_Queue s_graveyardQueue = THREAD_QUEUE_INITIALIZER;
static struct Thread_Queue s_reaperWaitQueue = THREAD_QUEUE_INITIALIZER;

// ----------------------------------------------------------------------
// Private functions
// ----------------------------------------------------------------------

// Initialize a new Kernel_Thread.
static void Init_Thread( struct Kernel_Thread* kthread, void* stackPage,
	int priority, Boolean detached )
{
    static int nextFreePid = 1;

    struct Kernel_Thread* owner = detached ? 0 : g_currentThread;

    memset( kthread, '\0', sizeof(*kthread) );
    kthread->stackPage = stackPage;
    kthread->esp = ((unsigned long) kthread->stackPage) + PAGE_SIZE;
    kthread->numTicks = 0;
    kthread->priority = priority;
    kthread->userContext = 0;
    kthread->owner = owner;

    // The thread has an implicit self-reference.
    // If the thread is not detached, then its owner
    // also has a reference to it.
    kthread->refCount = detached ? 1 : 2;

    kthread->alive = TRUE;
    kthread->pid = nextFreePid++;
}

// Create a new raw thread object.
// Returns a null pointer if there isn't enough memory.
static struct Kernel_Thread* Create_Thread( int priority, Boolean detached )
{
    struct threadItem *newItem;
    struct Kernel_Thread* kthread;
    void* stackPage = 0;

    Disable_Interrupts();

    // For now, just allocate one page each for the thread context
    // object and the thread's stack.
    kthread = Alloc_Page();
    if ( kthread != 0 )
        stackPage = Alloc_Page();    

    newItem = Malloc(sizeof(struct threadItem));
    newItem->next = allThreads;
    newItem->thread = kthread;
    allThreads = newItem;

    Enable_Interrupts();

    // Make sure that the memory allocations succeeded.
    if ( kthread == 0 )
	return 0;
    if ( stackPage == 0 ) {
	Free_Page_Atomic( kthread );
	return 0;
    }

    //Print( "New thread @ %x, stack @ %x\n", kthread, stackPage );

    // Initialize the stack pointer of the new thread
    // and accounting info
    Init_Thread( kthread, stackPage, priority, detached );

    return kthread;
}

// Push a dword value on the stack of given thread.
// We use this to set up some context for the thread before
// we make it runnable.
static __inline__ void Push( struct Kernel_Thread* kthread, unsigned long value )
{
    kthread->esp -= 4;
    *((unsigned long *) kthread->esp) = value;
}

// Destroy given thread.
// Called with interrupts enabled.
static void Destroy_Thread( struct Kernel_Thread* kthread )
{
    struct threadItem *curr, *lag;
    int reEnable = 0;

    if (Interrupts_Enabled()) {
        Disable_Interrupts();
        reEnable = 1;
    }

    KASSERT(!Interrupts_Enabled());

    for (lag=NULL, curr= allThreads; curr; curr=curr->next) {
        if (curr->thread == kthread) {
           if (curr == allThreads) {
              KASSERT(lag == NULL);
              allThreads = curr->next;
           } else {
              KASSERT(lag->next == curr);
              lag->next = curr->next;
           }
           Free(curr);
           break;
        } else {
           lag = curr;
        }
    }

    KASSERT(curr);

    // Dispose of the thread's memory.
    Free_Page( kthread->stackPage );
    Free_Page( kthread );

    if (reEnable) {
       Enable_Interrupts();
    }
}

// Called when a reference to the thread is broken.
void Detach_Thread( struct Kernel_Thread* kthread )
{
    KASSERT( !Interrupts_Enabled() );
    KASSERT( kthread->refCount > 0 );

    --kthread->refCount;
    if ( kthread->refCount == 0 ) {
	Reap_Thread( kthread );
    }
}

//find the thread by a pid (used for inter-user process communications)
struct Kernel_Thread* Find_Thread(int pid) {
    struct threadItem *curr = allThreads;

    KASSERT(!Interrupts_Enabled());

    while (curr != 0) {
        if (curr->thread->pid == pid) {
	    return curr->thread;
	}

       curr = curr->next;
    }

   return NULL;
}

// This function performs any needed initialization before
// a thread start function is executed.  Currently we just use
// it to enable interrupts (since Schedule() always activates
// a thread with interrupts disabled).
static void Launch_Thread( void )
{
    Enable_Interrupts();
}

// Code that is run when a thread finishes (i.e., returns from
// its body function), or when a thread exits voluntarily.  Frees
// the resources used by the thread.
static void Shutdown_Thread( void )
{
    struct Kernel_Thread* runnable;
    struct Kernel_Thread* current = g_currentThread;

    Disable_Interrupts();

    g_currentThread->alive = FALSE;

    // Find a thread to run.
    runnable = Get_Next_Runnable();

    // Remove the thread's implicit reference to itself.
    Detach_Thread( current );

    // Restore state of the thread we've chosen to run.
    // Note that we can't use Switch_To_Thread(), because
    // we don't want to return to this thread, because
    // it's going away.

    // Note: we must not touch the current stack again,
    // because it is a resource owned by the thread which
    // is going away.  So, we pass the pointer to the new
    // thread context in the eax register.  (See Restore_Thread
    // in lowlevel.asm).

    __asm__ __volatile__ (
	"jmp " _S(Restore_Thread)
	:
	: "a" (runnable) // ensures that runnable is in eax register
    );
}

// Push initial values for general purpose registers.
static void Push_General_Registers( struct Kernel_Thread* kthread )
{
    // Push initial values for saved general-purpose registers.
    // (The actual values are not important.)
    Push( kthread, 0 ); // eax
    Push( kthread, 0 ); // ebx
    Push( kthread, 0 ); // edx
    Push( kthread, 0 ); // edx
    Push( kthread, 0 ); // esi
    Push( kthread, 0 ); // edi
    Push( kthread, 0 ); // ebp
}

// Set up the initial context for a kernel-mode-only thread.
static void Setup_Kernel_Thread(
    struct Kernel_Thread* kthread,
    Thread_Start_Func startFunc,
    unsigned long arg )
{
    unsigned long eflags;

    // Push the argument to the thread start function, and the
    // return address (the shutdown function, so the thread will
    // go away cleanly when the start function returns).
    Push( kthread, arg );
    Push( kthread, (unsigned long) &Shutdown_Thread );

    // Push the address of the start function.
    Push( kthread, (unsigned long) startFunc );

    // To make the thread schedulable, we need to make it look
    // like it was suspended by an interrupt.  This means pushing
    // an "eflags, cs, eip" sequence onto the stack,
    // as well as int num, error code, saved registers, etc.

    // Use current value of eflags, except clear the interrupt flag
    // so the thread starts execution with interrupts disabled.
    // (The Schedule() function assumes that Switch_To_Thread()
    // will return with interrupts disabled.)
    eflags = Get_Current_EFLAGS();
    eflags &= ~(EFLAGS_IF);
    Push( kthread, eflags );

    // As the "return address" specifying where the new thread will
    // start executing, use the Launch_Thread() function.
    Push( kthread, KERNEL_CS );
    Push( kthread, (unsigned long) &Launch_Thread );

    // Push fake error code and interrupt number.
    Push( kthread, 0 );
    Push( kthread, 0 );

    // Push initial values for general-purpose registers.
    Push_General_Registers( kthread );

    // Push values for saved segment registers.
    // Only the ds register will contain a valid selector.
    Push( kthread, KERNEL_DS ); // ds
    Push( kthread, KERNEL_DS ); // es
    Push( kthread, 0 ); // fs
    Push( kthread, 0 ); // gs
}


// This is the body of the idle thread.  Its job is to preserve
// the invariant that a runnable thread always exists,
// i.e., the run queue is never empty.
static void Idle( unsigned long arg )
{
    while ( TRUE )
	Yield();
}

// The reaper thread.  Its job is to de-allocate memory
// used by threads which have finished.
static void Reaper( unsigned long arg )
{
    struct Kernel_Thread *kthread;

    Disable_Interrupts();

    while ( TRUE ) {
	// See if there are any threads needing disposal.
	if ( (kthread = s_graveyardQueue.head) == 0 ) {
	    // Graveyard is empty, so wait for a thread to die.
	    Wait( &s_reaperWaitQueue );
	}
	else {
	    // Make the graveyard queue empty.
	    Clear_Thread_Queue( &s_graveyardQueue );

	    // Now we can re-enable interrupts, since we
	    // have removed all the threads needing disposal.
	    Enable_Interrupts();
	    Yield();  // allow other threads to run?

	    // Dispose of the dead threads.
	    while ( kthread != 0 ) {
		struct Kernel_Thread* next = NODE_NEXT(Thread_Queue, kthread);
#if 0
		Print( "Reaper: disposing of thread @ %x, stack @ %x\n",
		    kthread, kthread->stackPage );
#endif
		Destroy_Thread( kthread );
		kthread = next;
	    }

	    // Disable interrupts again, since we're going to
	    // do another iteration.
	    Disable_Interrupts();
	}
    }
}

// Find the best (highest priority) thread in given
// thread queue.  Returns null if queue is empty.
static __inline__ struct Kernel_Thread* Find_Best( struct Thread_Queue* queue )
{
    // Pick the highest priority thread
    struct Kernel_Thread *kthread = queue->head, *best = 0;
    while ( kthread != 0 ) {
	if ( best == 0 || kthread->priority > best->priority )
	    best = kthread;
	kthread = NODE_NEXT(Thread_Queue, kthread);
    }
    return best;
}


// ----------------------------------------------------------------------
// Public functions
// ----------------------------------------------------------------------

void Init_Scheduler( void )
{
    struct Kernel_Thread* mainThread = (struct Kernel_Thread *) KERN_THREAD_OBJ;

    KASSERT( Is_Thread_Queue_Empty( &s_runQueue ) );

    // Create initial kernel thread context object and stack,
    // and make them current.

    allThreads = Malloc_Atomic(sizeof(struct threadItem));
    allThreads->next = 0;
    allThreads->thread  = mainThread;

    Init_Thread( mainThread, (void *) KERN_STACK, PRIORITY_NORMAL, TRUE );
    g_currentThread = mainThread;

    // Create the idle thread.
    //Print( "starting idle thread: " );
    Start_Kernel_Thread( Idle, 0, PRIORITY_IDLE, TRUE );

    // Create the reaper thread.
    //Print( "starting reaper thread: " );
    Start_Kernel_Thread( Reaper, 0, PRIORITY_NORMAL, TRUE );
}

// Start a kernel-mode-only thread, using given function as its body
// and passing given argument as its parameter.  Returns pointer
// to the new thread if successful, null otherwise.
//
// startFunc - is the function to be called by the new thread
// arg - is a paramter to pass to the new function
// priority - the priority of this thread (use PRIORITY_NORMAL) for
//    most things
// detahced - use false for kernel threads
//
struct Kernel_Thread* Start_Kernel_Thread(
    Thread_Start_Func startFunc,
    unsigned long arg,
    int priority,
    Boolean detached
)
{
    struct Kernel_Thread* kthread = Create_Thread( priority, detached );
    if ( kthread != 0 ) {
	// Create the initial context for the thread to make
	// it schedulable.
	Setup_Kernel_Thread( kthread, startFunc, arg );

	// Atomically put the thread on the run queue.
	Make_Runnable_Atomic( kthread );
    }

    return kthread;
}

//set up LDT
void Activate_User_Context_C( struct Kernel_Thread *kthread) {
    if (kthread->userContext != NULL) {

      //now put ldt selector into register
      __asm__ __volatile__ (
         "lldt %0"
         :
         : "a" (kthread->userContext->ldtSel)
      );

      g_theTSS.esp0 = ((unsigned long)kthread->stackPage + PAGE_SIZE);
      g_theTSS.ss0 = KERNEL_DS;
   }
}

struct Kernel_Thread* Start_User_Thread(
    struct User_Context* userContext,
    unsigned long entryAddr,
    Boolean detached
)
{
   // here you need to initalize a kthread using create_thread
   // push the appropriate values on its stack and make it runnable

   return NULL;
}


// Add given thread to the run queue, so that it
// may be scheduled.  Must be called with interrupts disabled!
void Make_Runnable( struct Kernel_Thread* kthread )
{
    KASSERT( !Interrupts_Enabled() );

    Enqueue_Thread( &s_runQueue, kthread );
}

// Atomically make a thread runnable.
// Assumes interrupts are currently enabled.
void Make_Runnable_Atomic( struct Kernel_Thread* kthread )
{
    Disable_Interrupts();
    Make_Runnable( kthread );
    Enable_Interrupts();
}

// Get the thread that currently has the CPU.
struct Kernel_Thread* Get_Current( void )
{
    return g_currentThread;
}

// Get the next runnable thread from the run queue.
// This is the scheduler.
struct Kernel_Thread* Get_Next_Runnable( void )
{
    struct Kernel_Thread* best = Find_Best( &s_runQueue );
    KASSERT( best != 0 );
    Remove_Thread( &s_runQueue, best );

//    Print( "Scheduling %x\n", best );

    return best;
}

// Schedule a thread that is waiting to run.
// Must be called with interrupts off!
// The current thread should already have been placed
// on whatever queue is appropriate (i.e., either the
// run queue if it is still runnable, or a wait queue
// if it is waiting for an event to occur).
void Schedule( void )
{
    struct Kernel_Thread* runnable;

    // Make sure interrupts really are disabled
    KASSERT( !Interrupts_Enabled() );

    // Get next thread to run from the run queue
    runnable = Get_Next_Runnable();

    // Activate the new thread, saving the context of the current thread.
    // Eventually, this thread will get re-activated and Switch_To_Thread()
    // will "return", and then Schedule() will return to wherever
    // it was called from.
    Switch_To_Thread( runnable );
}

// Voluntarily give up the CPU to another thread.
// Does nothing if no other threads are ready to run.
void Yield( void )
{
    Disable_Interrupts();
    Make_Runnable( g_currentThread );
    Schedule();
    Enable_Interrupts();
}

// Exit the current thread.
void Exit( void )
{
    Shutdown_Thread();
}

// Hand given thread to the reaper for destruction.
// Must be called with interrupts disabled!
void Reap_Thread( struct Kernel_Thread* kthread )
{
    Enqueue_Thread( &s_graveyardQueue, kthread );
    Wake_Up( &s_reaperWaitQueue );
}

// Wait for given thread to die.
void Join( struct Kernel_Thread* kthread )
{
    // It is only legal for the owner to join
    KASSERT( kthread->owner == g_currentThread );

    // busy wait
    while ( kthread->alive ) {
	Yield();
    }

    // Now the owner does not hold a valid reference to the thread
    Disable_Interrupts();
    Detach_Thread( kthread );
    Enable_Interrupts();
}

// Wait on given wait queue.
// Must be called with interrupts disabled!
// Note that the function will return with interrupts
// disabled.  This is desirable, because it allows us to
// atomically test a condition that can be affected by an interrupt
// and wait for it to be satisfied (if necessary).
// See the Wait_For_Key() function in keyboard.c
// for an example.
void Wait( struct Thread_Queue* waitQueue )
{
    struct Kernel_Thread* current = g_currentThread;

    KASSERT( !Interrupts_Enabled() );

    // Add the thread to the wait queue.
    Enqueue_Thread( waitQueue, current );

    // Find another thread to run.
    Schedule();
}

// Wake up all threads waiting on given wait queue.
// Must be called with interrupts disabled!
// See Keyboard_Interrupt_Handler() function in keyboard.c
// for an example.
void Wake_Up( struct Thread_Queue* waitQueue )
{
    struct Kernel_Thread *kthread = waitQueue->head, *next;

    KASSERT( !Interrupts_Enabled() );

    // Walk throught the list of threads in the wait queue,
    // transferring each one to the run queue.
    while ( kthread != 0 ) {
	next = NODE_NEXT(Thread_Queue, kthread);
	Make_Runnable( kthread );
	kthread = next;
    }

    // The wait queue is now empty.
    Clear_Thread_Queue( waitQueue );
}

// Wake up a single thread waiting on given wait queue
// (if there are any threads waiting).  Chooses the highest priority thread.
// Interrupts must be disabled!
void Wake_Up_One( struct Thread_Queue* waitQueue )
{
    struct Kernel_Thread* best;

    KASSERT( !Interrupts_Enabled() );

    best = Find_Best( waitQueue );

    if ( best != 0 ) {
	Remove_Thread( waitQueue, best );
	Make_Runnable( best );
	//Print( "Wake_Up_One: waking up %x from %x\n", best, g_currentThread );
    }
}
