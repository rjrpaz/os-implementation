// A test program for loading the ELF

#include "libio.h"

char  s1[40] = "Hi ! This is the first string\n";

int Main( int argc, char ** argv )
{
   char  s2[40] = "Hi ! This is the second string\n"; 

   Printf("The first string %s", s1);
   Printf("The second string %s", s2);

   return 0;
}
