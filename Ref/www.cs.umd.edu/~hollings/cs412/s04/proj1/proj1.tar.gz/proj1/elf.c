#include "pfat.h"
#include "screen.h"
#include "malloc.h"
#include "string.h"
#include "kthread.h"
#include "elf.h"
#include "lprog.h"

int elfDebug = 1;

struct Loadable_Program *Read_Elf_Executable(char *programName)
{
    char *program;
    int length;
    int ret;
    struct Loadable_Program *lp;

    if (elfDebug) 
      Print("reading %s...\n", programName);

    /* ReadFileAndAllocate will return a memory copy of the program on disk*/
    ret = ReadFileAndAllocate(programName, &program, &length);
    if (ret) 
      return NULL;

    if (elfDebug) 
      Print("reading %s done\n", programName);

    lp = (struct Loadable_Program *) Malloc_Atomic(sizeof(struct  Loadable_Program));

    /* here you read the ELF, parse the headers and fill lp
    ........
    ........
     */
     
    /* when done, comment the lp = NULL line below, so that
     * you return meaningful data to the caller in lprog.c
     */
    lp = NULL;

    return lp;
}
