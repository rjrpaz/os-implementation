// This is the device-driver interface to the interrupt system.
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.4 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#include "kassert.h"
#include "idt.h"
#include "io.h"
#include "irq.h"

// ----------------------------------------------------------------------
// Private functions and data
// ----------------------------------------------------------------------

// Current IRQ mask.
// This should be kept up to date with setup.asm
// (which does the initial programming of the PICs).
static unsigned short s_irqMask = 0xfffb;

// Get the master and slave parts of an IRQ mask.
#define MASTER(mask) ( (mask) & 0xff )
#define SLAVE(mask) ( ((mask)>>8) & 0xff )


// ----------------------------------------------------------------------
// Public functions
// ----------------------------------------------------------------------

// Install a handler for given IRQ.
// Note that we don't unmask the IRQ.
void Install_IRQ( int irq, Interrupt_Handler handler )
{
    Install_Interrupt_Handler( irq + FIRST_EXTERNAL_INT, handler );
}

// Get current IRQ mask.  Each bit position represents
// one of the 16 IRQ lines.
unsigned short Get_IRQ_Mask( void )
{
    return s_irqMask;
}

// Set the IRQ mask.
void Set_IRQ_Mask( unsigned short mask )
{
    unsigned char oldMask, newMask;

    oldMask = MASTER(s_irqMask);
    newMask = MASTER(mask);
    if ( newMask != oldMask ) {
	Out_Byte( 0x21, newMask );
    }

    oldMask = SLAVE(s_irqMask);
    newMask = SLAVE(mask);
    if ( newMask != oldMask ) {
	Out_Byte( 0xA1, newMask );
    }

    s_irqMask = mask;
}

// Called by an IRQ handler to begin the interrupt.
// Currently a no-op.
void Begin_IRQ( struct Interrupt_State* state )
{
}

// Called by an IRQ handler to end the interrupt.
// Sends an EOI command to the appropriate PIC(s).
void End_IRQ( struct Interrupt_State* state )
{
    int irq = state->intNum - FIRST_EXTERNAL_INT;
    unsigned char command = 0x60 | (irq & 0x7);

    if ( irq < 8 ) {
	// Specific EOI to master PIC
	Out_Byte( 0x20, command );
    }
    else {
	// Specific EOI to slave PIC, then to master (cascade line)
	Out_Byte( 0xA0, command );
	Out_Byte( 0x20, 0x62 );
    }
}
