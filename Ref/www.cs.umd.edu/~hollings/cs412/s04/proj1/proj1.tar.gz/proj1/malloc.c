// GeekOS memory allocation API
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.4 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#include "screen.h"
#include "int.h"
#include "bget.h"
#include "kassert.h"
#include "malloc.h"

// Initialize the heap starting at given address and occupying
// specified number of bytes.
void Init_Heap( unsigned long start, unsigned long size )
{
    Print( "Creating kernel heap: start=%x, size=%d\n", start, size );
    bpool( (void*) start, size );
}

// Dynamically allocate a buffer of given size.
// Returns null if there is not enough memory to satisfy the
// allocation.  Interrupts must be disabled!
void* Malloc( unsigned long size )
{
    KASSERT( !Interrupts_Enabled() );
    return bget( size );
}

// Like Malloc(), but is called with interrupts enabled.
void* Malloc_Atomic( unsigned long size )
{
    void* buf;

    Disable_Interrupts();
    buf = Malloc( size );
    Enable_Interrupts();

    return buf;
}

// Free a buffer allocated with Malloc() or Malloc_Atomic().
// Interrupts must be disabled!
void Free( void* buf )
{
    KASSERT( !Interrupts_Enabled() );
    brel( buf );
}

// Like Free(), but is called with interrupts enabled.
void Free_Atomic( void* buf )
{
    Disable_Interrupts();
    Free( buf );
    Enable_Interrupts();
}
