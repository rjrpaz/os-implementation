// A test program for loading the ELF

#include "libkern.h"


char  s1[40] = "Hi ! This is the first string\n";

void Main( void )
{
   char  s2[40] = "Hi ! This is the second string\n"; 

   ELF_Print(s1);
   ELF_Print(s2); 
}
