// GeekOS interrupt handling data structures and functions
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.12 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

// This module describes the C interface which must be implemented
// by interrupt handlers, and has the initialization function
// for the interrupt system as a whole.

#ifndef INT_H
#define INT_H

#include "kassert.h"
#include "ktypes.h"

//
// This struct reflects the contents of the stack when
// a C interrupt handler function is called.
// It must be kept up to date with the code in "lowlevel.asm".
//
struct Interrupt_State {
    // The register contents at the time of the exception.
    // We save these explicitly.
    unsigned int gs;
    unsigned int fs;
    unsigned int es;
    unsigned int ds;
    unsigned int ebp;
    unsigned int edi;
    unsigned int esi;
    unsigned int edx;
    unsigned int ecx;
    unsigned int ebx;
    unsigned int eax;

    // We explicitly push the interrupt number.
    // This makes it easy for the handler function to determine
    // which interrupt occurred.
    unsigned int intNum;

    // This may be pushed by the processor; if not, we push
    // a dummy error code, so the stack layout is the same
    // for every type of interrupt.
    unsigned int errorCode;

    // These are always pushed on the stack by the processor.
    unsigned int eip;
    unsigned int cs;
    unsigned int eflags;
};

// The interrupt flag bit in the eflags register.
// FIXME: should be in something like "cpu.h".
#define EFLAGS_IF (1 << 9)

// The signature of an interrupt handler.
typedef void (*Interrupt_Handler)( struct Interrupt_State* state );

// Perform all low- and high-level initialization of the
// interrupt system.
void Init_Interrupts( void );

// Query whether or not interrupts are currently enabled.
Boolean Interrupts_Enabled( void );

// Block interrupts.
static __inline__ void __Disable_Interrupts( void )
{
    __asm__ __volatile__ ( "cli" );
}
#define Disable_Interrupts()		\
do {					\
    KASSERT( Interrupts_Enabled() );	\
    __Disable_Interrupts();		\
} while ( 0 )

// Unblock interrupts.
static __inline__ void __Enable_Interrupts( void )
{
    __asm__ __volatile__ ( "sti" );
}
#define Enable_Interrupts()		\
do {					\
    KASSERT( !Interrupts_Enabled() );	\
    __Enable_Interrupts();		\
} while ( 0 )

// Dump interrupt state struct to screen
void Dump_Interrupt_State( struct Interrupt_State* state );

#endif // INT_H
