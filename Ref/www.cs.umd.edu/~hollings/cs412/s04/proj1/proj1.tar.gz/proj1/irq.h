// This is the device-driver interface to the interrupt system.
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.3 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#ifndef IRQ_H
#define IRQ_H

#include "int.h"

void Install_IRQ( int irq, Interrupt_Handler handler );
unsigned short Get_IRQ_Mask( void );
void Set_IRQ_Mask( unsigned short mask );

// IRQ handlers should call these to begin and end the
// interrupt.
void Begin_IRQ( struct Interrupt_State* state );
void End_IRQ( struct Interrupt_State* state );

#endif // IRQ_H
