// Trap handlers
// Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
// $Revision: 1.10 $

// This is free software.  You are permitted to use,
// redistribute, and modify it as specified in the file "COPYING".

#include "idt.h"
#include "kthread.h"
#include "defs.h"
#include "trap.h"

// TODO: need to add handlers for other exceptions (such as bounds
// check, debug, etc.)

// Handler for general protection faults and other bad errors.
// Kill the current thread (which caused the fault).
static void GPF_Handler( struct Interrupt_State* state )
{
    // Send the thread to the reaper...
    Print( "Exception %d received, killing thread %x\n",
	state->intNum, g_currentThread );
    Dump_Interrupt_State( state );

    while(1);

    Reap_Thread( g_currentThread ); // send the thread to the reaper
    g_killCurrentThread = TRUE;     // don't make the thread runnable again
    g_needReschedule = TRUE;	    // pick a new thread
}

// System call handler.
static void Syscall_Handler( struct Interrupt_State* state )
{
    // The system call number is specified in the eax register.
    unsigned int syscallNum = state->eax;

    Print( "Illegal system call %d by thread %x\n",
		syscallNum, g_currentThread );
    Reap_Thread( g_currentThread );
    g_killCurrentThread = TRUE;
    g_needReschedule = TRUE;
    return;
}

// Initialize handlers for processor traps.
void Init_Traps( void )
{
    Install_Interrupt_Handler( 12, &GPF_Handler ); // stack exception
    Install_Interrupt_Handler( 13, &GPF_Handler ); // general protection fault
    Install_Interrupt_Handler( SYSCALL_INT, &Syscall_Handler );
}
