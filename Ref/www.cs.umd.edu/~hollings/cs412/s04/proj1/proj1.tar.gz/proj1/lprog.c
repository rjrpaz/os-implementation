#include "pfat.h"
#include "screen.h"
#include "malloc.h"
#include "string.h"
#include "kthread.h"
#include "segment.h"
#include "gdt.h"
#include "mem.h"
#include "int.h"
#include "idt.h"
#include "lprog.h"

/* housekeeping routines, not much relevant */
extern void Trampoline(unsigned short CodeSelector, unsigned short DataSelector, unsigned long entry);
static void Printrap_Handler(struct Interrupt_State* state);

static void * virtSpace;

static int lprogdebug = 1;

/* Spawner is a a thread that accomodates the program to be loaded & executed
 * it is started from main.c
 */

void Spawner( unsigned long arg )
{
  struct Loadable_Program * lp;

  lp = Read_Elf_Executable("/c/a.exe");

  if (!lp)
    {
      Print("Read_Elf_Executable returned NULL, please fill in the code in Read_Elf_Executable()\n");
      Exit();
    }

  if (Spawn_Program(lp) != 0)
    {
      Print("Spawn_Program() failed\n");
      Exit();
    }

  /* If we arrived here, everything was fine and the program exited */

  Print("Hi ! This is the last string\n");
  Print("If you see this you're happy\n");

  Exit();
}

/* 
 * Spawn_Program() sets up the memory space, and kickstarts the program
 */

int Spawn_Program( struct Loadable_Program * lp )
{
  struct Segment_Descriptor* desc;
  unsigned long virtSize;
  unsigned short codeSelector, dataSelector;

  /* setup some memory space for the program */
  virtSize = Round_Up_To_Page(lp->imageSize);
  virtSpace = Malloc_Atomic(virtSize);
  memset((char *) virtSpace, '\0', virtSize);
  memcpy(virtSpace, (char *) lp->image, lp->imageSize);

  /* allocate and init descriptors and selectors for code and data */

  // Kernel code segment.
  desc = Allocate_Segment_Descriptor();
  Init_Code_Segment_Descriptor(
			       desc,
			       (unsigned long)virtSpace, // base address
			       (virtSize/PAGE_SIZE)+10,	 // num pages
			       0		         // privilege level (0 == kernel)
			       );
  codeSelector = Selector( 0, TRUE, Get_Descriptor_Index( desc ) );
  // Kernel data segment.
  desc = Allocate_Segment_Descriptor();
  Init_Data_Segment_Descriptor(
			       desc,
			       (unsigned long)virtSpace, // base address
			       (virtSize/PAGE_SIZE)+10,	 // num pages
			       0		         // privilege level (0 == kernel)
			       );
  dataSelector = Selector( 0, TRUE, Get_Descriptor_Index( desc ) );

  Install_Interrupt_Handler( 0x90, &Printrap_Handler );

  if (lprogdebug)
    {
      Print("Spawn_Program(): all structures are set up\n");
      Print(" virtSpace    = %x\n", virtSpace);
      Print(" virtSize     = %x\n", virtSize);
      Print(" codeSelector = %x\n", codeSelector);
      Print(" dataSelector = %x\n", dataSelector);

      Print("Now calling Trampoline()... \n");
    }

  Trampoline(codeSelector, dataSelector, lp->entryPoint); 
  return 0;
}

static void Printrap_Handler( struct Interrupt_State* state )
{
  char * msg = (char *)virtSpace + state->eax;

  Print(msg);

  g_needReschedule = TRUE;
  return;
}

