/* 
 * you shouldn't normally change this file
 */

/*
 * the only support for testing ELF load&run is this function which 
 * prints a string 
 */
 
#include <stddef.h>

void ELF_Print(char* msg);

