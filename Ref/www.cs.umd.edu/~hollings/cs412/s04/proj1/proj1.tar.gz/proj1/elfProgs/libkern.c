/*
 * you shouldn't normally change this file
 */
 
#include "libkern.h"

extern void Main( void );

void ELF_Print(char* msg)
{

  __asm__ __volatile__ (
			"int $0x90"
			: /* no return */
			: "a" (msg)	// goes in eax
			);
}

void Entry(void)
{
  Main();
  __asm__ __volatile__ ("leave");
  __asm__ __volatile__ ("lret");
}
