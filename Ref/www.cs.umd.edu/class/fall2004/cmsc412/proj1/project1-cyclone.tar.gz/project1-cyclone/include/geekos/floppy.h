/*
 * My feeble attempt at a floppy driver
 * Copyright (c) 2003, David H. Hovemeyer <daveho@cs.umd.edu>
 * $Revision: 1.9 $
 * 
 * This is free software.  You are permitted to use,
 * redistribute, and modify it as specified in the file "COPYING".
 */

#ifndef GEEKOS_FLOPPY_H
#define GEEKOS_FLOPPY_H

#ifdef GEEKOS

/*
 * Functions
 */
void Init_Floppy(void);

#endif  /* GEEKOS */

#endif  /* GEEKOS_FLOPPY_H */

