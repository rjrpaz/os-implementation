/*
 * Interface file for calling Cyclone code from C code in GeekOS.
 * Copyright (c) 2004, Michael Hicks <mwh@cs.umd.edu>
 * $Revision: 1.2 $
 * 
 * This is free software.  You are permitted to use,
 * redistribute, and modify it as specified in the file "COPYING".
 */

#ifndef __CYCLONE_H__
#define __CYCLONE_H__

#include <geekos/cyclone/runtime_internal.h>

/* Cyclone initialization.  This must be called before any Cyclone
   code can be executed.  Call one only once. */
#define Init_Cyclone() { _init_regions(); _init_stack(); _init_exceptions(); }


extern char *_set_top_handler();
extern char *_set_catchall_handler(struct _handler_cons *h);

/* To call a Cyclone function.  This macro does two things: 

   1) Places a "top-level" exception handler around this call to catch
   any stray exceptions.  The result of the macro is NULL if no
   exception is thrown, or the exception name if it was.
   2) Places Cyc_ prefix around the call.

   For cyc_call, the result is stored in the provided variable res.
*/
#define cyc_call(res,e)				\
({ struct _handler_cons h;			\
   char *exn = _set_catchall_handler(&h);	\
   if (!exn) res = Cyc_ ## e;			\
   exn;						\
})

#define void_cyc_call(e)			\
({ struct _handler_cons h;			\
   char *exn = _set_catchall_handler(&h);	\
   if (!exn) Cyc_ ## e;				\
   exn;						\
})

#endif
