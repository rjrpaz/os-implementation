/** @file add_one.h
 *  @brief provides the definitions for the add_one functions
 *
 *  @author Michael Ashley-Rollman(mpa)
 */

#ifndef __ADD_ONE_H
#define __ADD_ONE_H

int add_one1(int);
int add_one2(int);

#endif /* __ADD_ONE_H */
